<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['name' => 'Operator Sekolah', 'email' => 'operator@labschool.com', 'role' => 'operator'],
            ['name' => 'Wakasek Kurikulum', 'email' => 'kurikulum@labschool.com', 'role' => 'wakasek_kurikulum'],
            ['name' => 'Wakasek Kesiswaan', 'email' => 'kesiswaan@labschool.com', 'role' => 'wakasek_kesiswaan'],
            ['name' => 'Guru Mata Pelajaran', 'email' => 'guru@labschool.com', 'role' => 'guru'],
            ['name' => 'Wali Kelas', 'email' => 'walikelas@labschool.com', 'role' => 'wali_kelas'],
            ['name' => 'Guru Piket', 'email' => 'gurupiket@labschool.com', 'role' => 'guru_piket'],
            ['name' => 'Siswa', 'email' => 'siswa@labschool.com', 'role' => 'siswa'],
        ];

        foreach ($users as $user) {
            User::firstOrCreate(
                ['email' => $user['email']],
                [
                    'name'     => $user['name'],
                    'password' => Hash::make('password123'),
                    'role'     => $user['role'],
                ]
            );
        }
    }
}