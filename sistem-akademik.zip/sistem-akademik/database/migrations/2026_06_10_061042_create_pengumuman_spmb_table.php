<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pengumuman_spmb', function (Blueprint $table) {
            $table->id();
            $table->string('nama_siswa');
            $table->string('asal_sekolah');
            $table->enum('status', ['diterima', 'ditolak']);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pengumuman_spmb');
    }
};