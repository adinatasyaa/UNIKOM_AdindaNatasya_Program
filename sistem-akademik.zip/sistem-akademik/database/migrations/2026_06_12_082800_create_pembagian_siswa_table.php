<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    
    public function up(): void
    {
        Schema::create('pembagian_siswa', function (Blueprint $table) {
            $table->id();
            $table->foreignId('siswa_id')->constrained('siswa')->onDelete('cascade');
            $table->foreignId('kelas_id')->constrained('kelas')->onDelete('cascade');
            $table->string('tahun_ajaran');
            $table->enum('semester', ['1', '2']);
            $table->enum('status_pembagian', ['draft', 'fix'])->default('draft'); // Otomatis draft, jadi 'fix' setelah dirilis Wakasek
            $table->timestamps();
        });
    }

   
    public function down(): void
    {
        Schema::dropIfExists('pembagian_siswa');
    }
};