<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('predikat', function (Blueprint $table) {
            $table->id();

            $table->string('predikat', 1); // A,B,C,D
            $table->integer('nilai_min');
            $table->integer('nilai_max');
            $table->string('keterangan');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('predikat');
    }
};