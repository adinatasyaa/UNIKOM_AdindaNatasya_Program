<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('komponen_bobot', function (Blueprint $table) {
            $table->id();
            $table->foreignId('bobot_penilaian_id')->constrained('bobot_penilaian')->cascadeOnDelete();
            $table->string('nama_komponen');
            $table->enum('jenis', ['tugas', 'uts', 'uas'])->default('tugas');
            $table->integer('persentase');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('komponen_bobot');
    }
};