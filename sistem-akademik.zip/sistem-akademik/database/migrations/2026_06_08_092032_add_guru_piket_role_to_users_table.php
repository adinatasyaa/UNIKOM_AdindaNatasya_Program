<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        \DB::statement("ALTER TABLE users MODIFY COLUMN role ENUM('operator','wakasek_kurikulum','wakasek_kesiswaan','guru','guru_piket','wali_kelas','siswa','orang_tua') DEFAULT 'siswa'");
    }

    public function down(): void
    {
        \DB::statement("ALTER TABLE users MODIFY COLUMN role ENUM('operator','wakasek_kurikulum','wakasek_kesiswaan','guru','wali_kelas','siswa','orang_tua') DEFAULT 'siswa'");
    }
};