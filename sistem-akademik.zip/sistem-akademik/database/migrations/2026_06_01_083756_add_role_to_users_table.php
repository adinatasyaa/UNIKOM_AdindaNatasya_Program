<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', [
                'operator',
                'wakasek_kurikulum',
                'wakasek_kesiswaan',
                'guru',
                'wali_kelas',
                'siswa',
                'orang_tua'
            ])->default('siswa')->after('email');
            $table->foreignId('guru_id')->nullable()->constrained('guru')->nullOnDelete()->after('role');
            $table->foreignId('siswa_id')->nullable()->constrained('siswa')->nullOnDelete()->after('guru_id');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['role', 'guru_id', 'siswa_id']);
        });
    }
};