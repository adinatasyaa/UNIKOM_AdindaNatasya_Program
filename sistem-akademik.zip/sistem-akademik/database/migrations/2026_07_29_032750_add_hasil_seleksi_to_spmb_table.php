<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
    Schema::table('spmb', function (Blueprint $table) {
        $table->enum('hasil_seleksi', ['menunggu', 'lulus', 'tidak_lulus'])->default('menunggu')->after('status');
        });
    }

    public function down()
    {
    Schema::table('spmb', function (Blueprint $table) {
        $table->dropColumn('hasil_seleksi');
    });
    }
};
