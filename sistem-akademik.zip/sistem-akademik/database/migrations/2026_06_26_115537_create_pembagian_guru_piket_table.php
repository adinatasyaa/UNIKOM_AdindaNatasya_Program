<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pembagian_guru_piket', function (Blueprint $table) {
            $table->id();
            $table->foreignId('guru_id')->constrained('guru')->onDelete('cascade');
            $table->string('hari');
            $table->string('tahun_ajaran');
            $table->string('semester');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pembagian_guru_piket');
    }
};