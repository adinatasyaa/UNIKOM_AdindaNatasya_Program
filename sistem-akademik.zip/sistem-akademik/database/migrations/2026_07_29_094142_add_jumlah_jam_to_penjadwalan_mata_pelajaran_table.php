<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
{
    Schema::table('penjadwalan_mata_pelajaran', function (Blueprint $table) {
        $table->integer('jumlah_jam')->default(0)->after('jam_selesai');
    });
}

public function down()
{
    Schema::table('penjadwalan_mata_pelajaran', function (Blueprint $table) {
        $table->dropColumn('jumlah_jam');
    });
}
};
