<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('absensi_piket', function (Blueprint $table) {
            $table->id();
            $table->foreignId('siswa_id')->constrained('siswa')->cascadeOnDelete();
            $table->foreignId('guru_piket_id')->constrained('guru')->cascadeOnDelete();
            $table->date('tanggal');
            $table->enum('status', ['terlambat','izin_pulang','tidak_hadir']);
            $table->text('keterangan')->nullable();
            $table->string('tahun_ajaran');
            $table->enum('semester', ['1', '2']);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('absensi_piket');
    }
};