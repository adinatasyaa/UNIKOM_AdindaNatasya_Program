<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            {{ __('Hapus Akun') }}
        </h2>
        <p class="text-muted mb-3">
            Setelah akun Anda dihapus, semua data terkait akan dihapus secara permanen. Silakan unduh data yang ingin Anda simpan sebelum menghapus akun.
        </p>
    </header>

    @if ($errors->userDeletion->isNotEmpty())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->userDeletion->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="post" action="{{ route('profile.destroy') }}" onsubmit="return confirmDeleteAccount()">
        @csrf
        @method('delete')

        <div class="mb-3" style="max-width: 300px;">
            <label for="password" class="form-label">Password</label>
            <input id="password" name="password" type="password" class="form-control" placeholder="Masukkan password Anda">
        </div>

        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash me-1"></i> Hapus Akun
        </button>
    </form>
</section>

<script>
function confirmDeleteAccount() {
    return confirm('Yakin ingin menghapus akun ini? Tindakan ini tidak dapat dibatalkan dan seluruh data akan hilang permanen.');
}
</script>