@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="mb-4">
        <h4 class="mb-0">Pembagian Kelas</h4>
            <p class="text-muted">Daftar kelas dan siswa yang telah ditetapkan oleh sekolah.</p>
    </div>
    @if(session('success')) 
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    @endif

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tahun / Semester</th>
                        <th>Kelas Yang Ditugaskan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($kelasSaya as $ks)
                    <tr>
                        <td>{{ $ks->tahun_ajaran }} / {{ $ks->semester }}</td>
                        <td><strong>{{ $ks->kelas->nama_kelas ?? 'Kelas Tidak Ditemukan' }}</strong></td>
                        <td>
                            @if($ks->status_persetujuan == 'menunggu')
                                <span class="badge bg-warning text-dark">
                                    Menunggu Persetujuan Kepala Sekolah
                                </span>
                            @elseif($ks->status_persetujuan == 'disetujui')
                                <span class="badge bg-success">
                                    Disetujui Kepala Sekolah
                                </span>
                            @else
                                <span class="badge bg-danger">
                                    Ditolak Kepala Sekolah
                                </span>
                            @endif
                        </td>
                        <td class="text-center">
                            <a href="{{ route('wali_kelas.pembagian_kelas.show', $ks->id) }}"class="btn btn-info btn-sm"title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">Belum ada pembagian kelas yang dapat ditampilkan.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection