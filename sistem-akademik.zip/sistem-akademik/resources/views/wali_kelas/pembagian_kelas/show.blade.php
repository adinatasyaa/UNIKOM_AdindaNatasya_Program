@extends('layouts.app')

@section('page-title', 'Detail Persetujuan')

@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="{{ route('wali_kelas.pembagian_kelas.index') }}"class="btn btn-secondary btn-sm mb-2">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
            <h4 class="mb-0">Detail Siswa Kelas: {{ $pembagianKelas->kelas->nama_kelas }}</h4>
            <small class="text-muted">Tahun Ajaran: {{ $pembagianKelas->tahun_ajaran }} | Semester: {{ $pembagianKelas->semester }}</small>
        </div>
            <div>
                Status Kelas: 
                <span class="badge {{ $pembagianKelas->status_persetujuan == 'disetujui' ? 'bg-success' : 'bg-danger' }} uppercase">
                    {{ strtoupper($pembagianKelas->status_persetujuan) }}
                </span>
            </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white font-weight-bold">
            Daftar Siswa Terdistribusi (Total: {{ $daftarSiswa->count() }} Siswa)
        </div>
        <div class="card-body p-0">
            <table class="table table-striped table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="50" class="text-center">No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($daftarSiswa as $index => $ds)
                    <tr>
                        <td class="text-center">{{ $index + 1 }}</td>
                        <td>{{ $ds->siswa->nis ?? '-' }}</td>
                        <td>{{ $ds->siswa->nama ?? 'Nama Tidak Terdata' }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="3" class="text-center py-4 text-muted">Belum ada data siswa yang dimasukkan ke kelas ini oleh Kesiswaan.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection