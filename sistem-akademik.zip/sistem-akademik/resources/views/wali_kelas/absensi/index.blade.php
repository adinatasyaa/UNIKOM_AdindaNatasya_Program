@extends('layouts.app')

@section('page-title', 'Absensi Kelas')

@section('content')
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Rekap Absensi Kelas (Guru Mata Pelajaran)</h5>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Filter Kelas</label>
                <select class="form-select" onchange="window.location='?kelas_id='+this.value">
                    <option value="">-- Semua Kelas --</option>
                    @foreach($kelas as $k)
                        <option value="{{ $k->id }}" {{ request('kelas_id') == $k->id ? 'selected' : '' }}>
                            {{ $k->nama_kelas }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Jam Pelajaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($absensi as $index => $a)
                    <tr>
                        <td>{{ $absensi->firstItem() + $index }}</td>
                        <td>{{ \Carbon\Carbon::parse($a->tanggal)->format('d/m/Y') }}</td>
                        <td>{{ $a->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $a->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $a->guru->nama ?? '-' }}</td>
                        <td>{{ $a->jam_pelajaran }}</td>
                        <td>
                            <a href="{{ route('wali_kelas.absensi.show', $a->id) }}" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data absensi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $absensi->links('pagination::bootstrap-5') }}
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Informasi Absensi dari Guru Piket</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Informasi keterlambatan, izin pulang, atau ketidakhadiran siswa yang dicatat oleh Guru Piket.
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($absensiPiket as $index => $p)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ \Carbon\Carbon::parse($p->tanggal)->format('d/m/Y') }}</td>
                        <td>{{ $p->nama_siswa }}</td>
                        <td>{{ $p->nama_kelas }}</td>
                        <td>
                            @if($p->status == 'terlambat')
                                <span class="badge bg-warning">Terlambat</span>
                            @elseif($p->status == 'izin_pulang')
                                <span class="badge bg-info">Izin Pulang</span>
                            @elseif($p->status == 'izin')
                                <span class="badge bg-primary">Izin</span>
                            @elseif($p->status == 'tidak_hadir')
                                <span class="badge bg-danger">Tidak Hadir</span>
                            @endif
                        </td>
                        <td>{{ $p->keterangan ?? '-' }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada informasi dari Guru Piket</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection