@extends('layouts.app')

@section('page-title', 'Detail Absensi')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Absensi</h5>
        <a href="{{ route('wali_kelas.absensi.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Mata Pelajaran</td>
                        <td><strong>{{ $absensi->mataPelajaran->nama_mapel ?? '-' }}</strong></td>
                    </tr>
                    <tr>
                        <td>Kelas</td>
                        <td>{{ $absensi->kelas->nama_kelas ?? '-' }}</td>
                    </tr>
                    <tr>
                        <td>Guru</td>
                        <td>{{ $absensi->guru->nama ?? '-' }}</td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td>{{ \Carbon\Carbon::parse($absensi->tanggal)->format('d/m/Y') }}</td>
                    </tr>
                    <tr>
                        <td>Jam Pelajaran</td>
                        <td>{{ $absensi->jam_pelajaran }}</td>
                    </tr>
                    <tr>
                        <td>Semester</td>
                        <td>Semester {{ $absensi->semester }}</td>
                    </tr>
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td>{{ $absensi->tahun_ajaran }}</td>
                    </tr>
                </table>
            </div>
        </div>

        <h6 class="fw-bold mb-3">Daftar Kehadiran Siswa</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Status Kehadiran</th>
                        <th>Keterangan</th>
                        <th>Diperbarui Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($absensi->detail as $index => $d)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $d->siswa->nis ?? '-' }}</td>
                        <td>{{ $d->siswa->nama ?? '-' }}</td>
                        <td>
                            @if($d->status_kehadiran == 'Hadir')
                                <span class="badge" style="background:#28a745;">Hadir</span>
                            @elseif($d->status_kehadiran == 'Izin')
                                <span class="badge" style="background:#007bff;">Izin</span>
                            @elseif($d->status_kehadiran == 'Sakit')
                                <span class="badge" style="background:#fd7e14;">Sakit</span>
                            @elseif($d->status_kehadiran == 'Alpa')
                                <span class="badge" style="background:#dc3545;">Alpa</span>
                            @endif
                        </td>
                        <td>{{ $d->keterangan ?? '-' }}</td>
                        <td>{{ $d->updatedBy->name ?? '-' }}</td>
                        <td>
                            <!-- Form Update Wali Kelas -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                data-bs-target="#editModal{{ $d->id }}">
                                <i class="bi bi-pencil"></i>
                            </button>

                            <div class="modal fade" id="editModal{{ $d->id }}" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Update Kehadiran - {{ $d->siswa->nama ?? '-' }}</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form action="{{ route('wali_kelas.absensi.update', $d->id) }}" method="POST">
                                            @csrf
                                            @method('PATCH')
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Status Kehadiran</label>
                                                    <select name="status_kehadiran" class="form-select" required>
                                                        <option value="Hadir" {{ $d->status_kehadiran == 'Hadir' ? 'selected' : '' }}>Hadir</option>
                                                        <option value="Izin" {{ $d->status_kehadiran == 'Izin' ? 'selected' : '' }}>Izin</option>
                                                        <option value="Sakit" {{ $d->status_kehadiran == 'Sakit' ? 'selected' : '' }}>Sakit</option>
                                                        <option value="Alpa" {{ $d->status_kehadiran == 'Alpa' ? 'selected' : '' }}>Alpa</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Keterangan</label>
                                                    <textarea name="keterangan" class="form-control" rows="3">{{ $d->keterangan }}</textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data kehadiran</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection