@extends('layouts.app')

@section('page-title', 'Penilaian Kelas')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Kelengkapan Nilai — {{ $kelas->nama_kelas }}</h5>
        <a href="{{ route('wali_kelas.penilaian.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Ganti Kelas
        </a>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Wali Kelas hanya dapat <strong>melihat</strong> nilai siswa. Penginputan nilai dilakukan oleh Guru Mata Pelajaran.
            Baris berwarna <span style="background:#f8d7da; padding:2px 8px; border-radius:4px;">merah</span> menandakan siswa belum melengkapi nilai di salah satu mata pelajaran.
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead style="font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Jumlah Mapel Dinilai</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($dataSiswa as $index => $d)
                    <tr style="{{ !$d['lengkap'] ? 'background-color:#f8d7da;' : '' }}">
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $d['siswa']->nis }}</td>
                        <td>{{ $d['siswa']->nama }}</td>
                        <td>{{ $d['penilaian']->count() }} mata pelajaran</td>
                        <td>
                            @if($d['lengkap'])
                                <span class="badge bg-success">Lengkap</span>
                            @else
                                <span class="badge bg-danger">Belum Lengkap</span>
                            @endif
                        </td>
                        <td>
                            <a href="{{ route('wali_kelas.penilaian.detail', [$kelas->id, $d['siswa']->id]) }}" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i> Lihat Detail
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada siswa di kelas ini</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection