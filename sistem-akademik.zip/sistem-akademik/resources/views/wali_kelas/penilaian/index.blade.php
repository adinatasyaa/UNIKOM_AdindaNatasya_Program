@extends('layouts.app')

@section('page-title', 'Penilaian Kelas')

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Pilih Kelas</h5>
    </div>
    <div class="card-body">
        <p class="text-muted">Pilih kelas yang Anda ampu untuk melihat kelengkapan nilai siswa.</p>
        <div class="row g-3">
            @forelse($kelas as $k)
            <div class="col-md-3">
                <a href="{{ route('wali_kelas.penilaian.show', $k->id) }}" class="text-decoration-none">
                    <div class="card text-center p-3 h-100" style="border:1px solid #dee2e6; transition:.2s;"
                        onmouseover="this.style.boxShadow='0 4px 10px rgba(0,0,0,0.1)'"
                        onmouseout="this.style.boxShadow='none'">
                        <i class="bi bi-door-open fs-2 text-primary mb-2"></i>
                        <h6 class="mb-0">{{ $k->nama_kelas }}</h6>
                    </div>
                </a>
            </div>
            @empty
            <div class="col-12 text-center text-muted py-4">
                Anda belum ditetapkan sebagai wali kelas manapun.
            </div>
            @endforelse
        </div>
    </div>
</div>
@endsection