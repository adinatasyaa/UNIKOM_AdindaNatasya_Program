@extends('layouts.app')

@section('page-title', 'Detail Nilai Siswa')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Nilai — {{ $siswa->nama }}</h5>
    <div class="d-flex gap-2">
        <a href="{{ route('wali_kelas.penilaian.show', $kelas->id) }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
        <a href="{{ route('wali_kelas.penilaian.unduh', [$kelas->id, $siswa->id]) }}" class="btn btn-success btn-sm">
            <i class="bi bi-download me-1"></i> Unduh Rapor
        </a>
    </div>
</div>
    <div class="card-body">
        <table class="table table-bordered mb-4">
            <tr>
                <td width="30%">NIS</td>
                <td>{{ $siswa->nis }}</td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><strong>{{ $siswa->nama }}</strong></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td>{{ $kelas->nama_kelas }}</td>
            </tr>
        </table>

        <h6 class="fw-bold mb-3">Daftar Nilai per Mata Pelajaran</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>Mata Pelajaran</th>
                        <th>Nilai Akhir</th>
                        <th>Predikat</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($penilaian as $index => $p)
                    <tr style="{{ $p->status == 'belum_lengkap' ? 'background-color:#f8d7da;' : '' }}">
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $p->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $p->nilai_akhir ?? '-' }}</td>
                        <td>
                            @if($p->predikat)
                                <div class="d-flex flex-column align-items-center gap-1">
                                    <span class="badge bg-primary">{{ $p->predikat }}</span>
                                    <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                    {{ $p->keterangan }}
                                    </span>
                                </div>
                            @else
                              -
                            @endif
                        </td>
                        <td>
                            @if($p->status == 'final')
                                <span class="badge bg-success">Final</span>
                            @elseif($p->status == 'lengkap')
                                <span class="badge bg-info">Lengkap</span>
                            @else
                                <span class="badge bg-danger">Belum Lengkap</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted">Belum ada data nilai untuk siswa ini</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection