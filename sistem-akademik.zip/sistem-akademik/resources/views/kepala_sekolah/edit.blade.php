@extends('layouts.app')

@section('page-title', 'Edit Guru Piket')

@section('content')

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Guru Piket</h5>
        <a href="{{ route('kepala_sekolah.pembagian-guru-piket.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <div class="card-body">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('kepala_sekolah.pembagian-guru-piket.update', $piket->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Guru</label>
                    <select name="guru_id" class="form-select">
                        @foreach($guru as $g)
                            <option value="{{ $g->id }}"
                                {{ $g->id == $piket->guru_id ? 'selected' : '' }}>
                                {{ $g->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Hari</label>
                    <select name="hari" class="form-select">
                        @foreach(['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $hari)
                            <option value="{{ $hari }}"
                                {{ $hari == $piket->hari ? 'selected' : '' }}>
                                {{ $hari }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Tahun Ajaran</label>
                    <input type="text" name="tahun_ajaran" class="form-control"
                        value="{{ $piket->tahun_ajaran }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Semester</label>
                    <select name="semester" class="form-select">
                        <option value="Ganjil" {{ $piket->semester=='Ganjil' ? 'selected' : '' }}>Ganjil</option>
                        <option value="Genap" {{ $piket->semester=='Genap' ? 'selected' : '' }}>Genap</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save me-1"></i> Update
            </button>

        </form>

    </div>
</div>

@endsection