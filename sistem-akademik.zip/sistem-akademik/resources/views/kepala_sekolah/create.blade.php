@extends('layouts.app')

@section('page-title', 'Tambah Guru Piket')

@section('content')

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Pembagian Guru Piket</h5>
        <a href="{{ route('kepala_sekolah.pembagian-guru-piket.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
<div class="container">
    <form action="{{ route('kepala_sekolah.pembagian-guru-piket.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label class="form-label">Guru</label>
            <select name="guru_id" class="form-select" required>
                <option value="">-- Pilih Guru --</option>
                @foreach($guru as $g)
                    <option value="{{ $g->id }}">
                        {{ $g->nama }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Hari</label>
            <select name="hari" class="form-select" required>
                <option value="">Pilih Hari</option>
                <option value="Senin">Senin</option>
                <option value="Selasa">Selasa</option>
                <option value="Rabu">Rabu</option>
                <option value="Kamis">Kamis</option>
                <option value="Jumat">Jumat</option>
                <option value="Sabtu">Sabtu</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Tahun Ajaran</label>
            <input type="text"
                   name="tahun_ajaran"
                   class="form-control"
                   placeholder="2026/2027"
                   value="2026/2027"
                   required>
        </div>
        <div class="mb-3">
            <label class="form-label">Semester</label>
            <select name="semester" class="form-select" required>
                <option value="">Pilih Semester</option>
                <option value="1">Semester 1</option>
                <option value="2">Semester 2</option>
            </select>
        </div>

        <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
            
        </div>
    </form>
</div>
@endsection