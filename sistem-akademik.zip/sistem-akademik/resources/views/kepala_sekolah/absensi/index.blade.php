@extends('layouts.app')

@section('page-title', 'Absensi Siswa')

@section('content')

<div class="card mb-3">
    <div class="card-header">
        <h5 class="mb-0">Data Absensi Siswa</h5>
        <small class="text-muted">Absensi siswa berdasarkan kelas.</small>
    </div>
    <div class="card-body">
        <form method="GET" action="{{ route('kepala_sekolah.absensi.index') }}">
            <div class="row">
                <div class="col-md-4">
                    <label class="form-label">Pilih Kelas</label>
                    <select name="kelas_id" class="form-select">
                        <option value="">-- Pilih Kelas --</option>
                        @foreach($kelas as $k)
                            <option value="{{ $k->id }}"
                                {{ request('kelas_id') == $k->id ? 'selected' : '' }}>
                                {{ $k->nama_kelas }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button class="btn btn-primary">Tampilkan</button>
                </div>
            </div>
        </form>
    </div>
</div>

@if(request('kelas_id'))
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Daftar Absensi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($data as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->siswa->nama ?? '-' }}</td>
                        <td>{{ $item->absensi->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $item->absensi->guru->nama ?? '-' }}</td>
                        <td>{{ $item->absensi->tanggal }}</td>
                        <td>
                            @if($item->status_kehadiran == 'Hadir')
                                <span class="badge bg-success">Hadir</span>
                            @elseif($item->status_kehadiran == 'Izin')
                                <span class="badge bg-info">Izin</span>
                            @elseif($item->status_kehadiran == 'Sakit')
                                <span class="badge bg-warning text-dark">Sakit</span>
                            @else
                                <span class="badge bg-danger">Alpa</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">Tidak ada data absensi.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endif

@endsection