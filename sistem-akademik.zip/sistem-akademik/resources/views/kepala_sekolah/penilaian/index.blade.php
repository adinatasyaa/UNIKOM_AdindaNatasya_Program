@extends('layouts.app')

@section('page-title', 'Penilaian')

@section('content')

<div class="container-fluid">

    <div class="mb-3">
        <h4>Data Penilaian</h4>
        <p class="text-muted">
            Nilai siswa berdasarkan kelas.
        </p>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            <form method="GET"
                  action="{{ route('kepala_sekolah.penilaian.index') }}">
                <div class="row">
                    <div class="col-md-4">
                        <label>Pilih Kelas</label>
                        <select name="kelas_id" class="form-select">
                            <option value="">-- Pilih Kelas --</option>

                            @foreach($kelas as $k)
                                <option value="{{ $k->id }}"
                                    {{ request('kelas_id')==$k->id ? 'selected' : '' }}>
                                    {{ $k->nama_kelas }}
                                </option>
                            @endforeach

                        </select>
                    </div>
                    <div class="col-md-2 align-self-end">

                        <button class="btn btn-primary">
                            Tampilkan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    @if(request('kelas_id'))
    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Daftar Penilaian</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">
                <tr class="text-center">
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Mata Pelajaran</th>
                    <th>Guru</th>
                    <th>Nilai</th>
                    <th>Predikat</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>

                @forelse($data as $item)

                <tr>
                    <td class="text-center">{{ $loop->iteration }}</td>
                    <td>{{ $item->siswa->nama ?? '-' }}</td>
                    <td>{{ $item->mataPelajaran->nama_mapel ?? '-' }}</td>
                    <td>{{ $item->guru->nama ?? '-' }}</td>
                    <td class="text-center fw-bold">{{ $item->nilai_akhir }}</td>
                    <td class="text-center">
                        <div class="d-flex flex-column align-items-center gap-1">
                            <span class="fw-bold">{{ $item->predikat }}</span>
                            <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                {{ $item->keterangan }}
                            </span>
                        </div>
                    </td>
                    <td class="text-center">
                        @if($item->status=='aktif')
                            <span class="badge bg-success">
                                Aktif
                            </span>
                        @else
                            <span class="badge bg-secondary">
                                {{ ucfirst($item->status) }}
                            </span>
                        @endif
                    </td>
                </tr>

                @empty
                <tr>
                    <td colspan="7" class="text-center py-4">
                        Tidak ada data penilaian.
                    </td>
                </tr>

                @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @endif
</div>
@endsection