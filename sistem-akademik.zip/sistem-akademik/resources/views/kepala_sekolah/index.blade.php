@extends('layouts.app')

@section('page-title', 'Pembagian Guru Piket')

@section('content')

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Pembagian Guru Piket</h5>

        <a href="{{ route('kepala_sekolah.pembagian-guru-piket.create') }}"
           class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i>
            Tambah Guru Piket
        </a>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Guru</th>
                    <th>Hari</th>
                    <th>Tahun Ajaran</th>
                    <th>Semester</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($data as $item)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $item->guru->nama }}</td>
                    <td>{{ $item->hari }}</td>
                    <td>{{ $item->tahun_ajaran }}</td>
                    <td>{{ $item->semester }}</td>
                    <td class="text-center text-nowrap">
                        <a href="{{ route('kepala_sekolah.pembagian-guru-piket.edit', $item->id) }}"
                           class="btn btn-warning btn-sm"
                           title="Edit">
                            <i class="bi bi-pencil-square"></i>
                        </a>

                        <form action="{{ route('kepala_sekolah.pembagian-guru-piket.destroy', $item->id) }}"
                              method="POST"
                              class="d-inline"
                              onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                    class="btn btn-danger btn-sm"
                                    title="Hapus">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="text-center">
                        Belum ada pembagian guru piket.
                    </td>
                </tr>
                @endforelse
            </tbody>

        </table>
    </div>
</div>
@endsection