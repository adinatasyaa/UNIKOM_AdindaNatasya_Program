@extends('layouts.app')

@section('page-title', 'Jadwal Mata Pelajaran')

@section('content')

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Approval Jadwal Mata Pelajaran</h5>
    </div>

<div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="text-nowrap">No</th>
                    <th class="text-nowrap">Kelas</th>
                    <th class="text-nowrap">Mata Pelajaran</th>
                    <th class="text-nowrap">Guru</th>
                    <th class="text-nowrap">Hari</th>
                    <th class="text-nowrap">Jam</th>
                    <th class="text-nowrap">Tahun Ajaran</th>
                    <th class="text-nowrap">Semester</th>
                    <th class="text-nowrap">Status</th>
                    <th class="text-nowrap">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($jadwal as $item)
                <tr>
                   <td>{{ $jadwal->firstItem() + $loop->index }}</td>
                    <td>{{ $item->kelas->nama_kelas }}</td>
                    <td>{{ $item->mataPelajaran->nama_mapel }}</td>
                    <td>{{ $item->guru->nama }}</td>
                    <td>{{ $item->hari }}</td>
                    <td>
                        @php
                            $mulai = \Carbon\Carbon::parse($item->jam_mulai);
                            $selesai = \Carbon\Carbon::parse($item->jam_selesai);
                            $menit = $mulai->diffInMinutes($selesai);
                            $jam = intdiv($menit, 60);
                            $sisaMenit = $menit % 60;

                            $durasi = '';
                            if ($jam > 0) {
                                $durasi .= $jam . ' jam ';
                            }
                            if ($sisaMenit > 0) {
                                $durasi .= $sisaMenit . ' menit';
                            }
                        @endphp
                        {{ trim($durasi) }}
                    </td>
                    <td>{{ $item->tahun_ajaran }}</td>
                    <td>
                        @if($item->semester == 1)
                            Ganjil
                        @else
                            Genap
                        @endif
                    </td>
                    <td>
                        @if($item->status == 'draft')
                            <span class="badge bg-secondary">
                                Draft
                            </span>
                        @elseif($item->status == 'menunggu_persetujuan')
                            <span class="badge bg-warning text-dark">
                                Menunggu Persetujuan
                            </span>
                        @elseif($item->status == 'disetujui')
                            <span class="badge bg-success">
                                Disetujui
                            </span>
                        @else
                            <span class="badge bg-danger">
                                Ditolak
                            </span>
                        @endif
                    </td>
                    <td>
                        @if($item->status == 'menunggu_persetujuan')

                            <form action="{{ route('kepala_sekolah.jadwal.setujui', $item->id) }}"method="POST"
                                class="mb-2">
                              @csrf
                              <button type="submit" class="btn btn-success btn-sm w-100">
                                Setujui
                              </button>
                            </form>

                            <form action="{{ route('kepala_sekolah.jadwal.tolak', $item->id) }}"method="POST">
                              @csrf
                              <button type="submit" class="btn btn-danger btn-sm w-100">
                                Tolak
                              </button>
                            </form>

                               @else
        
                               @endif
                </td>
                </tr>
                @empty
                <tr>
                    <td colspan="9" class="text-center">
                        Belum ada data jadwal mata pelajaran.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
        <div class="mt-3">
            {{ $jadwal->links('pagination::bootstrap-5') }}
        </div>
    </div>
</div>
@endsection