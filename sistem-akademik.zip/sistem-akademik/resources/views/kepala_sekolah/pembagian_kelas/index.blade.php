@extends('layouts.app')

@section('page-title','Approval Pembagian Kelas')

@section('content')

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif

    <div class="card">

    <div class="card-header">
        <h5>Approval Pembagian Kelas</h5>
    </div>

    <div class="card-body">
        <table class="table table-bordered">

    <thead>
        <tr>
            <th>No</th>
            <th>Kelas</th>
            <th>Wali Kelas</th>
            <th>Tahun Ajaran</th>
            <th>Semester</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

    </thead>

    <tbody>

    @forelse($data as $item)

    <tr>

        <td>{{ $loop->iteration }}</td>
        <td>{{ $item->kelas->nama_kelas }}</td>
        <td>{{ $item->guru->nama }}</td>
        <td>{{ $item->tahun_ajaran }}</td>
        <td>{{ $item->semester }}</td>
    <td>

    @if($item->status_persetujuan=='menunggu')
    <span class="badge bg-warning">
        Menunggu Persetujuan
    </span>

    @elseif($item->status_persetujuan=='disetujui')
    <span class="badge bg-success">
        Disetujui
    </span>
    @else

    <span class="badge bg-danger">
        Ditolak
    </span>

    @endif
</td>
    <td>

    @if($item->status_persetujuan=='menunggu')

    <form action="{{ route('kepala_sekolah.pembagian-kelas.setujui',$item->id) }}"method="POST"class="d-inline">

    @csrf

        <button class="btn btn-success btn-sm">
            Setujui
        </button>

    </form>

    <form action="{{ route('kepala_sekolah.pembagian-kelas.tolak',$item->id) }}"method="POST"class="d-inline">

    @csrf

        <button class="btn btn-danger btn-sm">
            Tolak
        </button>

    </form>

    @else

    @endif

    </td>

    </tr>

    @empty

    <tr>

        <td colspan="7" class="text-center">
            Belum ada data.
    </td>
</tr>
    @endforelse
    </tbody>
</table>
</div>
</div>
@endsection