@extends('layouts.app')

@section('page-title', 'Data Kelas')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Kelas</h5>

        <a href="{{ route('operator.kelas.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Tambah Kelas
        </a>
    </div>

    <div class="card-body">

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <form action="{{ route('operator.kelas.index') }}" method="GET" class="mb-3">
            <div class="input-group" style="max-width: 350px;">
                <input type="text" name="search" class="form-control"
                    placeholder="Cari nama kelas, atau wali kelas..." value="{{ request('search') }}">
                <button class="btn btn-outline-secondary" type="submit">
                    <i class="bi bi-search"></i>
                </button>
                @if(request('search'))
                    <a href="{{ route('operator.kelas.index') }}" class="btn btn-outline-danger">
                        <i class="bi bi-x"></i>
                    </a>
                @endif
            </div>
</form>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>Nama Kelas</th>
                        <th>Tingkat</th>
                        <th>Tahun Ajaran</th>
                        <th>Wali Kelas</th>
                        <th>Status</th>
                        <th width="120">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($kelas as $index => $k)
                    <tr>
                        <td>{{ $kelas->firstItem() + $index }}</td>
                        <td>{{ $k->nama_kelas }}</td>
                        <td>{{ $k->tingkat }}</td>
                        <td>{{ $k->tahun_ajaran }}</td>

                        <td>
                            {{ $k->waliKelas->nama ?? '-' }}
                        </td>

                        <td>
                            <span class="badge {{ $k->status == 'aktif' ? 'bg-success' : 'bg-danger' }}">
                                {{ ucfirst($k->status) }}
                            </span>
                        </td>

                        <td>
                            <div class="d-flex gap-2">
                                <a href="{{ route('operator.kelas.edit', $k) }}" class="btn btn-warning btn-sm">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="{{ route('operator.kelas.destroy', $k) }}" method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus kelas ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Belum ada data kelas
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        {{ $kelas->links('pagination::bootstrap-5') }}

    </div>
</div>
@endsection