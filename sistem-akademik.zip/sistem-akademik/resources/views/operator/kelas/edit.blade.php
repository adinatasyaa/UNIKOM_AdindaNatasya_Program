@extends('layouts.app')

@section('page-title', 'Edit Kelas')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Data Kelas</h5>
        <a href="{{ route('operator.kelas.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <form action="{{ route('operator.kelas.update', $kelas) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label class="form-label">Nama Kelas</label>
                <input type="text" name="nama_kelas"
                    class="form-control @error('nama_kelas') is-invalid @enderror"
                    value="{{ old('nama_kelas', $kelas->nama_kelas) }}"
                    required>
                @error('nama_kelas')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Tingkat</label>
                <select name="tingkat" class="form-select" required>
                    <option value="7" {{ $kelas->tingkat == '7' ? 'selected' : '' }}>7</option>
                    <option value="8" {{ $kelas->tingkat == '8' ? 'selected' : '' }}>8</option>
                    <option value="9" {{ $kelas->tingkat == '9' ? 'selected' : '' }}>9</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Tahun Ajaran</label>
                <input type="text" name="tahun_ajaran" class="form-control"
                    value="{{ old('tahun_ajaran', $kelas->tahun_ajaran) }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Wali Kelas</label>
                <select name="wali_kelas_id" class="form-select">
                    <option value="">-- Pilih Wali Kelas --</option>
                    @foreach($guru as $g)
                        <option value="{{ $g->id }}"
                            {{ $kelas->wali_kelas_id == $g->id ? 'selected' : '' }}>
                            {{ $g->nama }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select" required>
                    <option value="aktif" {{ $kelas->status == 'aktif' ? 'selected' : '' }}>Aktif</option>
                    <option value="tidak_aktif" {{ $kelas->status == 'tidak_aktif' ? 'selected' : '' }}>Tidak Aktif</option>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Update
                </button>
                <a href="{{ route('operator.kelas.index') }}" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
@endsection