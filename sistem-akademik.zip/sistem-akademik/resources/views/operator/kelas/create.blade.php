@extends('layouts.app')

@section('page-title', 'Tambah Kelas')

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Tambah Data Kelas</h5>
    </div>

    <div class="card-body">
        <form action="{{ route('operator.kelas.store') }}" method="POST">
            @csrf

            <div class="mb-3">
                <label class="form-label">Nama Kelas</label>
                <input type="text" name="nama_kelas"
                    class="form-control @error('nama_kelas') is-invalid @enderror"
                    value="{{ old('nama_kelas') }}" required>

                @error('nama_kelas')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Tingkat</label>
                <select name="tingkat"
                    class="form-select @error('tingkat') is-invalid @enderror"
                    required>
                    <option value="">-- Pilih Tingkat --</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                </select>

                @error('tingkat')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Tahun Ajaran</label>
                <input type="text" name="tahun_ajaran"
                    class="form-control @error('tahun_ajaran') is-invalid @enderror"
                    placeholder="2026/2027"
                    value="{{ old('tahun_ajaran') }}"
                    required>

                @error('tahun_ajaran')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Wali Kelas</label>
                <select name="wali_kelas_id"
                    class="form-select">
                    <option value="">-- Pilih Wali Kelas --</option>

                    @foreach($guru as $g)
                        <option value="{{ $g->id }}">
                            {{ $g->nama }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Status</label>

                <select name="status"
                    class="form-select"
                    required>
                    <option value="aktif">Aktif</option>
                    <option value="tidak_aktif">Tidak Aktif</option>
                </select>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    Simpan
                </button>

                <a href="{{ route('operator.kelas.index') }}"
                    class="btn btn-secondary">
                    Kembali
                </a>
            </div>

        </form>
    </div>
</div>
@endsection