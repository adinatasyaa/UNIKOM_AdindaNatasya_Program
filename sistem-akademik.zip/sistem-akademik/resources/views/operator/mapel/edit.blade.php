@extends('layouts.app')

@section('page-title', 'Edit Mata Pelajaran')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Mata Pelajaran</h5>

        <a href="{{ route('operator.mapel.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('operator.mapel.update', $mapel) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Kode Mata Pelajaran <span class="text-danger">*</span></label>
                    <input type="text" name="kode_mapel" class="form-control"
                        value="{{ old('kode_mapel', $mapel->kode_mapel) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nama Mata Pelajaran <span class="text-danger">*</span></label>
                    <input type="text" name="nama_mapel" class="form-control"
                        value="{{ old('nama_mapel', $mapel->nama_mapel) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Guru Pengampu</label>
                    <select name="guru_id" class="form-select">
                        <option value="">-- Pilih Guru --</option>
                        @foreach($guru as $g)
                            <option value="{{ $g->id }}"
                                {{ old('guru_id', $mapel->guru_id) == $g->id ? 'selected' : '' }}>
                                {{ $g->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>
               <div class="col-md-6">
                    <label class="form-label">Alokasi Waktu</label>
                    <div class="input-group">
                        <input type="text" class="form-control" value="{{ $mapel->alokasi_waktu }}" disabled>
                        <span class="input-group-text">jam/minggu</span>
                    </div>
                        <small class="text-muted">Diatur oleh Wakasek Kurikulum, tidak dapat diubah di sini.</small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status <span class="text-danger">*</span></label>
                    <select name="status" class="form-select" required>
                        <option value="aktif" {{ old('status', $mapel->status) == 'aktif' ? 'selected' : '' }}>Aktif</option>
                        <option value="tidak_aktif" {{ old('status', $mapel->status) == 'tidak_aktif' ? 'selected' : '' }}>Tidak Aktif</option>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Update
                </button>
                <a href="{{ route('operator.mapel.index') }}" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
@endsection