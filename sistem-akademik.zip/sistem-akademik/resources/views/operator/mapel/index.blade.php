@extends('layouts.app')

@section('page-title', 'Data Mata Pelajaran')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Mata Pelajaran</h5>

        <a href="{{ route('operator.mapel.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Tambah Mata Pelajaran
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <form action="{{ route('operator.mapel.index') }}" method="GET" class="mb-3">
            <div class="input-group" style="max-width: 350px;">
                <input type="text" name="search" class="form-control"
                    placeholder="Cari kode, nama mapel, atau guru..." value="{{ request('search') }}">
                <button class="btn btn-outline-secondary" type="submit">
                    <i class="bi bi-search"></i>
                </button>
                @if(request('search'))
                    <a href="{{ route('operator.mapel.index') }}" class="btn btn-outline-danger">
                        <i class="bi bi-x"></i>
                    </a>
                @endif
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama Mata Pelajaran</th>
                        <th>Guru Pengampu</th>
                        <th>Alokasi Waktu</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($mapel as $index => $m)
                    <tr>
                        <td>{{ $mapel->firstItem() + $index }}</td>
                        <td>{{ $m->kode_mapel }}</td>
                        <td>{{ $m->nama_mapel }}</td>
                        <td>{{ optional($m->guru)->nama ?? '-' }}</td>
                        <td>{{ $m->alokasi_waktu }} jam/minggu</td>
                        <td>
                            <span class="badge {{ $m->status == 'aktif' ? 'bg-success' : 'bg-danger' }}">
                                {{ ucfirst($m->status) }}
                            </span>
                        </td>
                       <td>
                            <div class="d-flex gap-2">
                                <a href="{{ route('operator.mapel.edit', $m) }}" class="btn btn-warning btn-sm">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="{{ route('operator.mapel.destroy', $m) }}" method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus mata pelajaran ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data mata pelajaran</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $mapel->links('pagination::bootstrap-5') }}
    </div>
</div>
@endsection