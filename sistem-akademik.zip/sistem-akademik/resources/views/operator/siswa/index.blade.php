@extends('layouts.app')

@section('page-title', 'Data Siswa')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Siswa</h5>
        <div class="d-flex gap-2">
           
            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#importModal">
                <i class="bi bi-file-earmark-excel me-1"></i> Import Excel
            </button>
           
            <a href="{{ route('operator.siswa.create') }}" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Tambah Siswa
            </a>
        </div>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <form action="{{ route('operator.siswa.index') }}" method="GET" class="mb-3">
    <div class="input-group" style="max-width: 350px;">
        <input type="text" name="search" class="form-control"
               placeholder="Cari NIS atau Nama..." value="{{ request('search') }}">
        <button class="btn btn-outline-secondary" type="submit">
            <i class="bi bi-search"></i>
        </button>
        @if(request('search'))
            <a href="{{ route('operator.siswa.index') }}" class="btn btn-outline-danger">
                <i class="bi bi-x"></i>
            </a>
        @endif
    </div>
</form>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                        <tr>
                            <th class="text-nowrap">No</th>
                            <th class="text-nowrap">NIS</th>
                            <th class="text-nowrap">Nama</th>
                            <th class="text-nowrap">Kelas</th>
                            <th class="text-nowrap">Jenis Kelamin</th>
                            <th class="text-nowrap">Email</th>
                            <th class="text-nowrap">Tanggal Lahir</th>
                            <th class="text-nowrap">Tempat Lahir</th>
                            <th class="text-nowrap">Status</th>
                            <th class="text-nowrap">Aksi</th>
                        </tr>
                    </thead>
                </thead>
                <tbody>
                    @forelse($siswa as $index => $s)
                    <tr>
                        <td>{{ $siswa->firstItem() + $index }}</td>
                        <td>{{ $s->nis ?? '-' }}</td>
                        <td>{{ $s->nama }}</td>
                        <td>{{ $s->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $s->jenis_kelamin == 'L' ? 'Laki-laki' : ($s->jenis_kelamin == 'P' ? 'Perempuan' : '-') }}</td>
                        <td>{{ $s->email ?? '-' }}</td>
                        <td>{{ $s->tanggal_lahir ?? '-' }}</td>
                        <td>{{ $s->tempat_lahir ?? '-' }}</td>

                        <td>
                            <span class="badge {{ $s->status == 'aktif' ? 'bg-success' : 'bg-danger' }}">
                                {{ ucfirst($s->status) }}
                            </span>
                        </td>

                        <td>
                            <div class="d-flex gap-2">
                                <a href="{{ route('operator.siswa.edit', $s->id) }}" class="btn btn-warning btn-sm">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="{{ route('operator.siswa.destroy', $s->id) }}" method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="10" class="text-center text-muted">Belum ada data siswa</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
         {{ $siswa->links('pagination::bootstrap-5') }}
    </div>
</div>

<div class="modal fade" id="importModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Import Data Siswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('operator.siswa.import') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-1"></i>
                        Format kolom Excel: <strong>nis, nama, nama_kelas, jenis_kelamin, tempat_lahir, tanggal_lahir, email, status, spmb_id</strong>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Pilih File Excel</label>
                        <input type="file" name="file" class="form-control" accept=".xlsx,.xls" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-upload me-1"></i> Import
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection