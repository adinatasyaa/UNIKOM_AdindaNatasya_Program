@extends('layouts.app')

@section('page-title', 'Tambah Guru')

@section('content')

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Tambah Data Guru</h5>
    </div>

    <div class="card-body">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('operator.guru.store') }}" method="POST">
            @csrf

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">NIP</label>
                    <input type="text"
                           name="nip"
                           class="form-control"
                           value="{{ old('nip') }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Guru <span class="text-danger">*</span></label>
                    <input type="text"
                           name="nama"
                           class="form-control"
                           value="{{ old('nama') }}"
                           required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Jenis Kelamin</label>

                    <select name="jenis_kelamin" class="form-select">
                        <option value="">-- Pilih --</option>

                        <option value="L"
                            {{ old('jenis_kelamin') == 'L' ? 'selected' : '' }}>
                            Laki-laki
                        </option>

                        <option value="P"
                            {{ old('jenis_kelamin') == 'P' ? 'selected' : '' }}>
                            Perempuan
                        </option>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">No Telepon</label>

                    <input type="text"
                           name="no_telp"
                           class="form-control"
                           value="{{ old('no_telp') }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>

                    <input type="email"
                           name="email"
                           class="form-control"
                           value="{{ old('email') }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Role</label>

                    <select name="role" class="form-select" required>

                        <option value="">-- Pilih Role --</option>

                        <option value="guru"
                            {{ old('role') == 'guru' ? 'selected' : '' }}>
                            Guru
                        </option>

                        <option value="wali_kelas"
                            {{ old('role') == 'wali_kelas' ? 'selected' : '' }}>
                            Wali Kelas
                        </option>

                         <option value="kepala_sekolah"
                            {{ old('role') == 'kepala_sekolah' ? 'selected' : '' }}>
                            Kepala Sekolah
                        </option>

                        <option value="wakasek_kurikulum"
                            {{ old('role') == 'wakasek_kurikulum' ? 'selected' : '' }}>
                            Wakasek Kurikulum
                        </option>

                        <option value="wakasek_kesiswaan"
                            {{ old('role') == 'wakasek_kesiswaan' ? 'selected' : '' }}>
                            Wakasek Kesiswaan
                        </option>

                        <option value="operator"
                            {{ old('role') == 'operator' ? 'selected' : '' }}>
                            Operator
                        </option>

                        <option value="guru_piket"
                            {{ old('role') == 'guru_piket' ? 'selected' : '' }}>
                            Guru Piket
                        </option>

                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Status</label>

                    <select name="status" class="form-select">

                        <option value="aktif"
                            {{ old('status') == 'aktif' ? 'selected' : '' }}>
                            Aktif
                        </option>

                        <option value="tidak_aktif"
                            {{ old('status') == 'tidak_aktif' ? 'selected' : '' }}>
                            Tidak Aktif
                        </option>

                    </select>
                </div>

            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i>
                    Simpan
                </button>

                <a href="{{ route('operator.guru.index') }}"
                   class="btn btn-secondary">
                    Kembali
                </a>
            </div>

        </form>

    </div>
</div>

@endsection