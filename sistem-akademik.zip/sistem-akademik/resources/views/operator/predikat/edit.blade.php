@extends('layouts.app')

@section('page-title', 'Edit Predikat')

@section('content')
<div class="card">

    <div class="card-header">
        <h5 class="mb-0">Edit Predikat</h5>
    </div>

    <div class="card-body">

        <form action="{{ route('operator.predikat.update', $predikat->id) }}"
              method="POST">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label">Predikat</label>
                <input type="text"
                       name="predikat"
                       class="form-control"
                       value="{{ $predikat->predikat }}"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nilai Minimum</label>
                <input type="number"
                       name="nilai_min"
                       class="form-control"
                       value="{{ $predikat->nilai_min }}"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nilai Maksimum</label>
                <input type="number"
                       name="nilai_max"
                       class="form-control"
                       value="{{ $predikat->nilai_max }}"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Keterangan</label>
                <select name="keterangan" class="form-control form-select" required>
                    <option value="Sangat Baik" {{ $predikat->keterangan == 'Sangat Baik' ? 'selected' : '' }}>Sangat Baik</option>
                    <option value="Baik" {{ $predikat->keterangan == 'Baik' ? 'selected' : '' }}>Baik</option>
                    <option value="Cukup" {{ $predikat->keterangan == 'Cukup' ? 'selected' : '' }}>Cukup</option>
                    <option value="Perlu Bimbingan" {{ $predikat->keterangan == 'Perlu Bimbingan' ? 'selected' : '' }}>Perlu Bimbingan</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                Update
            </button>

            <a href="{{ route('operator.predikat.index') }}"
               class="btn btn-secondary">
                Kembali
            </a>

        </form>

    </div>
</div>
@endsection