@extends('layouts.app')

@section('page-title', 'Daftar Siswa Registrasi')

@section('sidebar')
<a href="{{ route('kesiswaan.dashboard') }}" class="nav-link {{ request()->routeIs('kesiswaan.dashboard') ? 'active' : '' }}">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="{{ route('kesiswaan.registrasi.index') }}" class="nav-link {{ request()->routeIs('kesiswaan.registrasi.*') ? 'active' : '' }}">
    <i class="bi bi-person-lines-fill me-2"></i> Daftar Siswa Registrasi
</a>
<a href="{{ route('kesiswaan.pembagian.index') }}" class="nav-link {{ request()->routeIs('kesiswaan.pembagian.*') ? 'active' : '' }}">
    <i class="bi bi-people me-2"></i> Pembagian Kelas
</a>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Daftar Siswa Registrasi</h5>
        <small class="text-muted">Siswa hasil konfirmasi pendaftaran SPMB. Lengkapi NIS sebelum pembagian kelas.</small>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger">{{ $errors->first() }}</div>
        @endif

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                </tr>
            </thead>
            <tbody>
                @forelse($siswa as $index => $s)
                <tr>
                    <td>{{ $siswa->firstItem() + $index }}</td>
                    <td>
                        <form action="{{ route('kesiswaan.registrasi.update_nis', $s->id) }}" method="POST" class="d-flex gap-2">
                            @csrf
                            @method('PUT')
                            <input type="text" name="nis" class="form-control form-control-sm" style="width: 130px;" value="{{ $s->nis }}" placeholder="Isi NIS" required>
                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                        </form>
                    </td>
                    <td>{{ $s->nama }}</td>
                    <td>{{ $s->kelas->nama_kelas ?? '-' }}</td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center text-muted">Belum ada siswa dari hasil registrasi SPMB</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $siswa->links('pagination::bootstrap-5') }}
    </div>
</div>
@endsection