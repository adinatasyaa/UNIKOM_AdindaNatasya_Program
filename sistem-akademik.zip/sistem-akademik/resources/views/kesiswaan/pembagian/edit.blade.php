@extends('layouts.app')

@section('page-title', 'Edit Pembagian Kelas')

@section('content')
<div class="container py-4">
    <div class="card shadow-sm mx-auto" style="max-width: 500px;">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0">Edit Wali Kelas: {{ $pembagianKelas->kelas->nama_kelas }}</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('kesiswaan.pembagian.update', $pembagianKelas->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="mb-3">
                    <label class="form-label fw-bold">Pilih Wali Kelas Baru</label>
                    <select class="form-select" name="guru_id" required>
                        @foreach($daftarGuru as $g)
                            <option value="{{ $g->id }}" {{ $pembagianKelas->guru_id == $g->id ? 'selected' : '' }}>{{ $g->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="d-flex gap-2">
                    <a href="{{ route('kesiswaan.pembagian.index') }}" class="btn btn-secondary w-50">Batal</a>
                    <button type="submit" class="btn btn-warning w-50">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection