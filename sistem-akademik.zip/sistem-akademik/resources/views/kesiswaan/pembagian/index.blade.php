@extends('layouts.app')

@section('page-title', 'Pembagian Kelas')

@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Pembagian Kelas Siswa</h4>
        <a href="{{ route('kesiswaan.pembagian.create') }}" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Tambah Pembagian Siswa
            </a>
    </div>

    @if(session('success')) 
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    @endif

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tahun / Semester</th>
                        <th>Kelas</th>
                        <th>Wali Kelas</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($riwayatPembagian as $rp)
                    <tr>
                        <td>{{ $rp->tahun_ajaran }} / {{ $rp->semester }}</td>
                        <td><strong>{{ $rp->kelas->nama_kelas ?? 'Kelas Tidak Ditemukan' }}</strong></td>
                        <td>{{ $rp->guru->nama ?? 'Belum Ditunjuk' }}</td>
                        <td>
                            @if($rp->status_persetujuan == 'menunggu') 
                                <span class="badge bg-warning text-dark">Menunggu</span>
                            @elseif($rp->status_persetujuan == 'disetujui') 
                                <span class="badge bg-success">Disetujui</span>
                            @else 
                                <span class="badge bg-danger">Ditolak</span> 
                            @endif
                        </td>
                        <td class="text-center text-nowrap">

                            <a href="{{ route('kesiswaan.pembagian.show', $rp->id) }}"
                               class="btn btn-info btn-sm"
                               title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>

                            <a href="{{ route('kesiswaan.pembagian.edit', $rp->id) }}"
                               class="btn btn-warning btn-sm"
                               title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>

                            <form action="{{ route('kesiswaan.pembagian.destroy', $rp->id) }}"
                                  method="POST"
                                  class="d-inline">
                                @csrf
                                @method('DELETE')

                                <button type="submit"
                                        class="btn btn-danger btn-sm"
                                        onclick="return confirm('Yakin ingin menghapus?')"
                                        title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">Belum ada data pembagian kelas.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection