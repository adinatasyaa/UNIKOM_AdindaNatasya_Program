@extends('layouts.app')

@section('page-title', 'Detail Pembagian Kelas')

@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Daftar Siswa Kelas {{ $pembagianKelas->kelas->nama_kelas }}</h4>
        <a href="{{ route('kesiswaan.pembagian.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        @if($pembagianKelas->jenis !== 'siswa_baru')
                        <th>Rata-Rata Nilai</th>
                        <th>Kategori</th>
                        @endif
                        <th class="text-center">Pindah Kelas</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($daftarSiswa as $index => $ds)
                    @php
                        $nilai = $rataRataNilai[$ds->siswa_id] ?? null;
                        $kategori = '-';
                        $badgeClass = 'secondary';
                        if ($nilai !== null) {
                            if ($nilai >= 80) { $kategori = 'High'; $badgeClass = 'success'; }
                            elseif ($nilai >= 65) { $kategori = 'Medium'; $badgeClass = 'warning'; }
                            else { $kategori = 'Low'; $badgeClass = 'danger'; }
                        }
                    @endphp
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td><strong>{{ $ds->siswa->nama }}</strong></td>
                        @if($pembagianKelas->jenis !== 'siswa_baru')
                        <td>{{ $nilai ?? 'Belum ada nilai' }}</td>
                        <td><span class="badge bg-{{ $badgeClass }}">{{ $kategori }}</span></td>
                        @endif
                        <td>
                            <form action="{{ route('kesiswaan.pembagian.pindah', $ds->id) }}" method="POST" class="d-flex justify-content-center gap-2">
                                @csrf
                                <select class="form-select form-select-sm" name="kelas_baru_id" style="max-width: 180px;" required>
                                    <option value="">-- Pindahkan Ke --</option>
                                    @foreach($kelasLain as $kl)
                                        <option value="{{ $kl->id }}">Kelas {{ $kl->nama_kelas }}</option>
                                    @endforeach
                                </select>
                                <button type="submit" class="btn btn-sm btn-warning">Pindah</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="{{ $pembagianKelas->jenis !== 'siswa_baru' ? 5 : 3 }}" class="text-center py-4">Belum ada siswa di kelas ini.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection