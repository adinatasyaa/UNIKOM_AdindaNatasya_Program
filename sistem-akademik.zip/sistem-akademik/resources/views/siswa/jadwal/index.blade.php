@extends('layouts.app')

@section('page-title', 'Jadwal Mata Pelajaran')

@section('content')

<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h4>Jadwal Mata Pelajaran</h4>
            <p class="text-muted">
                Jadwal mata pelajaran sesuai kelas yang telah ditetapkan sekolah.
            </p>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('success') }}

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>
        </div>
    @endif

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Jadwal Pelajaran</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Hari</th>
                        <th>Jam</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Kelas</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                    </tr>
                </thead>
                <tbody>

                @forelse($jadwal as $item)
                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td>{{ $item->hari }}</td>
                        <td>{{ \Carbon\Carbon::parse($item->jam_mulai)->format('H.i') }} - {{ \Carbon\Carbon::parse($item->jam_selesai)->format('H.i') }}</td>
                        <td>{{ $item->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $item->guru->nama ?? '-' }}</td>
                        <td>{{ $item->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $item->tahun_ajaran }}</td>
                        <td>{{ $item->semester }}</td>
                    </tr>
                @empty

                    <tr>
                        <td colspan="8"
                            class="text-center py-4 text-muted">
                            Jadwal pelajaran belum tersedia.
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection