@extends('layouts.app')

@section('page-title', 'Penilaian')

@section('content')
<div class="container-fluid">

    <div class="mb-3">
        <h4>Data Penilaian</h4>
        <p class="text-muted">
            Daftar nilai yang telah diberikan oleh guru mata pelajaran.
        </p>
    </div>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Daftar Nilai</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th class="text-nowrap">No</th>
                        <th class="text-nowrap">Mata Pelajaran</th>
                        <th class="text-nowrap">Guru</th>
                        <th class="text-nowrap">Tahun Ajaran</th>
                        <th class="text-nowrap">Semester</th>
                        <th class="text-nowrap" style="max-width: 200px;">Nilai Akhir</th>
                        <th class="text-nowrap">Predikat</th>
                        <th class="text-nowrap">Status</th>
                    </tr>
                </thead>

                <tbody>

                @forelse($data as $item)
                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td>{{ $item->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $item->guru->nama ?? '-' }}</td>
                        <td class="text-center">{{ $item->tahun_ajaran }}</td>
                        <td class="text-center">{{ $item->semester }}</td>
                        <td class="text-center fw-bold">{{ $item->nilai_akhir }}</td>
                       <td class="text-center">
                            <div class="d-flex flex-column align-items-center gap-1">
                                <span class="badge bg-primary">{{ $item->predikat }}</span>
                                <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                     {{ $item->keterangan }}
                                </span>
                            </div>
                        </td>
                        <td class="text-center">
                            @if($item->status=='final')
                                <span class="badge bg-success">Final</span>
                            @elseif($item->status=='lengkap')
                                <span class="badge bg-info">Lengkap</span>
                            @else
                                <span class="badge bg-secondary">Belum Lengkap</span>
                            @endif
                        </td>
                    </tr>
                @empty

                    <tr>
                        <td colspan="8" class="text-center py-4">
                            Belum ada data penilaian.
                        </td>
                    </tr>
                @endforelse

                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection