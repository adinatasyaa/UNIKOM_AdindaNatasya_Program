@extends('layouts.app')

@section('page-title', 'Absensi')

@section('content')

<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h4>Riwayat Absensi</h4>
            <p class="text-muted">
                Riwayat kehadiran siswa pada setiap mata pelajaran.
            </p>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('success') }}

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>
        </div>
    @endif

    <div class="card shadow-sm">

        <div class="card-header">
            <strong>Data Absensi</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Tanggal</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Status Kehadiran</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                @forelse($absensi as $item)

                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td>{{ $item->absensi?->tanggal ?? '-' }}</td>
                        <td>{{ $item->absensi?->mataPelajaran?->nama_mapel ?? '-' }}</td>
                        <td>{{ $item->absensi?->guru?->nama ?? '-' }}</td>
                        <td>
                           @if($item->status_kehadiran == 'Hadir')
                                <span class="badge bg-success">Hadir</span>
                           @elseif($item->status_kehadiran == 'Izin')
                                <span class="badge bg-info">Izin</span>
                           @elseif($item->status_kehadiran == 'Sakit')
                                <span class="badge bg-warning text-dark">Sakit</span>
                           @else
                                <span class="badge bg-danger">Alpa</span>
                            @endif
                        </td>
                        <td>{{ $item->keterangan ?? '-' }}</td>
                    </tr>
                @empty

                    <tr>
                        <td colspan="6"
                            class="text-center py-4 text-muted">
                            Belum ada data absensi.
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection