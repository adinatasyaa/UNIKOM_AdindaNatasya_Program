@extends('layouts.app')

@section('page-title', 'Pembagian Kelas')

@section('content')

<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h4>Pembagian Kelas</h4>
            <p class="text-muted">
                Informasi pembagian kelas yang telah ditetapkan oleh sekolah.
            </p>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('success') }}

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>
        </div>
    @endif


    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Data Pembagian Kelas</strong>
        </div>
        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">

                    <tr>
                        <th width="60">No</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                        <th>Kelas</th>
                        <th>Status</th>
                    </tr>

                </thead>
                <tbody>
                @forelse($data as $item)

                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td>{{ $item->tahun_ajaran }}</td>
                        <td>{{ $item->semester }}</td>
                        <td><strong>{{ $item->kelas->nama_kelas ?? '-' }}</strong></td>
                        <td>
                            @if($item->status_pembagian == 'final')
                                <span class="badge bg-success">Final</span>
                            @elseif($item->status_pembagian == 'draft')
                                <span class="badge bg-secondary">Draft</span>
                            @else
                                <span class="badge bg-secondary">{{ ucfirst($item->status_pembagian) }}</span>
                            @endif

                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5"
                            class="text-center py-4 text-muted">
                            Belum ada data pembagian kelas.
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

</div>

@endsection