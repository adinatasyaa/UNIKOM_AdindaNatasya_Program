@extends('layouts.app')

@section('page-title','Jadwal Guru Piket')

@section('content')

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            Jadwal Guru Piket
        </h5>
    </div>

    <div class="card-body p-0">
        <table class="table table-bordered mb-0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Guru</th>
                    <th>Hari</th>
                    <th>Tahun Ajaran</th>
                    <th>Semester</th>
                </tr>
            </thead>

            <tbody>

            @forelse($data as $item)

                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $item->guru->nama }}</td>
                    <td>{{ $item->hari }}</td>
                    <td>{{ $item->tahun_ajaran }}</td>
                    <td>{{ $item->semester }}</td>
                </tr>

            @empty

                <tr>
                    <td colspan="5" class="text-center">
                        Belum ada jadwal guru piket.
                    </td>
                </tr>

            @endforelse

            </tbody>
        </table>
    </div>
</div>

@endsection