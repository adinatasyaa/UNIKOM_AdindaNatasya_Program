@extends('layouts.app')

@section('page-title', 'Absensi Piket')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Absensi Piket</h5>
        <a href="{{ route('guru_piket.absensi.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Input Absensi Piket
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                        <th>Semester</th>
                        <th>Tahun Ajaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($absensi as $index => $a)
                    <tr>
                        <td>{{ $absensi->firstItem() + $index }}</td>
                        <td>{{ \Carbon\Carbon::parse($a->tanggal)->format('d/m/Y') }}</td>
                        <td>{{ $a->nama_siswa ?? '-' }}</td>
                        <td>{{ $a->nama_kelas ?? '-' }}</td>
                        <td>
                            @if($a->status == 'terlambat')
                                <span class="badge bg-warning">Terlambat</span>
                            @elseif($a->status == 'izin_pulang')
                                <span class="badge bg-info">Izin Pulang</span>
                            @elseif($a->status == 'izin')
                                <span class="badge bg-primary">Izin</span>
                            @elseif($a->status == 'tidak_hadir')
                                <span class="badge bg-danger">Tidak Hadir</span>
                            @endif
                        </td>
                        <td>{{ $a->keterangan ?? '-' }}</td>
                        <td>Semester {{ $a->semester }}</td>
                        <td>{{ $a->tahun_ajaran }}</td>
                        <td class="text-center">
                            <div class="d-flex gap-1 justify-content-center">
                                <a href="{{ route('guru_piket.absensi.edit', $a->id) }}" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="{{ route('guru_piket.absensi.destroy', ['id' => $a->id]) }}" method="POST" class="d-inline">
                                    @csrf 
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data absensi ini?')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9" class="text-center text-muted">Belum ada data absensi piket</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $absensi->links('pagination::bootstrap-5') }}
    </div>
</div>
@endsection