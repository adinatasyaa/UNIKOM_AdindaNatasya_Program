@extends('layouts.app')

@section('page-title', 'Edit Absensi Piket')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Absensi Piket</h5>
        <a href="{{ route('guru_piket.absensi.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('guru_piket.absensi.update', $absensi->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Siswa <span class="text-danger">*</span></label>
                    <input type="text" name="nama_siswa" class="form-control"
                        value="{{ old('nama_siswa', $absensi->nama_siswa) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Kelas <span class="text-danger">*</span></label>
                    <input type="text" name="nama_kelas" class="form-control"
                        value="{{ old('nama_kelas', $absensi->nama_kelas) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tanggal <span class="text-danger">*</span></label>
                    <input type="date" name="tanggal" class="form-control"
                        value="{{ old('tanggal', $absensi->tanggal) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status <span class="text-danger">*</span></label>
                    <select name="status" class="form-select" required>
                        <option value="">-- Pilih Status --</option>
                        <option value="terlambat" {{ old('status', $absensi->status) == 'terlambat' ? 'selected' : '' }}>Terlambat</option>
                        <option value="izin_pulang" {{ old('status', $absensi->status) == 'izin_pulang' ? 'selected' : '' }}>Izin Pulang</option>
                        <option value="tidak_hadir" {{ old('status', $absensi->status) == 'tidak_hadir' ? 'selected' : '' }}>Tidak Hadir</option>
                        <option value="izin" {{ old('status') == 'izin' ? 'selected' : '' }}>Izin</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Semester <span class="text-danger">*</span></label>
                    <select name="semester" class="form-select" required>
                        <option value="">-- Pilih Semester --</option>
                        <option value="1" {{ old('semester', $absensi->semester) == '1' ? 'selected' : '' }}>Semester 1</option>
                        <option value="2" {{ old('semester', $absensi->semester) == '2' ? 'selected' : '' }}>Semester 2</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                    <input type="text" name="tahun_ajaran" class="form-control"
                        value="{{ old('tahun_ajaran', $absensi->tahun_ajaran) }}" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="3">{{ old('keterangan', $absensi->keterangan) }}</textarea>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Update
                </button>
                <a href="{{ route('guru_piket.absensi.index') }}" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
@endsection