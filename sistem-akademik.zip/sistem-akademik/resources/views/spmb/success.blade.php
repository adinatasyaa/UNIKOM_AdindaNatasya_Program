<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Pendaftaran Berhasil - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body style="background-color: #f8f9fa;">
    <div class="container py-5">
        <div class="card shadow border-success p-5 mx-auto text-center" style="max-width: 650px;">
            <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
            <h3 class="mt-3 fw-bold">Data Formulir Disetujui!</h3>
            <p class="text-muted mb-1">Selamat, pengisian formulir pendaftaran SPMB milik:</p>
            <h4 class="fw-bold text-primary">{{ $spmb->nama_lengkap }}</h4>
            <p class="text-muted">Asal Sekolah: <strong>{{ $spmb->asal_sekolah }}</strong> telah sukses diverifikasi.</p>

            <hr class="my-4">
            <h5 class="fw-bold text-dark"><i class="bi bi-calendar-event me-2"></i>JADWAL TES FISIK LANGSUNG DI SEKOLAH</h5>
            
            <div class="alert alert-secondary d-inline-block px-4 py-3 my-3 text-start w-100">
                <strong>Hari / Tanggal :</strong> Senin s/d Rabu (Sesuai Gelombang)<br>
                <strong>Waktu Pelaksanaan :</strong> 08.00 WIB - Selesai<br>
                <strong>Lokasi Ujian :</strong> Gedung Utama SMP Labschool UPI Kampus Cibiru
            </div>

            <div class="alert alert-danger text-start small">
                <i class="bi bi-exclamation-triangle-fill me-2"></i><strong>PENTING:</strong> Orang tua wajib mendampingi siswa dan membawa seluruh berkas fisik asli beserta fotokopi (Kartu Keluarga, Akta Kelahiran, Rapor SD) untuk diserahkan ke panitia pendaftaran di lokasi tes.
            </div>

            <div class="d-flex gap-2 justify-content-center mt-3">
                <a href="{{ route('spmb.cek_status') }}" class="btn btn-primary">
                    <i class="bi bi-search me-1"></i> Cek Status Formulir
                </a>
                <a href="{{ route('spmb.index') }}" class="btn btn-secondary">
                    <i class="bi bi-house me-1"></i> Kembali ke Menu
                </a>
            </div>
        </div>
    </div>
</body>
</html>