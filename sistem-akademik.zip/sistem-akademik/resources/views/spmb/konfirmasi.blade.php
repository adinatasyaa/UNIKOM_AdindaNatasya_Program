<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Konfirmasi Pendaftaran SPMB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f6f9; }
        .navbar-custom { background-color: #1a237e; }
        .card-header-custom { background-color: #1a237e; color: white; }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark navbar-custom mb-4">
        <div class="container justify-content-start">
            <a href="{{ route('spmb.index') }}" class="btn btn-outline-light btn-sm me-3">
                <i class="bi bi-arrow-left"></i> Kembali ke Menu Utama
            </a>
            <span class="navbar-brand mb-0 h1 fs-6">Tahap 2: Konfirmasi Data Kelayakan</span>
        </div>
    </nav>

    <div class="container mb-5">
        <div class="row justify-content-center">
            <div class="col-md-8">

                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <div class="card shadow-sm">
                    <div class="card-header card-header-custom py-3">
                        <h5 class="mb-0 fw-bold"><i class="bi bi-shield-check me-2"></i> Verifikasi & Cocokkan Data Anda</h5>
                        <small class="text-white-50">Periksa kembali data Anda di bawah ini, lalu klik Konfirmasi jika sudah benar.</small>
                    </div>
                    <div class="card-body p-4">
                        
                        <form action="{{ route('spmb.submit-konfirmasi') }}" method="POST">
                            @csrf

                            <div class="mb-3">
    							<label for="nama_siswa" class="form-label fw-semibold">Nama Lengkap Calon Murid</label>
    							<input type="text" name="nama_siswa" id="nama_siswa" class="form-control bg-light" value="{{ $pendaftaran->nama_lengkap }}" readonly>
							</div>
							<div class="mb-3">
    							<label for="asal_sekolah" class="form-label fw-semibold">Asal Sekolah SD/MI</label>
    							<input type="text" name="asal_sekolah" id="asal_sekolah" class="form-control bg-light" value="{{ $pendaftaran->asal_sekolah }}" readonly>
							</div>
							<div class="mb-3">
    							<label for="nama_orang_tua" class="form-label fw-semibold">Nama Orang Tua / Wali</label>
    							<input type="text" name="nama_orang_tua" id="nama_orang_tua" class="form-control bg-light" value="{{ $pendaftaran->nama_orang_tua }}" readonly>
							</div>

                            <hr>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success btn-lg fw-bold">
                                    <i class="bi bi-check-all me-1"></i> Konfirmasi 
                                </button>
                            </div>

                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>