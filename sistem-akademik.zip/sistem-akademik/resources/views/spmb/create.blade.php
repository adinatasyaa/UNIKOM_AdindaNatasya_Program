<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Formulir SPMB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark" style="background-color: #0a1050;">
        <div class="container">
            <a href="{{ route('spmb.index') }}" class="navbar-brand fw-bold">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Menu Utama
            </a>
        </div>
    </nav>

    <div class="container py-4">
        <div class="card shadow-sm mx-auto" style="max-width: 800px;">
            <div class="card-header text-white" style="background-color: #0a1050;">
                <h5 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Formulir Pendaftaran SPMB</h5>
                <small>SMP Labschool UPI Kampus Cibiru</small>
            </div>
            <div class="card-body p-4">
               @if(isset($berhasilDaftar))
                    <div class="modal fade" id="modalIdPendaftaran" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content border-0 shadow">
                                <div class="modal-header text-white" style="background-color:#f57f17;">
                                    <h5 class="modal-title fw-bold"><i class="bi bi-exclamation-triangle-fill me-2"></i>WAJIB DICATAT!</h5>
                                </div>
                                <div class="modal-body p-4 text-center">
                                    <p class="mb-2">Pendaftaran <strong>{{ $berhasilDaftar->nama_lengkap }}</strong> berhasil disimpan.</p>
                                    <p class="fw-bold text-danger mb-3">Simpan ID Pendaftaran ini — dibutuhkan untuk cek status pendaftaran dan hasil kelulusan seleksi!</p>

                                    <div class="input-group mb-2">
                                        <input type="text" id="idPendaftaranText" class="form-control form-control-lg text-center fw-bold text-primary" value="{{ $berhasilDaftar->id_pendaftaran }}" readonly>
                                        <button class="btn btn-primary" type="button" onclick="copyIdPendaftaran()">
                                            <i class="bi bi-clipboard me-1"></i><span id="copyLabel">Salin</span>
                                        </button>
                                    </div>
                                    <small class="text-muted d-block">Nomor Kontak: {{ $berhasilDaftar->no_kontak_siswa }}</small>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Saya Sudah Mencatat ID Ini</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                @if($errors->any())
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('spmb.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <h6 class="fw-bold text-primary mb-3">Data Calon Murid Baru</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nama Lengkap Calon Murid Baru <span class="text-danger">*</span></label>
                            <input type="text" name="nama_lengkap" class="form-control" value="{{ old('nama_lengkap') }}" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                            <select name="jenis_kelamin" class="form-select" required>
                                <option value="">-- Pilih --</option>
                                <option value="L" {{ old('jenis_kelamin') == 'L' ? 'selected' : '' }}>Laki-laki</option>
                                <option value="P" {{ old('jenis_kelamin') == 'P' ? 'selected' : '' }}>Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Asal Sekolah SD/MI <span class="text-danger">*</span></label>
                            <input type="text" name="asal_sekolah" class="form-control" value="{{ old('asal_sekolah') }}" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nomor Kontak Siswa <span class="text-danger">*</span></label>
                            <input type="text" name="no_kontak_siswa" class="form-control" value="{{ old('no_kontak_siswa') }}" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Alamat Tempat Tinggal <span class="text-danger">*</span></label>
                            <textarea name="alamat" class="form-control" rows="3" required>{{ old('alamat') }}</textarea>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="fw-bold text-primary mb-3">Data Orang Tua / Wali</h6>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label">Nama Orang Tua / Wali <span class="text-danger">*</span></label>
                            <input type="text" name="nama_orang_tua" class="form-control" value="{{ old('nama_orang_tua') }}" required>
                        </div>
                        <div class="mb-3">
                            <label for="no_kontak_orang_tua" class="form-label">Nomor Kontak Orang Tua / Wali <span class="text-danger">*</span></label>
                            <input type="text" name="no_kontak_orang_tua" id="no_kontak_orang_tua" class="form-control" value="{{ old('no_kontak_orang_tua') }}">
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="fw-bold text-primary mb-3">Sumber Informasi</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Sumber Informasi SPMB <span class="text-danger">*</span></label>
                            <select name="sumber_informasi" class="form-select" required>
                                <option value="">-- Pilih --</option>
                                <option value="Saudara" {{ old('sumber_informasi') == 'Saudara' ? 'selected' : '' }}>Saudara</option>
                                <option value="Tetangga" {{ old('sumber_informasi') == 'Tetangga' ? 'selected' : '' }}>Tetangga</option>
                                <option value="Website/Social Media" {{ old('sumber_informasi') == 'Website/Social Media' ? 'selected' : '' }}>Website/Social Media (IG, Twitter, FB, TikTok, dll)</option>
                                <option value="Kunjungan langsung" {{ old('sumber_informasi') == 'Kunjungan langsung' ? 'selected' : '' }}>Kunjungan langsung</option>
                                <option value="Lainnya" {{ old('sumber_informasi') == 'Lainnya' ? 'selected' : '' }}>Lainnya</option>
                            </select>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="fw-bold text-primary mb-3">Upload Dokumen Persyaratan</h6>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Kartu Keluarga <span class="text-danger">*</span></label>
                            <input type="file" name="kartu_keluarga" class="form-control" accept=".jpg,.jpeg,.pdf" required>
                            <small class="text-muted">Format JPG/PDF, maks 2MB</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Akte Kelahiran <span class="text-danger">*</span></label>
                            <input type="file" name="akte_kelahiran" class="form-control" accept=".jpg,.jpeg,.pdf" required>
                            <small class="text-muted">Format JPG/PDF, maks 2MB</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">KTP Orang Tua <span class="text-danger">*</span></label>
                            <input type="file" name="ktp_orang_tua" class="form-control" accept=".jpg,.jpeg,.pdf" required>
                            <small class="text-muted">Format JPG/PDF, maks 2MB</small>
                        </div>
                    </div>

                    <div class="alert alert-warning mt-4">
                        <i class="bi bi-info-circle-fill me-2"></i><strong>Pemberitahuan:</strong> Dokumen yang diupload akan diverifikasi ulang dengan dokumen asli saat jadwal tes pendaftaran.
                    </div>

                    <div class="mt-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-arrow-right-circle me-1"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
@if(isset($berhasilDaftar))
    var modalId = new bootstrap.Modal(document.getElementById('modalIdPendaftaran'));
    modalId.show();
@endif

function copyIdPendaftaran() {
    var input = document.getElementById('idPendaftaranText');
    input.select();
    input.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(input.value).then(function () {
        document.getElementById('copyLabel').innerText = 'Tersalin!';
        setTimeout(function () {
            document.getElementById('copyLabel').innerText = 'Salin';
        }, 2000);
    });
}
</script>
</body>
</html>