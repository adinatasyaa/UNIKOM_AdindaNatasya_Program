<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Cek Status & Jadwal Tes SPMB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body style="background-color: #f8f9fa;">
    <nav class="navbar navbar-dark" style="background-color: #1a237e;">
        <div class="container">
            <a href="{{ route('spmb.index') }}" class="navbar-brand fw-bold">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke SPMB
            </a>
        </div>
    </nav>

    <div class="container py-4">
        
        @if(session('error'))
            <div class="alert alert-danger mx-auto" style="max-width: 600px;">
                <i class="bi bi-exclamation-triangle me-1"></i> {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success mx-auto" style="max-width: 600px;">
                <i class="bi bi-check-circle-fill me-1"></i> {{ session('success') }}
            </div>
        @endif

        <div class="card shadow-sm mx-auto" style="max-width: 600px;">
            <div class="card-header" style="background-color: #1a237e; color: white;">
                <h5 class="mb-0"><i class="bi bi-search me-2"></i>Cek Status Pendaftaran & Jadwal Tes</h5>
            </div>
            <div class="card-body p-4">
                <form action="{{ route('spmb.cek_status.post') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label">ID Pendaftaran <span class="text-danger">*</span></label>
                        <input type="text" name="id_pendaftaran" class="form-control" placeholder="Contoh: 2025/2026-01" value="{{ old('id_pendaftaran') }}" required>
                        <small class="text-muted">Masukkan ID Pendaftaran yang diberikan setelah submit formulir Tahap 1.</small>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search me-1"></i> Cek Status & Jadwal
                    </button>
                </form>

                @if(isset($pendaftaran) && $pendaftaran)
                    <hr class="my-4">
                    <h6 class="fw-bold text-success"><i class="bi bi-card-list me-1"></i> Data Pendaftar Ditemukan:</h6>
                    <table class="table table-bordered mt-2">
                        <tr>
                            <td width="40%" class="bg-light fw-semibold">ID Pendaftaran</td>
                            <td><strong class="text-primary">{{ $pendaftaran->id_pendaftaran }}</strong></td>
                        </tr>
                        <tr>
                            <td width="40%" class="bg-light fw-semibold">Nama Lengkap</td>
                            <td><strong>{{ $pendaftaran->nama_lengkap }}</strong></td>
                        </tr>
                        <tr>
                            <td class="bg-light fw-semibold">Asal Sekolah</td>
                            <td>{{ $pendaftaran->asal_sekolah }}</td>
                        </tr>
                        <tr>
                            <td class="bg-light fw-semibold">Status Validasi</td>
                            <td class="align-middle">
                                @if($pendaftaran->status == 'diterima')
                                    <span class="badge bg-success"><i class="bi bi-check-circle-fill me-1"></i> Diterima</span>
                                @elseif($pendaftaran->status == 'konfirmasi')
                                    <span class="badge bg-secondary text-white"><i class="bi bi-info-circle-fill me-1"></i> Konfirmasi</span>
                                @elseif($pendaftaran->status == 'pending')
                                    <span class="badge bg-warning text-dark"><i class="bi bi-clock-history me-1"></i> Pending</span>
                                @else
                                    <span class="badge bg-danger"><i class="bi bi-x-circle-fill me-1"></i> Ditolak</span>
                                @endif
                            </td>
                        </tr>
                    </table>

                    @if($pendaftaran->status == 'diterima')
                        <div class="mt-3 p-3 border border-info rounded bg-info bg-opacity-10 text-center">
                            <p class="mb-2 text-dark fw-semibold">Pendaftaran Anda telah disetujui untuk mengikuti tes. Silakan cek hasil seleksi Anda setelah tes dilaksanakan.</p>
                            <a href="{{ route('spmb.pengumuman') }}" class="btn btn-info w-100 fw-bold text-white">
                                <i class="bi bi-megaphone me-1"></i> Cek Hasil Seleksi
                            </a>
                        </div>
                    @endif

                    <div class="alert alert-info border-0 mt-3">
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-calendar3 me-1"></i> JADWAL TES FISIK SELEKSI:</h6>
                        @if($pendaftaran->tanggal_tes && $pendaftaran->status == 'diterima')
                            <p class="mb-1 text-dark">Hari : <strong>{{ \Carbon\Carbon::parse($pendaftaran->tanggal_tes)->translatedFormat('l') }}</strong></p>
                            <p class="mb-1 text-dark">Tanggal : <strong>{{ \Carbon\Carbon::parse($pendaftaran->tanggal_tes)->translatedFormat('d F Y') }}</strong></p>
                            <p class="mb-1 text-dark">Jam : <strong>{{ \Carbon\Carbon::parse($pendaftaran->jam_tes)->format('H:i') }} WIB</strong></p>
                            <p class="mb-1 text-dark">Ruangan : <strong>{{ $pendaftaran->ruangan ?? '-' }}</strong></p>
                            <p class="mb-0 text-muted small">Keterangan: {{ $pendaftaran->keterangan ?? 'Harap hadir tepat waktu mengenakan pakaian yang sopan.' }}</p>
                        @else
                            <p class="mb-0 text-muted small"><i class="bi bi-info-circle"></i> Jadwal tes fisik akan muncul di sini setelah status Anda disetujui dan diverifikasi oleh Kurikulum.</p>
                        @endif
                    </div>
                @endif
            </div>
        </div>
    </div>
</body>
</html>