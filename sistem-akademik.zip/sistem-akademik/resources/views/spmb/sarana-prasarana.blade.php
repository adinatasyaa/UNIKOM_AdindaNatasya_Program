<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Sarana Prasarana - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #fff; scroll-behavior: smooth; }
        .navbar-custom { background-color: #fff; border-bottom: 2px solid #0a1050; }
        .page-carousel{max-width: 850px;margin: auto;}
        .page-carousel img{width:100%;height:500px;object-fit:contain;background:#f8f9fa;}
        .carousel-control-prev-icon,
        .carousel-control-next-icon{width:45px;height:45px; }
        footer { background-color: #0a1050; color: rgba(255,255,255,0.8); }
        .navbar-nav .nav-link { color: #6c757d !important; font-weight: 500; }
        .navbar-nav .nav-link:hover { color: #0a1050 !important; }
        .navbar-nav .nav-link.active { color: #0a1050 !important; font-weight: 700; }
        .section-title { color: #0a1050; text-transform: uppercase; letter-spacing: 1px; }
        .section-divider { width: 60px; height: 3px; background-color: #0a1050; margin: 10px auto; }
       
    </style>
</head>
<body>

   <nav class="navbar navbar-expand-lg navbar-custom sticky-top border-0">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <img src="{{ asset('logo1.png') }}" height="45" style="width:auto; object-fit:contain; padding-left: 10px;">
        </div>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNavNav">
            <ul class="navbar-nav gap-2 mt-2 mt-lg-0">
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}#visi-misi">Visi & Misi</a></li>
                <li class="nav-item"><a class="nav-link active" href="{{ route('sarana-prasarana') }}">Sarana Prasarana</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('kegiatan-siswa') }}">Kegiatan Siswa</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}#pendaftaran">Pendaftaran</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}#kontak">Kontak</a></li>
				<li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Login</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container py-5">
        <div class="text-center mb-5">
            <h3 class="fw-bold section-title">Sarana Prasarana</h3>
            <div class="section-divider"></div>
            <p class="text-muted mx-auto" style="max-width: 700px; font-size: 15px;">
                Fasilitas penunjang kegiatan belajar mengajar di SMP Labschool UPI Kampus Cibiru.
            </p>
        </div>

        <div id="saranaCarousel" class="carousel slide page-carousel shadow-sm rounded" data-bs-ride="carousel">

        <div class="carousel-indicators" data-bs-interval="900">
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="3"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="4"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="5"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="6"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="7"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="8"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="9"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="10"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="11"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="12"></button>
            <button type="button" data-bs-target="#saranaCarousel" data-bs-slide-to="13"></button>
        </div>

        <div class="carousel-inner rounded">

            <div class="carousel-item active">
                <img src="{{ asset('fasilitas1.jpeg') }}" class="d-block w-100" alt="">
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas2.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Taman Yang Sangat Nyaman</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas3.jpeg') }}" class="d-block w-100" alt="">
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas4.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Gedung Timur - Ruang Kelas / Aula Terbuka</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas5.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Ruang Guru</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas6.jpeg') }}" class="d-block w-100" alt="">
                 <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Gedung Tengah - Ruang Kelas</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas7.jpeg') }}" class="d-block w-100" alt="">
                 <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Kantin Sehat</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas8.jpeg') }}" class="d-block w-100" alt="">
                 <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Ruang Kelas yang Nyaman</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas9.jpeg') }}" class="d-block w-100" alt="">
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas10.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Perpustakaan</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas11.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Tempat Parkir Motor</h6>
                    </div>
            </div>

            <div class="carousel-item">
                <img src="{{ asset('fasilitas12.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Tempat Parkir Mobil</h6>
                    </div>
            </div>

             <div class="carousel-item">
                <img src="{{ asset('fasilitas13.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Gerbang Utama Keluar</h6>
                    </div>
            </div>

             <div class="carousel-item">
                <img src="{{ asset('fasilitas14.jpeg') }}" class="d-block w-100" alt="">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Gerbang Utama Masuk</h6>
                    </div>
            </div>

        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#saranaCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon bg-dark rounded-circle p-3"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#saranaCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon bg-dark rounded-circle p-3"></span>
        </button>
    </div>
        </div>
            <div class="text-center pt-4">
                <small style="opacity:0.7;">© 2026 SMP Labschool UPI Kampus Cibiru. Hak Cipta Dilindungi</small>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>