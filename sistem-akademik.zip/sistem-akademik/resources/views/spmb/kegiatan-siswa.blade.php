<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Kegiatan Siswa - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #fff; scroll-behavior: smooth; }
        .navbar-custom { background-color: #fff; border-bottom: 2px solid #0a1050; }
        .page-carousel{max-width: 850px;margin: auto;}
        .page-carousel img{width:100%;height:500px;object-fit:contain;background:#f8f9fa;}
        footer { background-color: #0a1050; color: rgba(255,255,255,0.8); }
        .navbar-nav .nav-link { color: #6c757d !important; font-weight: 500; }
        .navbar-nav .nav-link:hover { color: #0a1050 !important; }
        .navbar-nav .nav-link.active { color: #0a1050 !important; font-weight: 700; }
        .section-title { color: #0a1050; text-transform: uppercase; letter-spacing: 1px; }
        .section-divider { width: 60px; height: 3px; background-color: #0a1050; margin: 10px auto; }
        .kegiatan-card { border-radius: 12px; border: 1px solid #e2e2e2; height: 100%; }
        .kegiatan-card .card-header-custom { background: #0a1050; color: #fff; padding: 12px 20px; font-weight: 700; font-size: 15px; }
        
    </style>
</head>
<body>

   <nav class="navbar navbar-expand-lg navbar-custom sticky-top border-0">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <img src="{{ asset('logo1.png') }}" height="45" style="width:auto; object-fit:contain; padding-left: 10px;">
        </div>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNavNav">
            <ul class="navbar-nav gap-2 mt-2 mt-lg-0">
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}#visi-misi">Visi & Misi</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('sarana-prasarana') }}">Sarana Prasarana</a></li>
                <li class="nav-item"><a class="nav-link active" href="{{ route('kegiatan-siswa') }}">Kegiatan Siswa</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}#pendaftaran">Pendaftaran</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('spmb.index') }}#kontak">Kontak</a></li>
				<li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Login</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container py-5">
        <div class="text-center mb-5">
            <h3 class="fw-bold section-title">Kegiatan Siswa</h3>
            <div class="section-divider"></div>
             <p class="text-muted mx-auto" style="max-width: 700px; font-size: 15px;">
                Kegiatan siswa di SMP Labschool UPI Kampus Cibiru.
            </p>
        </div>

        
        <div id="kegiatanCarousel" class="carousel slide page-carousel shadow-sm rounded mb-5" data-bs-ride="carousel">
            <div class="carousel-indicators" data-bs-interval="900">
                <button type="button" data-bs-target="#kegiatanCarousel" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#kegiatanCarousel" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#kegiatanCarousel" data-bs-slide-to="2"></button>
                <button type="button" data-bs-target="#kegiatanCarousel" data-bs-slide-to="3"></button>
            </div>
            <div class="carousel-inner rounded">
                <div class="carousel-item active">
                    <img src="{{ asset('kegiatan1.jpeg') }}" class="d-block w-100" alt="Ekstrakurikuler">
                    <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Program Unggulan Sekolah</h6>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('kegiatan2.jpeg') }}" class="d-block w-100" alt="Program Unggulan">
                    <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Program Unggulan Sekolah</h6>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('kegiatan3.jpeg') }}" class="d-block w-100" alt="Budaya Sekolah">
                    <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Kegiatan Ekstrakurikuler Siswa</h6>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('kegiatan4.jpeg') }}" class="d-block w-100" alt="Budaya Sekolah">
                    <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
                        <h6 class="fw-bold mb-0">Budaya Sekolah Sehari-hari</h6>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#kegiatanCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#kegiatanCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </button>
        </div>

        <h4 class="fw-bold mb-4" style="color:#0a1050;"><i class="bi bi-people-fill me-2"></i>Ekstrakurikuler</h4>
        <div class="row g-4 mb-5">
            <div class="col-md-6 col-lg-4">
                <div class="kegiatan-card shadow-sm">
                    <div class="card-header-custom">Bidang Keagamaan</div>
                    <div class="p-3">
                        <ul class="text-muted mb-0" style="font-size:14px;">
                            <li>Ikatan Remaja Masjid (IRMAS)</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="kegiatan-card shadow-sm">
                    <div class="card-header-custom">Bidang Keilmuan & Keterampilan</div>
                    <div class="p-3">
                        <ul class="text-muted mb-0" style="font-size:14px;">
                            <li>Karya Ilmiah Remaja (KIR)</li>
                            <li>English Club</li>
                            <li>Japanese Club</li>
                            <li>Cooking Club</li>
                            <li>Jurnalis / Fotografi</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="kegiatan-card shadow-sm">
                    <div class="card-header-custom">Bidang Kesenian</div>
                    <div class="p-3">
                        <ul class="text-muted mb-0" style="font-size:14px;">
                            <li>Seni Tari</li>
                            <li>Karawitan (Angklung)</li>
                            <li>Modern Dance</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="kegiatan-card shadow-sm">
                    <div class="card-header-custom">Bidang Olahraga</div>
                    <div class="p-3">
                        <ul class="text-muted mb-0" style="font-size:14px;">
                            <li>Basket</li>
                            <li>Futsal</li>
                            <li>Bola Voli</li>
                            <li>Pencak Silat</li>
                            <li>Karate</li>
                            <li>Bulu Tangkis</li>
                            <li>Taekwondo</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="kegiatan-card shadow-sm">
                    <div class="card-header-custom">Bidang Keorganisasian</div>
                    <div class="p-3">
                        <ul class="text-muted mb-0" style="font-size:14px;">
                            <li>Pramuka</li>
                            <li>Paskibra</li>
                            <li>Palang Merah Remaja (PMR)</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <h4 class="fw-bold mb-4" style="color:#0a1050;"><i class="bi bi-star-fill me-2"></i>Program Unggulan</h4>
        <div class="kegiatan-card shadow-sm mb-5 p-4">
            <div class="row">
                <div class="col-md-6">
                    <ul class="text-muted mb-0" style="font-size:14px; line-height:1.9;">
                        <li>Supercamp</li>
                        <li>Homestay</li>
                        <li>Career Day</li>
                        <li>Pelatihan Kepemimpinan Siswa Tingkat Dasar (PKSTD)</li>
                        <li>Pelatihan Kepemimpinan Siswa Tingkat Menengah (PKSTM)</li>
                        <li>English Camp</li>
                        <li>Character Building</li>
                        <li>Seminar Motivasi</li>
                        <li>Muhasabah dan Doa Bersama</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="text-muted mb-0" style="font-size:14px; line-height:1.9;">
                        <li>English Conversation</li>
                        <li>Pembinaan Olimpiade</li>
                        <li>Pemantapan Ujian Sekolah</li>
                        <li>Pesantren Ramadhan</li>
                        <li>Simple Research</li>
                        <li>Malam Bina Iman dan Taqwa (MABIT)</li>
                        <li>BTAQ</li>
                        <li>Pelatihan Kesiapsiagaan Bencana</li>
                        <li>Mini Skripsi Project</li>
                        <li>Field Trips Observation</li>
                    </ul>
                </div>
            </div>
        </div>

        <h4 class="fw-bold mb-4" style="color:#0a1050;"><i class="bi bi-flag-fill me-2"></i>Budaya Sekolah</h4>
        <div class="kegiatan-card shadow-sm p-4">
            <div class="row">
                <div class="col-md-6">
                    <ul class="text-muted mb-0" style="font-size:14px; line-height:1.9;">
                        <li>Tadarus Al-Qur'an</li>
                        <li>Shalat Dhuha Bersama</li>
                        <li>Shalat Dzuhur Berjamaah</li>
                        <li>Keputrian</li>
                        <li>English Day / English Conversation</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="text-muted mb-0" style="font-size:14px; line-height:1.9;">
                        <li>Budaya Jabat Tangan Bertemu Guru</li>
                        <li>Budaya Salam / Sapa</li>
                        <li>Budaya Bersih</li>
                        <li>Budaya Disiplin</li>
                        <li>Budaya Rapih dan Tata Tertib Sekolah</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
            </div>
            <div class="text-center pt-4">
                <small style="opacity:0.7;">© 2026 SMP Labschool UPI Kampus Cibiru. Hak Cipta Dilindungi</small>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>