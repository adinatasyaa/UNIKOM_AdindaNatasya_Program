<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>SPMB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #fff; scroll-behavior: smooth; }
        .navbar-custom { background-color: #fff; border-bottom: 2px solid #0a1050; }
        .hero-carousel {height: 500px; }
        .hero-carousel .carousel-inner,
        .hero-carousel .carousel-item {height: 500px;}
        .hero-carousel img {width: 100%;height: 450px;object-fit: cover;object-position: center;}
        .card-menu { border: 1px solid #0a1050; border-radius: 12px; transition: all 0.3s; background-color: #fff; }
        .card-menu:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(26,35,126,0.15); border-color: #0a1050; }
        .card-menu .icon-wrap { width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px auto; }
        .bg-navy-custom { background-color: #0a1050; color: white; }
        footer { background-color: #0a1050; color: rgba(255,255,255,0.8); }
        .navbar-nav .nav-link {color: #6c757d !important;font-weight: 500;transition: all 0.2s ease-in-out; }
        .navbar-nav .nav-link:hover {color: #0a1050 !important; }
        .navbar-nav .nav-link.active {color: #0a1050 !important;font-weight: 700; }
    </style>
</head>
<body> 
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top border-0">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <img src="{{ asset('logo1.png') }}" height="45" style="width:auto; object-fit:contain; padding-left: 10px;">
        </div>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNavNav">
            <ul class="navbar-nav gap-2 mt-2 mt-lg-0 align-items-lg-center">
                <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#visi-misi">Visi & Misi</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('sarana-prasarana') }}">Sarana Prasarana</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('kegiatan-siswa') }}">Kegiatan Siswa</a></li>
                <li class="nav-item"><a class="nav-link" href="#pendaftaran">Pendaftaran</a></li>
                <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
               <li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Login</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div id="home" class="carousel slide hero-carousel" data-bs-ride="carousel">
        <div class="carousel-indicators" data-bs-interval="2000">
            <button type="button" data-bs-target="#home" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#home" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#home" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#home" data-bs-slide-to="3"></button>
            <button type="button" data-bs-target="#home" data-bs-slide-to="4"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="{{ asset('slide1.jpeg') }}" class="d-block w-100" alt="Gedung Sekolah">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5 class="fw-bold ">Selamat Datang di SMP Labschool UPI Kampus Cibiru</h5>
                    <p>Membentuk generasi cerdas, berkarakter luhur, dan siap menghadapi masa depan.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="{{ asset('slide2.jpeg') }}" class="d-block w-100" alt="Kegiatan Siswa">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5 class="fw-bold fs-4">Fasilitas Modern & Kurikulum Unggulan</h5>
                    <p>Mengoptimalkan potensi akademik dan bakat non-akademik siswa secara maksimal.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="{{ asset('slide3.jpeg') }}" class="d-block w-100" alt="Gedung Sekolah">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5 class="fw-bold fs-4">Fasilitas Modern & Kurikulum Unggulan</h5>
                    <p>Mengoptimalkan potensi akademik dan bakat non-akademik siswa secara maksimal.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="{{ asset('slide4.jpeg') }}" class="d-block w-100" alt="Gedung Sekolah">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5 class="fw-bold fs-4">Selamat Datang di SMP Labschool UPI Kampus Cibiru</h5>
                    <p>Membentuk generasi cerdas, berkarakter luhur, dan siap menghadapi masa depan.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="{{ asset('slide5.jpeg') }}" class="d-block w-100" alt="Gedung Sekolah">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5 class="fw-bold fs-4">Fasilitas Modern & Kurikulum Unggulan</h5>
                    <p>Mengoptimalkan potensi akademik dan bakat non-akademik siswa secara maksimal.</p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#home" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#home" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
        </button>
    </div>

    <div class="text-center py-5 bg-light border-bottom">
        <div class="container">
            <div class="mb-3">
                <span style="background: #0a1050; color: #ffffff; padding: 6px 18px; border-radius: 20px; font-size: 13px; font-weight: 600;">
                    Tahun Ajaran 2026/2027
                </span>
            </div>
            <h2 class="mb-3 fw-bold" style="color: #0a1050;">Penerimaan Murid Baru Telah Dibuka!</h2>
            <p class="text-muted mx-auto" style="max-width: 750px; font-size: 15px;">
                Mari bergabung bersama keluarga besar SMP Labschool UPI Kampus Cibiru. Isilah data pendaftaran dengan benar dan pantau berkala proses seleksi putra/putri Anda melalui sistem online ini.
            </p>
        </div>
    </div>

    <div id="visi-misi" class="container py-5 border-bottom">
        <div class="text-center mb-5">
            <h3 class="fw-bold" style="color: #0a1050; text-transform: uppercase; letter-spacing: 1px;">Visi & Misi Sekolah</h3>
            <div style="width: 60px; height: 3px; background-color: #0a1050; margin: 10px auto;"></div>
        </div>
        
        <div class="row g-4 justify-content-center">
            <div class="col-md-11 mb-2">
                <div class="card border-0 shadow-sm p-4 text-center" style="background-color: #f8f9fa; border-radius: 12px; border-left: 5px solid #0a1050 !important;">
                    <i class="bi bi-eye text-primary mb-2" style="font-size: 2rem;"></i>
                    <h5 class="fw-bold" style="color: #0a1050;">Visi Sekolah</h5>
                    <p class="text-dark fst-italic mx-auto" style="max-width: 900px; font-size: 15px; line-height: 1.6;">
                        “Sekolah Laboratorium percontohan UPI Kampus Cibiru terdepan dalam inovasi, layanan pendidikan, dan pembelajaran di Indonesia, dan terbentuknya karakter siswa profil pelajar Pancasila, serta berwawasan dan berbudaya lingkungan”
                    </p>
                </div>
            </div>

            <div class="col-md-11">
                <div class="card border-0 shadow-sm p-4" style="background-color: #f8f9fa; border-radius: 12px; border-left: 5px solid #2e7d32 !important;">
                    <div class="text-center text-success mb-2">
                        <i class="bi bi-list-check" style="font-size: 2rem;"></i>
                        <h5 class="fw-bold text-dark">Misi Sekolah</h5>
                    </div>
                    
                    <div class="row pt-2">
                        <div class="col-md-6">
                            <ol class="text-muted small ps-3 mb-0" style="font-size: 13.5px; line-height: 1.8; text-align: justify;">
                                <li class="mb-2">Melaksanakan kegiatan belajar mengajar berstandar Nasional dan Internasional yang berazaskan religius.</li>
                                <li class="mb-2">Menumbuhkan karakteristik Profil Pelajar Pancasila untuk mendorong peserta didik menggali potensi dirinya agar berkembang sehingga meraih cita-cita yang diinginkannya.</li>
                                <li class="mb-2">Memenuhi standar Kurikulum Operasional Sekolah Penggerak yang merujuk pada Profil Pelajar Pancasila dan mengoptimalkan pemanfaatan lingkungan sekolah sebagai sumber belajar.</li>
                                <li class="mb-2">Mengembangkan berbagai konsep dan praktek pendidikan dan pembelajaran melalui penelitian secara kolaboratif, Project based learning, dan P5.</li>
                                <li class="mb-2">Mempersiapkan lulusan yang handal, tangguh, mandiri, tanggap, kreatif, inovatif berbudi luhur dan berjiwa kewirausahaan.</li>
                                <li class="mb-2">Membina peserta didik untuk menguasai keterampilan hidup (lifeskills) dan kecakapan Abad 21 yaitu karakter, kewarganegaraan, berpikir kritis, kreatif, kolaborasi, dan komunikasi.</li>
                            </ol>
                        </div>
                        <div class="col-md-6">
                            <ol start="7" class="text-muted small ps-3 mb-0" style="font-size: 13.5px; line-height: 1.8; text-align: justify;">
                                <li class="mb-2">Mewujudkan standar penilaian berbasis HOTS (Higher Order Thinking Skills).</li>
                                <li class="mb-2">Mewujudkan standar mutu tenaga pendidik dan kependidikan bermartabat (professional dan berintegritas).</li>
                                <li class="mb-2">Mengembangkan mutu SMP Laboratorium Percontohan UPI Kampus Cibiru dan manajemen secara profesional, proporsional serta akuntabel.</li>
                                <li class="mb-2">Meningkatkan prestasi akademik, non akademis siswa melalui berbagai program intrakurikuler dan kegiatan ekstrakurikuler tingkat nasional maupun internasional.</li>
                                <li class="mb-2">Mewujudkan Gerakan Literasi Sekolah (GLS) dalam bidang baca tulis, berhitung, sains, dan teknologi informasi dan komunikasi.</li>
                                <li class="mb-2">Menjadi yang terdepan dalam inovasi dan implementasi Teknologi Informasi dan Komunikasi dalam rangka meningkatkan kualitas pembelajaran.</li>
                                <li class="mb-2">Mewujudkan lingkungan sekolah yang hijau, indah, bersih, nyaman, aman rindang dan asri serta berwawasan lingkungan.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="pendaftaran" class="bg-navy-custom py-5" style="min-height: 450px;">
        <div class="container text-center mb-4">
            <h3 class="text-white fw-bold">Alur Pendaftaran Online</h3>
            <p class="text-white-50 small">Silakan pilih menu di bawah ini untuk memulai atau mengecek proses pendaftaran</p>
        </div>
        
        <div class="container">
            <div class="row g-4 justify-content-center">
                <div class="col-md-4">
                    <a href="{{ route('spmb.create') }}" class="text-decoration-none">
                        <div class="card card-menu text-center p-4 h-100">
                            <div class="icon-wrap" style="background:#e8eaf6;">
                                <i class="bi bi-pencil-square" style="font-size:1.8rem;color:#1a237e;"></i>
                            </div>
                            <h5 class="fw-bold" style="color:#1a237e;">Formulir Pendaftaran</h5>
                            <p class="text-muted mb-0" style="font-size:14px;">Isi formulir pendaftaran murid baru secara online</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="{{ route('spmb.cek_status') }}" class="text-decoration-none">
                        <div class="card card-menu text-center p-4 h-100">
                            <div class="icon-wrap" style="background:#e8f5e9;">
                                <i class="bi bi-search" style="font-size:1.8rem;color:#2e7d32;"></i>
                            </div>
                            <h5 class="fw-bold" style="color:#2e7d32;">Cek Status Pendaftaran</h5>
                            <p class="text-muted mb-0" style="font-size:14px;">Pantau status pendaftaran putra/putri Anda</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="{{ route('spmb.pengumuman') }}" class="text-decoration-none">
                        <div class="card card-menu text-center p-4 h-100">
                            <div class="icon-wrap" style="background:#fff8e1;">
                                <i class="bi bi-megaphone" style="font-size:1.8rem;color:#f57f17;"></i>
                            </div>
                            <h5 class="fw-bold" style="color:#f57f17;">Pengumuman</h5>
                            <p class="text-muted mb-0" style="font-size:14px;">Lihat pengumuman hasil seleksi akhir</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <footer id="kontak" class="py-5">
        <div class="container">
            <div class="row g-4 border-bottom border-secondary pb-4">
                <div class="col-md-6">
                    <h5 class="fw-bold text-white mb-2" style="font-size:16px;">SMP Labschool UPI Kampus Cibiru</h5>
                    <p class="m-0 text-white-50 small" style="line-height: 1.6;">
                        Jl. Pendidikan No.KM 15, Cibiru Wetan, <br>
                        Kec. Cileunyi, Kabupaten Bandung, Jawa Barat 40625.
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5 class="fw-bold text-white mb-2" style="font-size:16px;">Hubungi Layanan SPMB</h5>
                    <span class="d-block text-white-50 small">💬 WhatsApp Panitia: 0898-8236-497</span>
                </div>
            </div>
            <div class="text-center pt-4">
                <small style="opacity:0.7;">© 2026 SMP Labschool UPI Kampus Cibiru. Hak Cipta Dilindungi</small>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function setActiveMenu(hash) {
        document.querySelectorAll('.navbar-nav .nav-link').forEach(function (l) {
            l.classList.remove('active');
        });
        var target = document.querySelector('.navbar-nav .nav-link[href="' + hash + '"]');
        if (target) {
            target.classList.add('active');
        }
    }

    var initialHash = window.location.hash || '#home';
    setActiveMenu(initialHash);

    document.querySelectorAll('.navbar-nav .nav-link[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function () {
            setActiveMenu(this.getAttribute('href'));
        });
    });
    </script>
</body>
</html>