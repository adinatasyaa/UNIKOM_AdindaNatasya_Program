<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('logoSekolah.jpg') }}">
    <title>Pengumuman SPMB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body style="background-color: #f8f9fa;">
    <nav class="navbar navbar-dark" style="background-color: #1a237e;">
        <div class="container">
            <a href="{{ route('spmb.index') }}" class="navbar-brand fw-bold">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke SPMB
            </a>
        </div>
    </nav>

    <div class="container py-4">
        <div class="card shadow-sm mb-4 mx-auto" style="max-width: 600px;">
            <div class="card-body p-4">
                <h5 class="fw-bold text-center mb-3"><i class="bi bi-search me-2"></i>Cari Hasil Kelulusan Seleksi</h5>

                @if(session('error'))
                    <div class="alert alert-warning text-center">
                        <i class="bi bi-exclamation-triangle me-1"></i> {{ session('error') }}
                    </div>
                @endif

                <form action="{{ route('spmb.proses_cari_pengumuman') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label class="form-label">Masukkan ID Pendaftaran</label>
                        <input type="text" name="id_pendaftaran" class="form-control" placeholder="Contoh: 2026/2027-01" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search me-1"></i> Cari Hasil Seleksi
                    </button>
                </form>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header" style="background-color: #1a237e; color: white;">
                <h5 class="mb-0"><i class="bi bi-megaphone me-2"></i>Pengumuman Hasil Seleksi SPMB</h5>
                <small>SMP Labschool UPI Kampus Cibiru</small>
            </div>
            <div class="card-body">

                @if(isset($pengumuman) && $pengumuman->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>ID Pendaftaran</th>
                                    <th>Nama Siswa</th>
                                    <th>Asal Sekolah</th>
                                    <th>Status Kelulusan</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($pengumuman as $index => $p)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $p->id_pendaftaran }}</td>
                                    <td>{{ $p->nama_lengkap }}</td>
                                    <td>{{ $p->asal_sekolah }}</td>
                                    <td>
                                        @if($p->hasil_seleksi == 'lulus')
                                            <span class="badge bg-success">
                                                <i class="bi bi-check-circle me-1"></i> Lulus
                                            </span>
                                        @elseif($p->hasil_seleksi == 'tidak_lulus')
                                            <span class="badge bg-danger">
                                                <i class="bi bi-x-circle me-1"></i> Tidak Lulus
                                            </span>
                                        @else
                                            <span class="badge bg-warning text-dark">
                                                <i class="bi bi-hourglass-split me-1"></i> Menunggu Hasil Seleksi
                                            </span>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    @if($pengumuman->first()->hasil_seleksi == 'lulus')
                        <div class="alert alert-success text-center mt-3">
                            <p class="mb-2"><i class="bi bi-check-circle me-1"></i> Selamat! Anda dinyatakan lulus seleksi.</p>
                            <a href="{{ route('spmb.konfirmasi') }}" class="btn btn-success">
                                <i class="bi bi-arrow-right-circle me-1"></i> Lanjut ke Konfirmasi Data
                            </a>
                        </div>
                    @endif

                @elseif(isset($pengumuman))
                    <div class="alert alert-warning text-center">
                        <i class="bi bi-exclamation-triangle me-1"></i> Data pendaftaran dengan ID tersebut belum tersedia karena hasil kelulusan tes belum dipublikasikan. <br> 
                        Pengumuman hasil tes akan dilakukan paling lambat 3 hari setelah pelaksanaan tes.
                    </div>
                @else
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-megaphone" style="font-size: 3rem;"></i>
                        <p class="mt-3">Masukkan ID Pendaftaran Anda untuk melihat hasil kelulusan setelah pengumuman tersedia.</p>
                    </div>
                @endif

            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>