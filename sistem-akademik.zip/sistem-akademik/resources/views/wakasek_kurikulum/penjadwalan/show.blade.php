@extends('layouts.app')

@section('page-title', 'Detail Jadwal')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Jadwal Mata Pelajaran</h5>
        <a href="{{ route('kurikulum.penjadwalan.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <h6 class="fw-bold text-primary">Detail Jadwal</h6>
        <table class="table table-bordered">
            <tr>
                <td width="30%">Kelas</td>
                <td><strong>{{ $jadwal->kelas->nama_kelas ?? '-' }}</strong></td>
            </tr>
            <tr>
                <td>Mata Pelajaran</td>
                <td>{{ $jadwal->mataPelajaran->kode_mapel ?? '-' }}</td>
            </tr>
            <tr>
                <td>Guru</td>
                <td>{{ $jadwal->guru->nama ?? '-' }}</td>
            </tr>
            <tr>
                <td>Hari</td>
                <td>{{ $jadwal->hari }}</td>
            </tr>
            <tr>
                <td>Jam</td>
                <td>{{ \Carbon\Carbon::parse($jadwal->jam_mulai)->format('H.i') }} - {{ \Carbon\Carbon::parse($jadwal->jam_selesai)->format('H.i') }}</td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td>{{ $jadwal->tahun_ajaran }}</td>
            </tr>
            <tr>
                <td>Semester</td>
                <td>Semester {{ $jadwal->semester }}</td>
            </tr>
            <tr>
                <td>Status</td>
                <td><span class="badge bg-success">Aktif</span></td>
            </tr>
        </table>
    </div>
</div>
@endsection