@extends('layouts.app')

@section('page-title', 'Tambah Jadwal')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Tambah Jadwal Mata Pelajaran</h5>
        <a href="{{ route('kurikulum.penjadwalan.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('kurikulum.penjadwalan.store') }}" method="POST">
            @csrf
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Kelas <span class="text-danger">*</span></label>
                    <select name="kelas_id" id="kelasSelect" class="form-select" required>
                        <option value="">-- Pilih Kelas --</option>
                        @foreach($kelas as $k)
                            <option value="{{ $k->id }}" {{ old('kelas_id') == $k->id ? 'selected' : '' }}>
                                {{ $k->nama_kelas }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Mata Pelajaran <span class="text-danger">*</span></label>
                    <select name="mata_pelajaran_id" id="mapelSelect" class="form-select" required>
                        <option value="">-- Pilih Guru terlebih dahulu --</option>
                    </select>
                    <div id="infoKuota" class="mt-2" style="display:none;"></div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Guru <span class="text-danger">*</span></label>
                    <select name="guru_id" id="guruSelect" class="form-select" required>
                        <option value="">-- Pilih Guru --</option>
                        @foreach($guru as $g)
                            <option value="{{ $g->id }}" {{ old('guru_id') == $g->id ? 'selected' : '' }}>
                                {{ $g->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Hari <span class="text-danger">*</span></label>
                    <select name="hari" class="form-select" required>
                        <option value="">-- Pilih Hari --</option>
                        @foreach(['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat'] as $hari)
                            <option value="{{ $hari }}" {{ old('hari') == $hari ? 'selected' : '' }}>
                                {{ $hari }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Jam Mulai <span class="text-danger">*</span></label>
                    <input type="time" name="jam_mulai" id="jamMulai" class="form-control"
                        value="{{ old('jam_mulai') }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Jam Selesai <span class="text-danger">*</span></label>
                    <input type="time" name="jam_selesai" id="jamSelesai" class="form-control"
                        value="{{ old('jam_selesai') }}" required>
                    <small class="text-muted">Durasi maksimal 4 jam per sesi. Total jam mingguan mengikuti alokasi waktu mata pelajaran yang dipilih.</small>
                    <div id="errorJam" class="text-danger mt-1" style="display:none;"></div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                    <input type="text" name="tahun_ajaran" id="tahunAjaran" class="form-control"
                        value="{{ old('tahun_ajaran', '2026/2027') }}" placeholder="2026/2027" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Semester <span class="text-danger">*</span></label>
                    <select name="semester" id="semesterSelect" class="form-select" required>
                        <option value="">-- Pilih Semester --</option>
                        <option value="1" {{ old('semester') == '1' ? 'selected' : '' }}>Semester 1</option>
                        <option value="2" {{ old('semester') == '2' ? 'selected' : '' }}>Semester 2</option>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
                <a href="{{ route('kurikulum.penjadwalan.index') }}" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
<script>
document.getElementById('guruSelect').addEventListener('change', function() {
    const guruId = this.value;
    const mapelSelect = document.getElementById('mapelSelect');

    mapelSelect.innerHTML = '<option value="">Memuat...</option>';
    document.getElementById('infoKuota').style.display = 'none';

    if (!guruId) {
        mapelSelect.innerHTML = '<option value="">-- Pilih Guru terlebih dahulu --</option>';
        return;
    }

    fetch(`/kurikulum/penjadwalan/mapel-by-guru/${guruId}`)
        .then(res => res.json())
        .then(data => {
            mapelSelect.innerHTML = '';

            if (data.length === 0) {
                mapelSelect.innerHTML = '<option value="">Guru ini belum ditugaskan mata pelajaran</option>';
                return;
            }

            mapelSelect.innerHTML = '<option value="">-- Pilih Mata Pelajaran --</option>';
            data.forEach(m => {
                const selected = data.length === 1 ? 'selected' : '';
                mapelSelect.innerHTML += `<option value="${m.id}" ${selected}>${m.kode_mapel}</option>`;
            });

            cekSisaKuota();
        });
});

function cekSisaKuota() {
    const kelasId = document.getElementById('kelasSelect').value;
    const mapelId = document.getElementById('mapelSelect').value;
    const tahunAjaran = document.getElementById('tahunAjaran').value;
    const semester = document.getElementById('semesterSelect').value;
    const infoBox = document.getElementById('infoKuota');

    if (!kelasId || !mapelId || !tahunAjaran || !semester) {
        infoBox.style.display = 'none';
        return;
    }

    const params = new URLSearchParams({
        kelas_id: kelasId,
        mata_pelajaran_id: mapelId,
        tahun_ajaran: tahunAjaran,
        semester: semester,
    });

    fetch(`{{ route('kurikulum.penjadwalan.sisa_kuota') }}?${params}`)
        .then(res => res.json())
        .then(data => {
            const warna = data.sisa <= 0 ? 'alert-danger' : 'alert-info';
            infoBox.className = `alert ${warna} py-2 px-3 mb-0`;
            infoBox.innerHTML = `<strong>${data.nama_mapel}</strong>: alokasi ${data.alokasi} jam/minggu, sudah terpakai ${data.terpakai} jam, sisa ${data.sisa} jam.`;
            infoBox.style.display = 'block';
        });
}

document.getElementById('kelasSelect').addEventListener('change', cekSisaKuota);
document.getElementById('mapelSelect').addEventListener('change', cekSisaKuota);
document.getElementById('tahunAjaran').addEventListener('change', cekSisaKuota);
document.getElementById('semesterSelect').addEventListener('change', cekSisaKuota);

function validasiDurasiJam() {
    const jamMulai = document.getElementById('jamMulai').value;
    const jamSelesai = document.getElementById('jamSelesai').value;
    const errorBox = document.getElementById('errorJam');

    if (!jamMulai || !jamSelesai) {
        errorBox.style.display = 'none';
        return true;
    }

    const [h1, m1] = jamMulai.split(':').map(Number);
    const [h2, m2] = jamSelesai.split(':').map(Number);
    const menit1 = h1 * 60 + m1;
    const menit2 = h2 * 60 + m2;
    const selisihJam = (menit2 - menit1) / 60;

    if (selisihJam <= 0) {
        errorBox.textContent = 'Jam Selesai harus lebih besar dari Jam Mulai.';
        errorBox.style.display = 'block';
        return false;
    }

    if (selisihJam > 4) {
        errorBox.textContent = 'Durasi jadwal tidak boleh lebih dari 4 jam.';
        errorBox.style.display = 'block';
        return false;
    }

    errorBox.style.display = 'none';
    return true;
}

document.getElementById('jamMulai').addEventListener('change', validasiDurasiJam);
document.getElementById('jamSelesai').addEventListener('change', validasiDurasiJam);

document.querySelector('form').addEventListener('submit', function(e) {
    if (!validasiDurasiJam()) {
        e.preventDefault();
    }
});
</script>
@endsection