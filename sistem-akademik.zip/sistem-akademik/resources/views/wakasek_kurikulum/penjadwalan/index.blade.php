@extends('layouts.app')

@section('page-title', 'Penjadwalan Mata Pelajaran')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Penjadwalan Mata Pelajaran</h5>
        <a href="{{ route('kurikulum.penjadwalan.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Tambah Jadwal
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

		<form method="GET" action="{{ route('kurikulum.penjadwalan.index') }}" class="row g-2 mb-3">
            <div class="col-auto">
                <select name="kelas_id" class="form-select">
                    <option value="">-- Semua Kelas --</option>
                    @foreach($kelasList as $k)
                        <option value="{{ $k->id }}" {{ request('kelas_id') == $k->id ? 'selected' : '' }}>
                            {{ $k->nama_kelas }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-auto">
                <select name="hari" class="form-select">
                    <option value="">-- Semua Hari --</option>
                    @foreach(['Senin','Selasa','Rabu','Kamis','Jumat'] as $h)
                        <option value="{{ $h }}" {{ request('hari') == $h ? 'selected' : '' }}>{{ $h }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="{{ route('kurikulum.penjadwalan.index') }}" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>
        <div class="table-responsive">
           <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th class="text-nowrap">No</th>
                        <th class="text-nowrap">Kelas</th>
                        <th class="text-nowrap">Mata Pelajaran</th>
                        <th class="text-nowrap">Guru</th>
                        <th class="text-nowrap">Hari</th>
                        <th class="text-nowrap">Jam</th>
                        <th class="text-nowrap">Jumlah Jam</th>
                        <th class="text-nowrap">Tahun Ajaran</th>
                        <th class="text-nowrap">Semester</th>
                        <th class="text-nowrap">Status</th>
                        <th class="text-nowrap">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($jadwal as $index => $j)
                    <tr>
                        <td>{{ $jadwal->firstItem() + $index }}</td>
                        <td>{{ $j->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $j->mataPelajaran->kode_mapel ?? '-' }}</td>
                        <td>{{ $j->guru->nama ?? '-' }}</td>
                        <td>{{ $j->hari }}</td>
                        <td>{{ date('H.i', strtotime($j->jam_mulai)) }} - {{ date('H.i', strtotime($j->jam_selesai)) }}</td>
                        <td class="text-center">{{ $j->jumlah_jam }} jam</td>
                        <td>{{ $j->tahun_ajaran }}</td>
                        <td>Semester {{ $j->semester }}</td>
                        <td>
                            @if($j->status == 'draft')
                                <span class="badge bg-secondary">Draft</span>
                            @elseif($j->status == 'menunggu_persetujuan')
                                <span class="badge bg-warning text-dark">Menunggu Persetujuan
                                </span>
                            @elseif($j->status == 'disetujui')
                                <span class="badge bg-success">Disetujui
                                </span>
                            @elseif($j->status == 'ditolak')
                                <span class="badge bg-danger">Ditolak
                                </span>
                            @endif
                        </td>
                        <td class="text-center text-nowrap" style="min-width: 140px;">
                            <a href="{{ route('kurikulum.penjadwalan.show', $j->id) }}" class="btn btn-sm btn-info">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="{{ route('kurikulum.penjadwalan.edit', $j->id) }}" class="btn btn-sm btn-warning">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="{{ route('kurikulum.penjadwalan.destroy', $j->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Hapus data ini?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="11" class="text-center text-muted">Belum ada jadwal</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $jadwal->links('pagination::bootstrap-5') }}
    </div>
</div>
@endsection