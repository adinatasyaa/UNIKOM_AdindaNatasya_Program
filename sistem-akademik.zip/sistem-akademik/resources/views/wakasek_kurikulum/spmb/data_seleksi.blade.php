@extends('layouts.app')

@section('page-title', 'Data Seleksi')

@section('sidebar')
<a href="{{ route('kurikulum.dashboard') }}" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
<a href="{{ route('kurikulum.spmb.index') }}" class="nav-link"><i class="bi bi-person-plus me-2"></i> Data SPMB</a>
<a href="{{ route('kurikulum.spmb.data_seleksi') }}" class="nav-link active"><i class="bi bi-clipboard-check me-2"></i> Data Seleksi</a>
<a href="{{ route('kurikulum.spmb.hasil_seleksi') }}" class="nav-link"><i class="bi bi-award me-2"></i> Data Hasil Seleksi</a>
@endsection

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Seleksi (Absensi Tes)</h5>
        <a href="{{ route('kurikulum.spmb.data_seleksi.download') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-download me-1"></i> Download PDF
        </a>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID Pendaftaran</th>
                    <th>Nama Siswa</th>
                    <th>Ruangan</th>
                </tr>
            </thead>
            <tbody>
                @forelse($spmb as $i => $s)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $s->id_pendaftaran }}</td>
                    <td>{{ $s->nama_lengkap }}</td>
                    <td>{{ $s->ruangan ?? '-' }}</td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center text-muted">Belum ada siswa yang dijadwalkan tes</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection