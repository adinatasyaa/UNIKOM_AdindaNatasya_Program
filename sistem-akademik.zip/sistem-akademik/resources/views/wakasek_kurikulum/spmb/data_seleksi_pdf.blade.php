<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .header-table td { border: none; vertical-align: middle; padding: 0; }
        .header-table .logo-cell { width: 70px; }
        .header-table .logo-cell img { width: 60px; height: auto; }
        .header-table .text-cell { text-align: center; }
        .header-table h3 { margin: 0; font-size: 16px; }
        .header-table p { margin: 2px 0 0 0; font-size: 12px; }
        hr { border: none; border-top: 2px solid #333; margin: 5px 0 15px 0; }
        table.data { width: 100%; border-collapse: collapse; }
        table.data th, table.data td { border: 1px solid #333; padding: 6px 8px; text-align: left; }
        table.data th { background: #eee; }
        .ttd { margin-top: 40px; }
    </style>
</head>
<body>
    <table class="header-table">
        <tr>
            <td class="logo-cell">
                <img src="data:image/png;base64,{{ $logoBase64 }}">
            </td>
            <td class="text-cell">
                <h3>DAFTAR ABSENSI TES SPMB</h3>
                <p>SMP LABSCHOOL UPI KAMPUS CIBIRU</p>
                <p>TAHUN PELAJARAN 2026/2027</p>
            </td>
            <td class="logo-cell"></td>
        </tr>
    </table>
    <hr>

    <table class="data">
        <thead>
            <tr>
                <th style="width: 5%;">No</th>
                <th style="width: 20%;">ID Pendaftaran</th>
                <th>Nama Siswa</th>
                <th style="width: 15%;">Ruangan</th>
                <th style="width: 15%;">Tanda Tangan</th>
            </tr>
        </thead>
        <tbody>
            @foreach($spmb as $i => $s)
            <tr>
                <td>{{ $i + 1 }}</td>
                <td>{{ $s->id_pendaftaran }}</td>
                <td>{{ $s->nama_lengkap }}</td>
                <td>{{ $s->ruangan ?? '-' }}</td>
                <td></td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="ttd">
        <p>Bandung, {{ now()->translatedFormat('d F Y') }}</p>
        <br><p>Panitia SPMB</p>
    </div>
</body>
</html>