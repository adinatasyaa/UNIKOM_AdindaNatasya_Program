@extends('layouts.app')

@section('page-title', 'Data Hasil Seleksi')

@section('sidebar')
<a href="{{ route('kurikulum.dashboard') }}" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
<a href="{{ route('kurikulum.spmb.index') }}" class="nav-link"><i class="bi bi-person-plus me-2"></i> Data SPMB</a>
<a href="{{ route('kurikulum.spmb.data_seleksi') }}" class="nav-link"><i class="bi bi-clipboard-check me-2"></i> Data Seleksi</a>
<a href="{{ route('kurikulum.spmb.hasil_seleksi') }}" class="nav-link active"><i class="bi bi-award me-2"></i> Data Hasil Seleksi</a>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Data Hasil Seleksi</h5>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID Pendaftaran</th>
                    <th>Nama Siswa</th>
                    <th>Hasil Tes</th>
                </tr>
            </thead>
            <tbody>
                @forelse($spmb as $i => $s)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $s->id_pendaftaran }}</td>
                    <td>{{ $s->nama_lengkap }}</td>
                    <td>
                        <form action="{{ route('kurikulum.spmb.hasil_seleksi.update', $s->id) }}" method="POST" class="d-flex gap-2">
                            @csrf
                            <select name="hasil_seleksi" class="form-select form-select-sm" style="width: 160px;">
                                <option value="menunggu" {{ $s->hasil_seleksi == 'menunggu' ? 'selected' : '' }} disabled>Menunggu</option>
                                <option value="lulus" {{ $s->hasil_seleksi == 'lulus' ? 'selected' : '' }}>Lulus</option>
                                <option value="tidak_lulus" {{ $s->hasil_seleksi == 'tidak_lulus' ? 'selected' : '' }}>Tidak Lulus</option>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center text-muted">Belum ada siswa yang mengikuti tes</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection