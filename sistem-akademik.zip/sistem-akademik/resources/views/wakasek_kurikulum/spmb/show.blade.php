@extends('layouts.app')

@section('page-title', 'Detail SPMB')

@section('sidebar')
<a href="{{ route('kurikulum.dashboard') }}" class="nav-link">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="{{ route('kurikulum.spmb.index') }}" class="nav-link active">
    <i class="bi bi-person-plus me-2"></i> Data SPMB
</a>
@endsection

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Pendaftaran SPMB</h5>
        <a href="{{ route('kurikulum.spmb.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="row">
            <div class="col-md-6">
                <h6 class="fw-bold text-primary">Data Siswa</h6>
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Nama Lengkap</td>
                        <td><strong>{{ $spmb->nama_lengkap }}</strong></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>{{ $spmb->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan' }}</td>
                    </tr>
                    <tr>
                        <td>Asal Sekolah</td>
                        <td>{{ $spmb->asal_sekolah }}</td>
                    </tr>
                    <tr>
                        <td>No. Kontak Siswa</td>
                        <td>{{ $spmb->no_kontak_siswa }}</td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>{{ $spmb->alamat }}</td>
                    </tr>
                </table>

                <h6 class="fw-bold text-primary mt-3">Data Orang Tua</h6>
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Nama Orang Tua</td>
                        <td>{{ $spmb->nama_orang_tua }}</td>
                    </tr>
                    <tr>
                        <td>No. Kontak Orang Tua</td>
                        <td>{{ $spmb->no_kontak_orang_tua }}</td>
                    </tr>
                </table>

                <h6 class="text-primary fw-bold">Data Konfirmasi Orang Tua</h6>
                <table class="table table-bordered">
                    <tr>
                        <th width="35%">Status Konfirmasi</th>
                    <td>
                @if($spmb->status == 'konfirmasi')
                    <span class="badge bg-success">Sudah Konfirmasi</span>
                @else
                    <span class="badge bg-secondary">Belum Konfirmasi</span>
                @endif
                    </td>
                    </tr>
            </table>
                <h6 class="fw-bold text-primary mt-3">Dokumen Upload</h6>
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Kartu Keluarga</td>
                        <td>
                            @if($spmb->kartu_keluarga)
                                <a href="{{ asset('storage/' . $spmb->kartu_keluarga) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye me-1"></i> Lihat File
                                </a>
                            @else
                                <span class="text-muted">Belum diupload</span>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <td>Akte Kelahiran</td>
                        <td>
                            @if($spmb->akte_kelahiran)
                                <a href="{{ asset('storage/' . $spmb->akte_kelahiran) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye me-1"></i> Lihat File
                                </a>
                            @else
                                <span class="text-muted">Belum diupload</span>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <td>KTP Orang Tua</td>
                        <td>
                            @if($spmb->ktp_orang_tua)
                                <a href="{{ asset('storage/' . $spmb->ktp_orang_tua) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye me-1"></i> Lihat File
                                </a>
                            @else
                                <span class="text-muted">Belum diupload</span>
                            @endif
                        </td>
                    </tr>
                </table>
            </div>
                @if(in_array($spmb->status, ['pending', 'diterima']))

                <h6 class="fw-bold text-primary mt-3">Status Persetujuan Wakasek Kurikulum</h6>
                    <form action="{{ route('kurikulum.spmb.update', $spmb->id) }}" method="POST">
                @csrf
                @method('PUT')

        <div class="mb-3">
            <label class="form-label">Aksi Persetujuan</label>
                <select name="status" class="form-select" required>
                    <option value="pending" {{ $spmb->status == 'pending' ? 'selected' : '' }}>Menunggu</option>
                    <option value="diterima" {{ $spmb->status == 'diterima' ? 'selected' : '' }}>Setujui / Diterima</option>
                    <option value="ditolak">Tolak</option>
                </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Tanggal Tes (Jika Data Lengkap)</label>
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-calendar-event"></i></span>
                <input type="text" name="tanggal_tes" id="tanggal_tes_input" class="form-control"
                    placeholder="Pilih tanggal" value="{{ $spmb->tanggal_tes }}" autocomplete="off" readonly>
            </div>
                <small class="text-muted d-block mt-1">
                    <span class="badge bg-danger">&nbsp;</span> Penuh / Tidak Tersedia &nbsp;
                    <span class="badge bg-primary">&nbsp;</span> Tersedia
                </small>
            </div>
        <div class="mb-3">
            <label>Jam Tes</label>
            <input type="time" name="jam_tes" class="form-control"
                value="{{ old('jam_tes', $spmb->jam_tes) }}">
        </div>
        <div class="mb-3">
            <label class="form-label">Ruangan Kelas</label>
            <input type="text" name="ruangan" id="ruangan_input" class="form-control" placeholder="Contoh: Ruang 7A"
                value="{{ old('ruangan', $spmb->ruangan) }}">
        </div>
        <div class="mb-3">
            <label class="form-label">Keterangan / Catatan Kurikulum</label>
            <textarea name="keterangan" class="form-control" rows="3">{{ $spmb->keterangan }}</textarea>
        </div>

            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-save me-1"></i> Simpan Keputusan
            </button>
    </form>

            @else

            <h6 class="fw-bold text-primary mt-3">Status Persetujuan Wakasek Kurikulum</h6>

        <div class="alert alert-success">
            <strong>Status Saat Ini :</strong>
            @if($spmb->status == 'diterima')
                <span class="badge bg-success">Diterima</span>
            @elseif($spmb->status == 'konfirmasi')
                <span class="badge bg-info text-dark">Sudah Konfirmasi</span>
            @elseif($spmb->status == 'ditolak')
                <span class="badge bg-danger">Ditolak</span>
            @endif
        </div>

            @endif
                </div>
            </div>
        </div>
    </div>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        .flatpickr-day.tanggal-penuh { background: #dc3545 !important; color: white !important; border-color: #dc3545 !important; }
        .flatpickr-day.tanggal-tersedia { background: #0d6efd !important; color: white !important; border-color: #0d6efd !important; }
    </style>
    <script>
    let kuotaData = [];

    function formatTanggal(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    fetch("{{ route('kurikulum.spmb.kuota.json') }}")
        .then(res => res.json())
        .then(data => {
            kuotaData = data;

            flatpickr("#tanggal_tes_input", {
    dateFormat: "Y-m-d",
    defaultDate: "{{ $spmb->tanggal_tes }}",
    disable: [
        function(date) {
            const tgl = formatTanggal(date);
            const cocok = kuotaData.find(d => d.tanggal === tgl);
            return !cocok || cocok.penuh;
        }
    ],
    onDayCreate: function(dObj, dStr, fp, dayElem) {
        const tgl = formatTanggal(dayElem.dateObj);
        const cocok = kuotaData.find(d => d.tanggal === tgl);

        if (!cocok) return; 

        if (cocok.penuh) {
            dayElem.classList.add('tanggal-penuh');
        } else {
            dayElem.classList.add('tanggal-tersedia');
        }
    }
});
 });
</script>
@endsection