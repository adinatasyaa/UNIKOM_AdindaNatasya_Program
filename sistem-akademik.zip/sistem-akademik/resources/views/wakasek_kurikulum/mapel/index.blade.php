@extends('layouts.app')

@section('page-title', 'Kelola Mata Pelajaran')

@section('sidebar')
<a href="{{ route('kurikulum.dashboard') }}" class="nav-link {{ request()->routeIs('kurikulum.dashboard') ? 'active' : '' }}">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="{{ route('kurikulum.spmb.index') }}" class="nav-link {{ request()->routeIs('kurikulum.spmb.index', 'kurikulum.spmb.show') ? 'active' : '' }}">
    <i class="bi bi-person-plus me-2"></i> Data SPMB
</a>
<a href="{{ route('kurikulum.mapel.index') }}" class="nav-link {{ request()->routeIs('kurikulum.mapel.*') ? 'active' : '' }}">
    <i class="bi bi-book me-2"></i> Kelola Mata Pelajaran
</a>
<a href="{{ route('kurikulum.penjadwalan.index') }}" class="nav-link {{ request()->routeIs('kurikulum.penjadwalan.*') ? 'active' : '' }}">
    <i class="bi bi-calendar-event me-2"></i> Penjadwalan
</a>
<a href="{{ route('kurikulum.spmb.data_seleksi') }}" class="nav-link {{ request()->routeIs('kurikulum.spmb.data_seleksi', 'kurikulum.spmb.data_seleksi.*') ? 'active' : '' }}">
    <i class="bi bi-clipboard-check me-2"></i> Data Seleksi
</a>
<a href="{{ route('kurikulum.spmb.hasil_seleksi') }}" class="nav-link {{ request()->routeIs('kurikulum.spmb.hasil_seleksi', 'kurikulum.spmb.hasil_seleksi.*') ? 'active' : '' }}">
    <i class="bi bi-award me-2"></i> Data Hasil Seleksi
</a>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Kelola Alokasi Waktu Mata Pelajaran</h5>
        <small class="text-muted">Atur jam pelajaran per minggu untuk tiap mapel sebelum membuat jadwal.</small>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger">
                {{ $errors->first() }}
            </div>
        @endif

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama Mata Pelajaran</th>
                    <th>Guru Pengampu</th>
                    <th>Alokasi Waktu (jam/minggu)</th>
                </tr>
            </thead>
            <tbody>
                @forelse($mapel as $index => $m)
                <tr>
                    <td>{{ $mapel->firstItem() + $index }}</td>
                    <td>{{ $m->kode_mapel }}</td>
                    <td>{{ $m->nama_mapel }}</td>
                    <td>{{ $m->guru->nama ?? '-' }}</td>
                    <td>
                        <form action="{{ route('kurikulum.mapel.update_alokasi', $m->id) }}" method="POST" class="d-flex gap-2">
                            @csrf
                            @method('PUT')
                            <input type="number" name="alokasi_waktu" class="form-control form-control-sm" style="width: 90px;" min="1" max="40" value="{{ $m->alokasi_waktu }}" required>
                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="5" class="text-center text-muted">Belum ada data mata pelajaran</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $mapel->links('pagination::bootstrap-5') }}
    </div>
</div>
@endsection