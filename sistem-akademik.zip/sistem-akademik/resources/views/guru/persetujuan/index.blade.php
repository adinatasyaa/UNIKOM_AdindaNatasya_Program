@extends('layouts.app')

@section('page-title', 'Persetujuan Jadwal Mengajar')

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Daftar Permohonan Persetujuan Jadwal</h5>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Hari</th>
                        <th>Jam Mengajar</th>
                        <th>Tahun Ajaran / Sem.</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($persetujuan as $index => $p)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $p->jadwal->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $p->jadwal->mataPelajaran->kode_mapel ?? '-' }}</td>
                        <td>{{ $p->jadwal->hari }}</td>
                        <td>{{ $p->jadwal->jam_mulai }} - {{ $p->jadwal->jam_selesai }}</td>
                        <td>{{ $p->jadwal->tahun_ajaran }} (Smstr {{ $p->jadwal->semester }})</td>
                        <td>
                            @if($p->status == 'menunggu')
                                <span class="badge bg-warning text-dark">Menunggu Review</span>
                            @elseif($p->status == 'disetujui')
                                <span class="badge bg-success">Sudah Disetujui</span>
                            @elseif($p->status == 'ditolak')
                                <span class="badge bg-danger">Anda Tolak</span>
                                @if($p->catatan)
                                    <small class="d-block text-muted">Ket: {{ $p->catatan }}</small>
                                @endif
                            @endif
                        </td>
                        <td>
                            @if($p->status == 'menunggu')
                                <form action="{{ route('guru.persetujuan-jadwal.proses', $p->id) }}" method="POST" class="d-inline"
                                    onsubmit="return confirm('Apakah Anda menyetujui jadwal mengajar ini?')">
                                    @csrf
                                    <input type="hidden" name="aksi" value="setuju">
                                    <button class="btn btn-success btn-sm" title="Setujui">
                                        <i class="bi bi-check-lg"></i> Setuju
                                    </button>
                                </form>

                                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalTolak{{ $p->id }}">
                                    <i class="bi bi-x-lg"></i> Tolak
                                </button>

                                <div class="modal fade" id="modalTolak{{ $p->id }}" data-bs-backdrop="static" tabindex="-1">
                                    <div class="modal-dialog">
                                        <form action="{{ route('guru.persetujuan.proses', $p->id) }}" method="POST">
                                            @csrf
                                            <input type="hidden" name="aksi" value="tolak">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Alasan Penolakan Jadwal</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="text-muted small">Berikan alasan mengapa jadwal ini ditolak (misal: bentrok dengan jam luar sekolah, dsb).</p>
                                                    <div class="mb-3">
                                                        <label class="form-label">Catatan / Alasan <span class="text-danger">*</span></label>
                                                        <textarea name="catatan" class="form-control" rows="3" required placeholder="Tulis alasan di sini..."></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-danger btn-sm">Kirim Penolakan</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            @else
                                <span class="text-muted small">- Tidak ada aksi -</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center text-muted">Belum ada permohonan persetujuan jadwal.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection