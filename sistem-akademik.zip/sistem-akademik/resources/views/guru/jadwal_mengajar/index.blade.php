@extends('layouts.app')

@section('page-title', 'Jadwal Mengajar')

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Jadwal Mengajar Saya</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Berikut adalah jadwal mengajar yang telah ditetapkan oleh Wakasek Kurikulum.
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Hari</th>
                        <th>Jam</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($jadwal as $index => $j)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $j->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $j->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $j->hari }}</td>
                        <td>{{ date('H.i', strtotime($j->jam_mulai)) }} - {{ date('H.i', strtotime($j->jam_selesai)) }}</td>
                        <td>{{ $j->tahun_ajaran }}</td>
                        <td>Semester {{ $j->semester }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada jadwal mengajar untuk Anda</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection