@extends('layouts.app')

@section('page-title', 'Penilaian Siswa')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="mb-0">Setting Bobot Penilaian</h5>
        <div class="d-flex gap-2 flex-wrap align-items-center">
            <form action="{{ route('guru.bobot.recalculate') }}" method="POST"
                onsubmit="return confirm('Hitung ulang predikat semua siswa berdasarkan setting predikat terbaru?')">
                @csrf
                <button class="btn btn-outline-warning btn-sm">
                    <i class="bi bi-arrow-repeat me-1"></i> Update Predikat
                </button>
            </form>
            @if($bobot->count() > 0)
            <a href="{{ route('guru.penilaian.pilih_kelas.default') }}" class="btn btn-success btn-sm">
                <i class="bi bi-pencil-square me-1"></i> Input Nilai
            </a>
            @endif
            <a href="{{ route('guru.bobot.create') }}" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Buat Bobot Baru
            </a>
        </div>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Mata Pelajaran</th>
                        <th>Kelas</th>
                        <th>Komponen</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($bobot as $index => $b)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $b->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>
                            @forelse($b->daftarKelas as $namaKelas)
                                {{ $namaKelas }}{{ !$loop->last ? ', ' : '' }}
                            @empty
                            -
                            @endforelse
                        </td>
                        <td>
                            @foreach($b->komponen as $k)
                                <span class="badge bg-secondary">{{ $k->nama_komponen }} ({{ $k->persentase }}%)</span>
                            @endforeach
                        </td>
                        <td>{{ $b->tahun_ajaran }}</td>
                        <td>Semester {{ $b->semester }}</td>

						<td>
    						<div class="d-flex gap-1">
        						<a href="{{ route('guru.bobot.edit', $b->id) }}" class="btn btn-warning btn-sm">
            						<i class="bi bi-pencil"></i>
        						</a>
        						<a href="{{ route('guru.bobot.show', $b->id) }}" class="btn btn-info btn-sm">
            						<i class="bi bi-eye"></i>
        						</a>
        						<form action="{{ route('guru.bobot.destroy', $b->id) }}" method="POST" class="d-inline"
            						onsubmit="return confirm('Yakin ingin menghapus bobot ini? Data nilai terkait juga akan terhapus!')">
            						@csrf
            						@method('DELETE')
            						<button class="btn btn-danger btn-sm">
               		 					<i class="bi bi-trash"></i>
            						</button>
        						</form>
    						</div>
						</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada bobot penilaian dibuat</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.getElementById('formInputNilai')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const bobotId = document.getElementById('pilihBobotNilai').value;
    if (!bobotId) return;

    const url = "{{ route('guru.penilaian.pilih_kelas', ':id') }}".replace(':id', bobotId);
    window.location.href = url;
});
</script>
@endsection