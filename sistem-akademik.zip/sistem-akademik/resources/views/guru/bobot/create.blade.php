@extends('layouts.app')

@section('page-title', 'Buat Bobot Penilaian')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Setting Bobot Penilaian</h5>
        <a href="{{ route('guru.bobot.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('guru.bobot.store') }}" method="POST" id="formBobot">
            @csrf
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Mata Pelajaran <span class="text-danger">*</span></label>
                    <select name="mata_pelajaran_id" class="form-select" required>
                        <option value="">-- Pilih Mata Pelajaran --</option>
                        @foreach($mapel as $m)
                            <option value="{{ $m->id }}" {{ old('mata_pelajaran_id') == $m->id ? 'selected' : '' }}>
                                {{ $m->nama_mapel }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                    <input type="text" name="tahun_ajaran" class="form-control"
                        value="{{ old('tahun_ajaran', '2026/2027') }}" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Semester <span class="text-danger">*</span></label>
                    <select name="semester" class="form-select" required>
                        <option value="">-- Pilih Semester --</option>
                        <option value="1" {{ old('semester') == '1' ? 'selected' : '' }}>Semester 1</option>
                        <option value="2" {{ old('semester') == '2' ? 'selected' : '' }}>Semester 2</option>
                    </select>
                </div>
            </div>

            <hr>
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold mb-0">Komponen Penilaian</h6>
                <button type="button" class="btn btn-outline-primary btn-sm" onclick="tambahKomponen()">
                    <i class="bi bi-plus-circle me-1"></i> Tambah Komponen
                </button>
            </div>

            <div id="komponenWrapper">
                <div class="row g-2 mb-2 komponen-row">
                    <div class="col-md-5">
                        <input type="text" name="komponen[0][nama]" class="form-control" placeholder="Nama komponen (contoh: Tugas 1)" required>
                    </div>
                    <div class="col-md-3">
                        <select name="komponen[0][jenis]" class="form-select" required>
                            <option value="tugas">Tugas</option>
                            <option value="uts">UTS</option>
                            <option value="uas">UAS</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="number" name="komponen[0][persentase]" class="form-control persentase-input" placeholder="Persentase %" min="1" max="100" required oninput="hitungTotal()">
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-danger btn-sm" onclick="hapusKomponen(this)">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="alert mt-3" id="totalAlert">
                Total Persentase: <strong id="totalPersentase">0</strong>%
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan Bobot
                </button>
                <a href="{{ route('guru.bobot.index') }}" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>

<script>
let komponenIndex = 1;

function tambahKomponen() {
    const wrapper = document.getElementById('komponenWrapper');
    const row = document.createElement('div');
    row.className = 'row g-2 mb-2 komponen-row';
    row.innerHTML = `
        <div class="col-md-5">
            <input type="text" name="komponen[${komponenIndex}][nama]" class="form-control" placeholder="Nama komponen" required>
        </div>
        <div class="col-md-3">
            <select name="komponen[${komponenIndex}][jenis]" class="form-select" required>
                <option value="tugas">Tugas</option>
                <option value="uts">UTS</option>
                <option value="uas">UAS</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="number" name="komponen[${komponenIndex}][persentase]" class="form-control persentase-input" placeholder="Persentase %" min="1" max="100" required oninput="hitungTotal()">
        </div>
        <div class="col-md-1">
            <button type="button" class="btn btn-danger btn-sm" onclick="hapusKomponen(this)">
                <i class="bi bi-trash"></i>
            </button>
        </div>
    `;
    wrapper.appendChild(row);
    komponenIndex++;
}

function hapusKomponen(btn) {
    btn.closest('.komponen-row').remove();
    hitungTotal();
}

function hitungTotal() {
    const inputs = document.querySelectorAll('.persentase-input');
    let total = 0;
    inputs.forEach(input => {
        total += parseInt(input.value) || 0;
    });
    document.getElementById('totalPersentase').textContent = total;

    const alertBox = document.getElementById('totalAlert');
    if (total === 100) {
        alertBox.className = 'alert alert-success mt-3';
    } else {
        alertBox.className = 'alert alert-warning mt-3';
    }
}

document.getElementById('formBobot').addEventListener('submit', function(e) {
    const inputs = document.querySelectorAll('.persentase-input');
    let total = 0;
    inputs.forEach(input => {
        total += parseInt(input.value) || 0;
    });
    if (total !== 100) {
        e.preventDefault();
        alert('Total persentase harus 100%! Saat ini: ' + total + '%');
    }
});
</script>
@endsection