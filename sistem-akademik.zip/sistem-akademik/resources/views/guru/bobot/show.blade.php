@extends('layouts.app')

@section('page-title', 'Detail Bobot Penilaian')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Bobot Penilaian</h5>
        <a href="{{ route('guru.bobot.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <table class="table table-bordered mb-4">
            <tr>
                <td width="30%">Mata Pelajaran</td>
                <td><strong>{{ $bobot->mataPelajaran->nama_mapel ?? '-' }}</strong></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td>
                    @forelse($bobot->daftarKelas as $namaKelas)
                        {{ $namaKelas }}{{ !$loop->last ? ', ' : '' }}
                    @empty
                        -
                    @endforelse
                </td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td>{{ $bobot->tahun_ajaran }}</td>
            </tr>
            <tr>
                <td>Semester</td>
                <td>Semester {{ $bobot->semester }}</td>
            </tr>
        </table>
    </div>
        <h6 class="fw-bold mb-3">Komponen Penilaian</h6>
        <table class="table table-bordered">

            <thead style="font-weight:600;">
                <tr>
                    <th style="width:60px;">No</th>
                    <th>Nama Komponen</th>
                    <th>Jenis</th>
                    <th>Persentase</th>
                </tr>
            </thead>
            <tbody>
                @foreach($bobot->komponen as $index => $k)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $k->nama_komponen }}</td>
                    <td><span class="badge bg-secondary">{{ ucfirst($k->jenis) }}</span></td>
                    <td>{{ $k->persentase }}%</td>
                </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr class="fw-bold">
                    <td colspan="3" class="text-end">Total</td>
                    <td>{{ $bobot->komponen->sum('persentase') }}%</td>
                </tr>
            </tfoot>
        </table>

        <h6 class="fw-bold mb-3 mt-4">Tabel Nilai Siswa</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="font-weight:600;">
                    <tr>
                        <th style="width:60px;">No</th>
                        <th>Kelas</th>
                        <th>Nama Siswa</th>
                        <th>Nilai Akhir</th>
                        <th>Predikat</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($daftarNilai as $index => $nilai)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $nilai->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $nilai->siswa->nama ?? '-' }}</td>
                        <td>{{ $nilai->nilai_akhir ?? '-' }}</td>
                        <td>
                            @if($nilai->predikat)
                                <span class="badge bg-info text-dark">{{ $nilai->predikat }}</span>
                            @else
                                -
                            @endif
                        </td>
                        <td>
                            @if($nilai->status == 'final')
                                <span class="badge bg-success">Final</span>
                            @elseif($nilai->status == 'lengkap')
                                <span class="badge bg-primary">Lengkap</span>
                            @else
                                <span class="badge bg-warning text-dark">Belum Lengkap</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada nilai siswa yang diinput untuk mata pelajaran ini.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <a href="{{ route('guru.penilaian.pilih_kelas', $bobot->id) }}" class="btn btn-success">
            
        <a href="{{ route('guru.penilaian.pilih_kelas', $bobot->id) }}" class="btn btn-success">
            <i class="bi bi-pencil-square me-1"></i> Input Nilai Siswa
        </a>
    </div>
</div>
@endsection