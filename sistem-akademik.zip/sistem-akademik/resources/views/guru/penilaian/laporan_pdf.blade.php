<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .header-table td { border: none; vertical-align: middle; padding: 0; }
        .header-table .logo-cell { width: 70px; }
        .header-table .logo-cell img { width: 60px; height: auto; }
        .header-table .text-cell { text-align: center; }
        .header-table h3 { margin: 0; font-size: 16px; }
        .header-table p { margin: 2px 0 0 0; font-size: 12px; }
        hr { border: none; border-top: 2px solid #333; margin: 5px 0 15px 0; }
        table.data { width: 100%; border-collapse: collapse; }
        table.data th, table.data td { border: 1px solid #333; padding: 6px 8px; text-align: center; }
        table.data th { background: #eee; }
        table.data td.nama { text-align: left; }
        .info { margin-bottom: 10px; }
        .info td { border: none; padding: 2px 0; text-align: left; }
        .ttd { margin-top: 40px; }
    </style>
</head>
<body>
    <table class="header-table">
        <tr>
            <td class="logo-cell">
                <img src="data:image/jpeg;base64,{{ $logoBase64 }}">
            </td>
            <td class="text-cell">
                <h3>LAPORAN NILAI SISWA</h3>
                <p>SMP LABSCHOOL UPI KAMPUS CIBIRU</p>
            </td>
            <td class="logo-cell"></td>
        </tr>
    </table>
    <hr>

    <table class="info">
        <tr><td width="120">Mata Pelajaran</td><td>: {{ $bobot->mataPelajaran->nama_mapel }}</td></tr>
        <tr><td>Kelas</td><td>: {{ $kelas->nama_kelas }}</td></tr>
        <tr><td>Semester</td><td>: {{ $bobot->semester }}</td></tr>
        <tr><td>Tahun Ajaran</td><td>: {{ $bobot->tahun_ajaran }}</td></tr>
    </table>

    <table class="data">
        <thead>
            <tr>
                <th style="width: 4%;">No</th>
                <th style="width: 12%;">NIS</th>
                <th style="width: 22%;">Nama Siswa</th>
                @foreach($bobot->komponen as $k)
                    <th>{{ $k->nama_komponen }} ({{ $k->persentase }}%)</th>
                @endforeach
                <th>Nilai Akhir</th>
                <th>Predikat</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            @foreach($dataSiswa as $i => $d)
            <tr>
                <td>{{ $i + 1 }}</td>
                <td>{{ $d['siswa']->nis }}</td>
                <td class="nama">{{ $d['siswa']->nama }}</td>
                @foreach($bobot->komponen as $k)
                    <td>{{ $d['nilai'][$k->id] }}</td>
                @endforeach
                <td>{{ $d['penilaian']->nilai_akhir ?? '-' }}</td>
                <td>{{ $d['penilaian']->predikat ?? '-' }}</td>
                <td>{{ $d['penilaian']->keterangan ?? '-' }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="ttd">
        <p>Bandung, {{ now()->translatedFormat('d F Y') }}</p>
        <br><p>{{ auth()->user()->name ?? 'Guru Mata Pelajaran' }}</p>
    </div>
</body>
</html>