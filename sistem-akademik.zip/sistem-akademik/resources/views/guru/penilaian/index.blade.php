@extends('layouts.app')

@section('page-title', 'Input Nilai')

@section('content')
<div class="card">
    
<div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Input Nilai — {{ $bobot->mataPelajaran->nama_mapel ?? '-' }} ({{ $kelas->nama_kelas }})</h5>
    <div class="d-flex gap-2">
        <a href="{{ route('guru.penilaian.pilih_kelas', $bobot->id) }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Ganti Kelas
        </a>
        <a href="{{ route('guru.penilaian.unduh', [$bobot->id, $kelas->id]) }}" class="btn btn-success btn-sm">
            <i class="bi bi-download me-1"></i> Unduh Laporan
        </a>
    </div>
</div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <table class="table table-bordered mb-4">
            <tr>
                <td width="30%">Mata Pelajaran</td>
                <td><strong>{{ $bobot->mataPelajaran->nama_mapel ?? '-' }}</strong></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td>{{ $kelas->nama_kelas }}</td>
            </tr>
            <tr>
                <td>Semester</td>
                <td>Semester {{ $bobot->semester }}</td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td>{{ $bobot->tahun_ajaran }}</td>
            </tr>
        </table>
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Bobot: 
            @foreach($bobot->komponen as $k)
                <span class="badge bg-secondary">{{ $k->nama_komponen }} ({{ $k->persentase }}%)</span>
            @endforeach
        </div>

        <form action="{{ route('guru.penilaian.store', [$bobot->id, $kelas->id]) }}" method="POST">
            @csrf
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead style="font-weight:600;">
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            @foreach($bobot->komponen as $k)
                                <th>{{ $k->nama_komponen }}<br><small>({{ $k->persentase }}%)</small></th>
                            @endforeach
                            <th>Nilai Akhir</th>
                            <th>Predikat</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($dataSiswa as $index => $d)
                        <tr style="{{ $d['penilaian']->status == 'belum_lengkap' ? 'background-color:#f8d7da;' : '' }}">
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $d['siswa']->nis }}</td>
                            <td>{{ $d['siswa']->nama }}</td>
                            @foreach($bobot->komponen as $k)
                            <td>
                                <input type="number" step="0.01" min="0" max="100"
                                    name="nilai[{{ $d['penilaian']->id }}][{{ $k->id }}]"
                                    class="form-control form-control-sm"
                                    value="{{ $d['nilai'][$k->id] }}"
                                    {{ $d['penilaian']->status == 'final' ? 'readonly' : '' }}>
                            </td>
                            @endforeach
                            <td><strong>{{ $d['penilaian']->nilai_akhir ?? '-' }}</strong></td>
                            <td class="text-center">
                                @if($d['penilaian']->predikat)
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <span class="badge bg-primary">{{ $d['penilaian']->predikat }}</span>
                                        <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                            {{ $d['penilaian']->keterangan }}
                                        </span>
                                    </div>
                                @else
                                 -
                                @endif
                            </td>
                            <td>
                                @if($d['penilaian']->status == 'final')
                                    <span class="badge bg-success">Final</span>
                                @elseif($d['penilaian']->status == 'lengkap')
                                    <span class="badge bg-info">Lengkap</span>
                                @else
                                    <span class="badge bg-danger">Belum Lengkap</span>
                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10" class="text-center text-muted">Belum ada siswa di kelas ini</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-3 d-flex gap-2">
                <button type="submit" name="aksi" value="sementara" class="btn btn-warning">
                    <i class="bi bi-save me-1"></i> Simpan Sementara
                </button>
                <button type="submit" name="aksi" value="final" class="btn btn-success"
                    onclick="return confirm('Yakin ingin menyimpan nilai secara FINAL? Data tidak bisa diubah lagi setelah ini.')">
                    <i class="bi bi-check-circle me-1"></i> Simpan Final
                </button>
            </div>
        </form>
    </div>
</div>
@endsection