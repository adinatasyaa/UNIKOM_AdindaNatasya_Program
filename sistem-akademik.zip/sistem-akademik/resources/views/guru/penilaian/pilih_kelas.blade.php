@extends('layouts.app')

@section('page-title', 'Pilih Kelas')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Pilih Kelas — {{ $bobot->mataPelajaran->nama_mapel ?? '-' }}</h5>
        <a href="{{ route('guru.bobot.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <p class="text-muted">Pilih kelas untuk menginput nilai siswa.</p>
        <div class="row g-3">
            @forelse($kelas as $k)
            <div class="col-md-3">
                <a href="{{ route('guru.penilaian.index', [$bobot->id, $k->id]) }}" class="text-decoration-none">
                    <div class="card text-center p-3 h-100" style="border:1px solid #dee2e6; transition:.2s;"
                        onmouseover="this.style.boxShadow='0 4px 10px rgba(0,0,0,0.1)'"
                        onmouseout="this.style.boxShadow='none'">
                        <i class="bi bi-door-open fs-2 text-primary mb-2"></i>
                        <h6 class="mb-0">{{ $k->nama_kelas }}</h6>
                    </div>
                </a>
            </div>
            @empty
            <div class="col-12 text-center text-muted py-4">
                Belum ada kelas tersedia.
            </div>
            @endforelse
        </div>
    </div>
</div>
@endsection