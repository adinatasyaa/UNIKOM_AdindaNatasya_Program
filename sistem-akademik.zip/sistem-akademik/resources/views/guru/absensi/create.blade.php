@extends('layouts.app')

@section('page-title', 'Input Absensi')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Input Absensi</h5>
        <a href="{{ route('guru.absensi.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div id="alertJadwal" class="alert alert-warning" style="display:none;"></div>

        <form action="{{ route('guru.absensi.store') }}" method="POST" id="formAbsensi">
            @csrf

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Kelas <span class="text-danger">*</span></label>
                    <select class="form-select" id="kelasSelect" required>
                        <option value="">-- Pilih Kelas --</option>
                        @foreach($daftarKelas as $k)
                            <option value="{{ $k->id }}">{{ $k->nama_kelas }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div id="infoJadwal" class="row g-3 mb-4" style="display:none;">
                <div class="col-md-4">
                    <label class="form-label">Mata Pelajaran</label>
                    <input type="text" class="form-control" id="infoMapel" readonly>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" id="infoTanggal"
                        value="{{ date('Y-m-d') }}" readonly required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Jam Pelajaran</label>
                    <input type="text" class="form-control" id="infoJam" readonly>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Semester</label>
                    <input type="text" class="form-control" id="infoSemester" readonly>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tahun Ajaran</label>
                    <input type="text" class="form-control" id="infoTahunAjaran" readonly>
                </div>
            </div>

            <input type="hidden" name="kelas_id" id="hiddenKelasId">
            <input type="hidden" name="mata_pelajaran_id" id="hiddenMapelId">
            <input type="hidden" name="jam_pelajaran" id="hiddenJamPelajaran">
            <input type="hidden" name="semester" id="hiddenSemester">
            <input type="hidden" name="tahun_ajaran" id="hiddenTahunAjaran">

            <div id="tabelAbsensi" style="display:none;">
                <h6 class="fw-bold mb-3">Daftar Kehadiran Siswa</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead style="font-weight:600;">
                            <tr>
                                <th>No</th>
                                <th>NIS</th>
                                <th>Nama Siswa</th>
                                <th>Status Kehadiran</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody id="siswaTbody"></tbody>
                    </table>
                </div>
                <button type="submit" class="btn btn-primary mt-3">
                    <i class="bi bi-save me-1"></i> Simpan Absensi
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('kelasSelect').addEventListener('change', function() {
    const kelasId = this.value;
    const alertBox = document.getElementById('alertJadwal');
    const infoJadwal = document.getElementById('infoJadwal');
    const tabelAbsensi = document.getElementById('tabelAbsensi');

    alertBox.style.display = 'none';
    infoJadwal.style.display = 'none';
    tabelAbsensi.style.display = 'none';

    if (!kelasId) return;

    fetch(`/guru/absensi/jadwal/${kelasId}`)
        .then(res => res.json().then(data => ({ status: res.status, body: data })))
        .then(({ status, body }) => {
            if (status !== 200) {
                alertBox.textContent = body.error;
                alertBox.style.display = 'block';
                return;
            }

            document.getElementById('hiddenKelasId').value = kelasId;
            document.getElementById('hiddenMapelId').value = body.jadwal.mata_pelajaran_id;
            document.getElementById('hiddenJamPelajaran').value = body.jadwal.jam_pelajaran;
            document.getElementById('hiddenSemester').value = body.jadwal.semester;
            document.getElementById('hiddenTahunAjaran').value = body.jadwal.tahun_ajaran;

            document.getElementById('infoMapel').value = body.jadwal.mata_pelajaran_nama;
            document.getElementById('infoJam').value = body.jadwal.jam_pelajaran;
            document.getElementById('infoSemester').value = 'Semester ' + body.jadwal.semester;
            document.getElementById('infoTahunAjaran').value = body.jadwal.tahun_ajaran;

            infoJadwal.style.display = 'flex';

            const tbody = document.getElementById('siswaTbody');
            tbody.innerHTML = '';

            if (body.siswa.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">Tidak ada siswa di kelas ini</td></tr>';
            } else {
                body.siswa.forEach((s, i) => {
                    tbody.innerHTML += `
                    <tr>
                        <td>${i + 1}</td>
                        <td>${s.nis}</td>
                        <td>${s.nama}</td>
                        <td>
                            <select name="kehadiran[${s.id}][status]" class="form-select form-select-sm" required>
                                <option value="Hadir">Hadir</option>
                                <option value="Izin">Izin</option>
                                <option value="Sakit">Sakit</option>
                                <option value="Alpa">Alpa</option>
                            </select>
                        </td>
                        <td>
                            <input type="text" name="kehadiran[${s.id}][keterangan]"
                                class="form-control form-control-sm" placeholder="Keterangan (opsional)">
                        </td>
                    </tr>`;
                });
            }

            tabelAbsensi.style.display = 'block';
        });
});
</script>
@endsection