@extends('layouts.app')

@section('page-title', 'Absensi')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Absensi</h5>
        <a href="{{ route('guru.absensi.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Input Absensi
        </a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Jam Pelajaran</th>
                        <th>Semester</th>
                        <th>Tahun Ajaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($absensi as $index => $a)
                    <tr>
                        <td>{{ $absensi->firstItem() + $index }}</td>
                        <td>{{ \Carbon\Carbon::parse($a->tanggal)->format('d/m/Y') }}</td>
                        <td>{{ $a->kelas->nama_kelas ?? '-' }}</td>
                        <td>{{ $a->mataPelajaran->nama_mapel ?? '-' }}</td>
                        <td>{{ $a->jam_pelajaran }}</td>
                        <td>Semester {{ $a->semester }}</td>
                        <td>{{ $a->tahun_ajaran }}</td>
                        <td>
                            <a href="{{ route('guru.absensi.show', $a->id) }}" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="{{ route('guru.absensi.edit', $a->id) }}" class="btn btn-warning btn-sm">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="{{ route('guru.absensi.destroy', $a->id) }}" method="POST" class="d-inline"
                                onsubmit="return confirm('Yakin ingin menghapus absensi ini?')">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-danger btn-sm">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center text-muted">Belum ada data absensi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $absensi->links('pagination::bootstrap-5') }}
    </div>
</div>
@endsection