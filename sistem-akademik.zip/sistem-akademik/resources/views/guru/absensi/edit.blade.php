@extends('layouts.app')

@section('page-title', 'Edit Absensi')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Absensi</h5>
        <a href="{{ route('guru.absensi.show', $absensi->id) }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <!-- Informasi Absensi -->
        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Mata Pelajaran</td>
                        <td><strong>{{ $absensi->mataPelajaran->nama_mapel ?? '-' }}</strong></td>
                    </tr>
                    <tr>
                        <td>Kelas</td>
                        <td>{{ $absensi->kelas->nama_kelas ?? '-' }}</td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td>{{ \Carbon\Carbon::parse($absensi->tanggal)->format('d/m/Y') }}</td>
                    </tr>
                    <tr>
                        <td>Jam Pelajaran</td>
                        <td>{{ $absensi->jam_pelajaran }}</td>
                    </tr>
                    <tr>
                        <td>Semester</td>
                        <td>Semester {{ $absensi->semester }}</td>
                    </tr>
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td>{{ $absensi->tahun_ajaran }}</td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Form Edit Kehadiran -->
        <form action="{{ route('guru.absensi.update', $absensi->id) }}" method="POST">
            @csrf
            @method('PUT')

            <h6 class="fw-bold mb-3">Edit Kehadiran Siswa</h6>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead style="font-weight:600;">
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Status Kehadiran</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($absensi->detail as $index => $d)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $d->siswa->nis ?? '-' }}</td>
                            <td>{{ $d->siswa->nama ?? '-' }}</td>
                            <td>
                                <select name="kehadiran[{{ $d->id }}][status]" class="form-select form-select-sm" required>
                                    <option value="Hadir" {{ $d->status_kehadiran == 'Hadir' ? 'selected' : '' }}>Hadir</option>
                                    <option value="Izin" {{ $d->status_kehadiran == 'Izin' ? 'selected' : '' }}>Izin</option>
                                    <option value="Sakit" {{ $d->status_kehadiran == 'Sakit' ? 'selected' : '' }}>Sakit</option>
                                    <option value="Alpa" {{ $d->status_kehadiran == 'Alpa' ? 'selected' : '' }}>Alpa</option>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="kehadiran[{{ $d->id }}][keterangan]"
                                    class="form-control form-control-sm"
                                    value="{{ $d->keterangan }}"
                                    placeholder="Keterangan (opsional)">
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center text-muted">Belum ada data kehadiran</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn btn-primary mt-3">
                <i class="bi bi-save me-1"></i> Simpan Perubahan
            </button>
        </form>
    </div>
</div>
@endsection