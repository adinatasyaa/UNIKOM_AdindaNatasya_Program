<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SpmbPublicController;

Route::get('/', function () {
    return view('welcome');
});

// Default dashboard
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Profile
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Operator
Route::middleware(['auth', 'role:operator'])->prefix('operator')->name('operator.')->group(function () {
    Route::get('/dashboard', function () {
        return view('operator.dashboard');
    })->name('dashboard');

    Route::resource('siswa', \App\Http\Controllers\Operator\SiswaController::class);
    Route::post('siswa/import', [\App\Http\Controllers\Operator\SiswaController::class, 'import'])->name('siswa.import');
    Route::resource('guru', \App\Http\Controllers\Operator\GuruController::class);
    Route::post('guru/import', [\App\Http\Controllers\Operator\GuruController::class, 'import'])->name('guru.import');
    Route::resource('kelas', \App\Http\Controllers\Operator\KelasController::class)->parameters(['kelas' => 'kelas']);
    Route::resource('mapel', \App\Http\Controllers\Operator\MataPelajaranController::class);
    Route::resource('predikat', \App\Http\Controllers\Operator\PredikatController::class);
});

// Wakasek Kurikulum
Route::middleware(['auth', 'role:wakasek_kurikulum'])->prefix('kurikulum')->name('kurikulum.')->group(function () {
    Route::get('/dashboard', function () {
        return view('kurikulum.dashboard');
    })->name('dashboard');

    Route::get('/dashboard', function () {
    $total_pending = \App\Models\Spmb::where('status', 'pending')->count();
        $total_diterima = \App\Models\Spmb::where('status', 'diterima')->count();
        $total_ditolak = \App\Models\Spmb::where('status', 'ditolak')->count();
        $total_jadwal = \App\Models\PenjadwalanMataPelajaran::count(); 
        return view('kurikulum.dashboard', compact('total_pending', 'total_diterima', 'total_ditolak', 'total_jadwal'));
    })->name('dashboard');

    Route::post('spmb/kuota', [\App\Http\Controllers\WakasekKurikulum\SpmbController::class, 'storeKuota'])->name('spmb.kuota.store');
    Route::get('spmb/kuota-json', [\App\Http\Controllers\WakasekKurikulum\SpmbController::class, 'kuotaJson'])->name('spmb.kuota.json');
    Route::get('spmb/data-seleksi', [\App\Http\Controllers\WakasekKurikulum\SpmbController::class, 'dataSeleksi'])->name('spmb.data_seleksi');
    Route::get('spmb/data-seleksi/download', [\App\Http\Controllers\WakasekKurikulum\SpmbController::class, 'downloadSeleksi'])->name('spmb.data_seleksi.download');
    Route::get('spmb/hasil-seleksi', [\App\Http\Controllers\WakasekKurikulum\SpmbController::class, 'hasilSeleksi'])->name('spmb.hasil_seleksi');
    Route::post('spmb/hasil-seleksi/{id}', [\App\Http\Controllers\WakasekKurikulum\SpmbController::class, 'updateHasilSeleksi'])->name('spmb.hasil_seleksi.update');
    Route::resource('spmb', \App\Http\Controllers\WakasekKurikulum\SpmbController::class)->only(['index', 'show', 'update', 'destroy']);
    Route::resource('penjadwalan', \App\Http\Controllers\WakasekKurikulum\PenjadwalanController::class);
    Route::get('penjadwalan/kelas/{kelas_id}', [PenjadwalanController::class, 'index'])->name('penjadwalan.index');
    Route::post('penjadwalan/{id}/kirim', [\App\Http\Controllers\WakasekKurikulum\PenjadwalanController::class, 'kirimPersetujuan'])->name('penjadwalan.kirim');
    Route::post('penjadwalan/{id}/publish', [\App\Http\Controllers\WakasekKurikulum\PenjadwalanController::class, 'publish'])->name('penjadwalan.publish');
    Route::get('penjadwalan/mapel-by-guru/{guru_id}', [\App\Http\Controllers\WakasekKurikulum\PenjadwalanController::class, 'getMapelByGuru'])->name('penjadwalan.mapel_by_guru');
    Route::get('mapel', [\App\Http\Controllers\WakasekKurikulum\MataPelajaranController::class, 'index'])->name('mapel.index');
    Route::put('mapel/{mapel}', [\App\Http\Controllers\WakasekKurikulum\MataPelajaranController::class, 'updateAlokasi'])->name('mapel.update_alokasi');
    Route::get('penjadwalan/sisa-kuota', [\App\Http\Controllers\WakasekKurikulum\PenjadwalanController::class, 'sisaKuota'])->name('penjadwalan.sisa_kuota');
});

// Wakasek Kesiswaan
Route::middleware(['auth', 'role:wakasek_kesiswaan'])->prefix('kesiswaan')->name('kesiswaan.')->group(function () {
    Route::get('/dashboard', function () {
        return view('kesiswaan.dashboard');
    })->name('dashboard');
    // Pembagian Kelas
    Route::get('registrasi', [\App\Http\Controllers\WakasekKesiswaan\RegistrasiSiswaController::class, 'index'])->name('registrasi.index');
    Route::put('registrasi/{siswa}/nis', [\App\Http\Controllers\WakasekKesiswaan\RegistrasiSiswaController::class, 'updateNis'])->name('registrasi.update_nis');
    Route::resource('pembagian', \App\Http\Controllers\WakasekKesiswaan\PembagianKelasController::class);
    Route::post('pembagian-siswa/{id}/pindah', [\App\Http\Controllers\WakasekKesiswaan\PembagianKelasController::class, 'pindahSiswa'])->name('pembagian.pindah');
    Route::post('pembagian/rilis', [\App\Http\Controllers\WakasekKesiswaan\PembagianKelasController::class, 'rilisKeSiswa'])->name('pembagian.rilis');
});

// Kepala Sekolah
Route::middleware(['auth', 'role:kepala_sekolah'])->prefix('kepala-sekolah')->name('kepala_sekolah.')->group(function () {
        Route::get('/dashboard', function () {
            return view('kepala_sekolah.dashboard');
        })->name('dashboard');
        // Pembagian Guru Piket
        Route::resource('pembagian-guru-piket',\App\Http\Controllers\KepalaSekolah\PembagianGuruPiketController::class);
        // Jadwal Pelajaran
        Route::get('jadwal',[\App\Http\Controllers\KepalaSekolah\JadwalPelajaranController::class, 'index'])->name('jadwal.index');
        Route::post('jadwal/{id}/setujui',[\App\Http\Controllers\KepalaSekolah\JadwalPelajaranController::class, 'setujui'])->name('jadwal.setujui');
        Route::post('jadwal/{id}/tolak',[\App\Http\Controllers\KepalaSekolah\JadwalPelajaranController::class, 'tolak'])->name('jadwal.tolak');
        Route::get('/pembagian-kelas',[\App\Http\Controllers\KepalaSekolah\PersetujuanPembagianKelasController::class, 'index'])->name('pembagian-kelas.index');
        Route::post('/pembagian-kelas/{id}/setujui',[\App\Http\Controllers\KepalaSekolah\PersetujuanPembagianKelasController::class, 'setujui'])->name('pembagian-kelas.setujui');
        Route::post('/pembagian-kelas/{id}/tolak',[\App\Http\Controllers\KepalaSekolah\PersetujuanPembagianKelasController::class, 'tolak'])->name('pembagian-kelas.tolak');
        // Absensi
        Route::get('/absensi',[\App\Http\Controllers\KepalaSekolah\AbsensiController::class, 'index'])->name('absensi.index');
        // Penilaian
        Route::get('/penilaian',[\App\Http\Controllers\KepalaSekolah\PenilaianController::class, 'index'])->name('penilaian.index');
});

// Guru Mata Pelajaran
Route::middleware(['auth', 'role:guru,wakasek_kurikulum,wakasek_kesiswaan'])->prefix('guru')->name('guru.')->group(function () {
    Route::get('/dashboard', function () {
        return view('guru.dashboard');
    })->name('dashboard');

    Route::resource('absensi', \App\Http\Controllers\Guru\AbsensiController::class);
    Route::get('absensi/siswa/{kelas_id}', [\App\Http\Controllers\Guru\AbsensiController::class, 'getSiswaByKelas'])->name('absensi.siswa');
    Route::get('absensi/jadwal/{kelas_id}', [\App\Http\Controllers\Guru\AbsensiController::class, 'getJadwalByKelas'])->name('absensi.jadwal');
    // Bobot Penilaian
    Route::resource('bobot', \App\Http\Controllers\Guru\BobotPenilaianController::class);
    Route::get('bobot/tahun-semester/{mapel_id}', [\App\Http\Controllers\Guru\BobotPenilaianController::class, 'getTahunSemesterByMapel'])->name('bobot.tahun_semester');
    Route::post('bobot/recalculate-predikat', [\App\Http\Controllers\Guru\BobotPenilaianController::class, 'recalculatePredikat'])->name('bobot.recalculate');
    Route::get('penilaian/pilih-kelas', [\App\Http\Controllers\Guru\PenilaianController::class, 'pilihKelas'])->name('penilaian.pilih_kelas.default');
    Route::get('penilaian/{bobot_id}/pilih-kelas', [\App\Http\Controllers\Guru\PenilaianController::class, 'pilihKelas'])->name('penilaian.pilih_kelas');
    Route::get('penilaian/{bobot_id}/{kelas_id}', [\App\Http\Controllers\Guru\PenilaianController::class, 'index'])->name('penilaian.index');
    Route::post('penilaian/{bobot_id}/{kelas_id}', [\App\Http\Controllers\Guru\PenilaianController::class, 'store'])->name('penilaian.store');
    Route::get('penilaian/{bobot_id}/{kelas_id}/unduh', [\App\Http\Controllers\Guru\PenilaianController::class, 'unduhLaporan'])->name('penilaian.unduh');
    // Persetujuan Jadwal
    Route::get('persetujuan', [\App\Http\Controllers\Guru\PersetujuanJadwalController::class, 'index'])->name('persetujuan.index');
    Route::post('persetujuan/{id}/proses', [\App\Http\Controllers\Guru\PersetujuanJadwalController::class, 'prosesPersetujuan'])->name('persetujuan.proses');
    // Jadwal Mengajar
    Route::get('jadwal-mengajar', [\App\Http\Controllers\Guru\JadwalMengajarController::class, 'index'])->name('jadwal_mengajar.index');
});

// Wali Kelas
Route::middleware(['auth', 'role:wali_kelas'])->prefix('wali-kelas')->name('wali_kelas.')->group(function () {
    Route::get('/dashboard', function () {
        return view('wali_kelas.dashboard');
    })->name('dashboard');

    Route::get('absensi', [\App\Http\Controllers\WaliKelas\AbsensiController::class, 'index'])->name('absensi.index');
    Route::get('absensi/{id}', [\App\Http\Controllers\WaliKelas\AbsensiController::class, 'show'])->name('absensi.show');
    Route::patch('absensi/{id}', [\App\Http\Controllers\WaliKelas\AbsensiController::class, 'update'])->name('absensi.update');
    Route::get('penilaian', [\App\Http\Controllers\WaliKelas\PenilaianController::class, 'index'])->name('penilaian.index');
    Route::get('penilaian/{kelas_id}', [\App\Http\Controllers\WaliKelas\PenilaianController::class, 'show'])->name('penilaian.show');
    Route::get('penilaian/{kelas_id}/siswa/{siswa_id}', [\App\Http\Controllers\WaliKelas\PenilaianController::class, 'detailSiswa'])->name('penilaian.detail');
    Route::get('penilaian/{kelas_id}/siswa/{siswa_id}/unduh', [\App\Http\Controllers\WaliKelas\PenilaianController::class, 'unduhRapor'])->name('penilaian.unduh');
    Route::get('/pembagian-kelas', [\App\Http\Controllers\WaliKelas\PembagianKelasController::class, 'index'])->name('pembagian_kelas.index');
    Route::get('/pembagian-kelas/{id}', [\App\Http\Controllers\WaliKelas\PembagianKelasController::class, 'show'])->name('pembagian_kelas.show');
});

// Guru Piket
Route::middleware(['auth', 'role:guru_piket'])->prefix('guru-piket')->name('guru_piket.')->group(function () {
    Route::get('/dashboard', function () {
        return view('guru_piket.dashboard');
    })->name('dashboard');
    Route::get('/absensi', [\App\Http\Controllers\GuruPiket\AbsensiPiketController::class, 'index'])->name('absensi.index');
    Route::get('/absensi/create', [\App\Http\Controllers\GuruPiket\AbsensiPiketController::class, 'create'])->name('absensi.create');
    Route::post('/absensi', [\App\Http\Controllers\GuruPiket\AbsensiPiketController::class, 'store'])->name('absensi.store');
    Route::get('/absensi/{id}/edit', [\App\Http\Controllers\GuruPiket\AbsensiPiketController::class, 'edit'])->name('absensi.edit');
    Route::put('/absensi/{id}', [\App\Http\Controllers\GuruPiket\AbsensiPiketController::class, 'update'])->name('absensi.update');
    Route::delete('/absensi/{id}', [\App\Http\Controllers\GuruPiket\AbsensiPiketController::class, 'destroy'])->name('absensi.destroy');
    Route::get('/pembagian-guru-piket', [\App\Http\Controllers\GuruPiket\PembagianGuruPiketController::class, 'index'])->name('pembagian-guru-piket.index');
});

// Siswa
    Route::middleware(['auth','role:siswa'])->prefix('siswa')->name('siswa.')->group(function () {
    Route::get('/dashboard', function () {
        return view('siswa.dashboard');
    })->name('dashboard');
    Route::get('/pembagian-kelas',[\App\Http\Controllers\Siswa\PembagianKelasController::class,'index'])->name('pembagian-kelas.index');
    Route::get('/jadwal',[\App\Http\Controllers\Siswa\JadwalPelajaranController::class,'index'])->name('jadwal.index');
    Route::get('/absensi',[\App\Http\Controllers\Siswa\AbsensiController::class,'index'])->name('absensi.index');
    Route::get('/penilaian',[\App\Http\Controllers\Siswa\PenilaianController::class,'index'])->name('penilaian.index');
});

// Orang Tua
Route::middleware(['auth', 'role:orang_tua'])->prefix('orang-tua')->name('orang_tua.')->group(function () {
    Route::get('/dashboard', function () {
        return view('orang_tua.dashboard');
    })->name('dashboard');
});

Route::prefix('spmb')->group(function () {
    Route::get('/', [SpmbPublicController::class, 'index'])->name('spmb.index');
    Route::view('/sarana-prasarana', 'spmb.sarana-prasarana')->name('sarana-prasarana');
    Route::view('/kegiatan-siswa', 'spmb.kegiatan-siswa')->name('kegiatan-siswa');
    Route::get('/pendaftaran', [SpmbPublicController::class, 'create'])->name('spmb.create');
    Route::post('/pendaftaran', [SpmbPublicController::class, 'store'])->name('spmb.store');
    Route::get('/cek-status', [SpmbPublicController::class, 'cekStatus'])->name('spmb.cek_status');
    Route::post('/cek-status', [SpmbPublicController::class, 'prosesCekStatus'])->name('spmb.cek_status.post');
    Route::get('/konfirmasi', [SpmbPublicController::class, 'showKonfirmasi'])->name('spmb.konfirmasi');
    Route::post('/konfirmasi', [SpmbPublicController::class, 'submitKonfirmasi'])->name('spmb.submit-konfirmasi');
    Route::get('/pengumuman', [SpmbPublicController::class, 'pengumuman'])->name('spmb.pengumuman');
    Route::post('/spmb/pengumuman/cari', [SpmbPublicController::class, 'prosesCariPengumuman'])->name('spmb.proses_cari_pengumuman');

});

require __DIR__.'/auth.php';