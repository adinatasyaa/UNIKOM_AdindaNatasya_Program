<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

       $user = auth()->user();

   return match($user->role) {
    'operator' => redirect()->route('operator.dashboard'),
    'wakasek_kurikulum' => redirect()->route('kurikulum.dashboard'),
    'wakasek_kesiswaan' => redirect()->route('kesiswaan.dashboard'),
    'guru' => redirect()->route('guru.dashboard'),
    'guru_piket' => redirect()->route('guru_piket.dashboard'),
    'wali_kelas' => redirect()->route('wali_kelas.dashboard'),
    'kepala_sekolah' => redirect()->route('kepala_sekolah.dashboard'),
    'siswa' => redirect()->route('siswa.dashboard'),
    default => redirect()->route('dashboard'),
};
    }

    
    public function destroy(Request $request): RedirectResponse
    {
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect()->route('login');
    }
}
