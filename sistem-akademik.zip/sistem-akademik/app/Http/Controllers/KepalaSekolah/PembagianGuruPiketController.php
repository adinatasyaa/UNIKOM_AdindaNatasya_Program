<?php

namespace App\Http\Controllers\KepalaSekolah;

use App\Http\Controllers\Controller;
use App\Models\Guru;
use App\Models\Kelas;
use App\Models\PembagianGuruPiket;
use Illuminate\Http\Request;

class PembagianGuruPiketController extends Controller
{
    public function index()
    {
        $data = PembagianGuruPiket::with('guru')
            ->orderBy('hari')
            ->get();

        return view('kepala_sekolah.index', compact('data'));
    }

    public function create()
    {
        $guru = Guru::where('status','aktif')
                    ->orderBy('nama')
                    ->get();

        $tahunAjaran = Kelas::select('tahun_ajaran')
                            ->distinct()
                            ->pluck('tahun_ajaran');

        return view('kepala_sekolah.create', compact('guru','tahunAjaran'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'guru_id'=>'required',
            'hari'=>'required',
            'tahun_ajaran'=>'required',
            'semester'=>'required'
        ]);

        PembagianGuruPiket::create($request->all());

        return redirect()
            ->route('kepala_sekolah.pembagian-guru-piket.index')
            ->with('success','Data berhasil ditambahkan');
    }

    public function edit($id)
    {
        $piket = PembagianGuruPiket::findOrFail($id);

        $guru = Guru::where('status','aktif')
                    ->orderBy('nama')
                    ->get();

        $tahunAjaran = Kelas::select('tahun_ajaran')
                            ->distinct()
                            ->pluck('tahun_ajaran');

        return view('kepala_sekolah.edit',
            compact('piket','guru','tahunAjaran'));
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'guru_id'=>'required',
            'hari'=>'required',
            'tahun_ajaran'=>'required',
            'semester'=>'required'
        ]);

        $piket = PembagianGuruPiket::findOrFail($id);

        $piket->update($request->all());

        return redirect()
            ->route('kepala_sekolah.pembagian-guru-piket.index')
            ->with('success','Data berhasil diubah');
    }

    public function destroy($id)
    {
        PembagianGuruPiket::findOrFail($id)->delete();

        return redirect()
            ->route('kepala_sekolah.pembagian-guru-piket.index')
            ->with('success','Data berhasil dihapus');
    }
}