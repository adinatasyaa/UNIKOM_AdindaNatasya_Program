<?php

namespace App\Http\Controllers\KepalaSekolah;

use App\Http\Controllers\Controller;
use App\Models\AbsensiDetail;
use App\Models\Kelas;
use Illuminate\Http\Request;

class AbsensiController extends Controller
{
    public function index(Request $request)
    {
        $kelas = Kelas::orderBy('tingkat')->orderBy('nama_kelas')->get();

        $data = collect();

        if ($request->kelas_id) {

            $data = AbsensiDetail::with([
                'siswa',
                'absensi.guru',
                'absensi.mataPelajaran',
                'absensi.kelas'
            ])
            ->whereHas('absensi', function ($q) use ($request){
                $q->where('kelas_id',$request->kelas_id);
            })
            ->get()
            ->sortBy(function ($item) {
                return $item->siswa->nama ?? '';
            })
            ->values();

        }

        return view(
            'kepala_sekolah.absensi.index',
            compact('kelas','data')
        );
  }
}