<?php

namespace App\Http\Controllers\KepalaSekolah;

use App\Http\Controllers\Controller;
use App\Models\Kelas;
use App\Models\Penilaian;
use Illuminate\Http\Request;

class PenilaianController extends Controller
{
    public function index(Request $request)
{
    $kelas = Kelas::orderBy('tingkat')->orderBy('nama_kelas')->get();

        $data = collect();

        if($request->kelas_id){

            $data = Penilaian::with([
                'siswa',
                'guru',
                'mataPelajaran'
            ])
            ->where('kelas_id',$request->kelas_id)
            ->get();

        }

        return view(
            'kepala_sekolah.penilaian.index',
            compact('kelas','data')
        );
    }
}