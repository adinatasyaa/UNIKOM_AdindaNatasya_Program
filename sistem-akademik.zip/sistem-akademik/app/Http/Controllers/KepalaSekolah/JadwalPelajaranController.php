<?php

namespace App\Http\Controllers\KepalaSekolah;

use App\Http\Controllers\Controller;
use App\Models\PenjadwalanMataPelajaran;

class JadwalPelajaranController extends Controller
{

    public function index()
    {
        $jadwal = PenjadwalanMataPelajaran::with([
            'kelas',
            'mataPelajaran',
            'guru'
        ])
        ->orderBy('hari')
        ->orderBy('jam_mulai')
        ->paginate(10);

        return view('kepala_sekolah.jadwal.index', compact('jadwal'));
    }
    public function setujui($id)
{
    $jadwal = PenjadwalanMataPelajaran::findOrFail($id);

    $jadwal->update([
        'status' => 'disetujui'
    ]);

    return back()->with('success', 'Jadwal berhasil disetujui.');
}

public function tolak($id)
{
    $jadwal = PenjadwalanMataPelajaran::findOrFail($id);

    $jadwal->update([
        'status' => 'ditolak'
    ]);

    return back()->with('success', 'Jadwal berhasil ditolak.');
}
}