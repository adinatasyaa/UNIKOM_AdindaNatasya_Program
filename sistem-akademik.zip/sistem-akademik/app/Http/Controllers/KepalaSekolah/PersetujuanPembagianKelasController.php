<?php

namespace App\Http\Controllers\KepalaSekolah;

use App\Http\Controllers\Controller;
use App\Models\PembagianKelas;

class PersetujuanPembagianKelasController extends Controller
{
    public function index()
    {
        $data = PembagianKelas::with(['kelas','guru'])
                    ->orderBy('tahun_ajaran')
                    ->get();

        return view('kepala_sekolah.pembagian_kelas.index', compact('data'));
    }

    public function setujui($id)
    {
        $pembagian = PembagianKelas::findOrFail($id);

        $pembagian->update([
            'status_persetujuan' => 'disetujui'
        ]);

        return back()->with('success','Pembagian kelas berhasil disetujui.');
    }

    public function tolak($id)
    {
        $pembagian = PembagianKelas::findOrFail($id);

        $pembagian->update([
            'status_persetujuan' => 'ditolak'
        ]);

        return back()->with('success','Pembagian kelas ditolak.');
    }
}