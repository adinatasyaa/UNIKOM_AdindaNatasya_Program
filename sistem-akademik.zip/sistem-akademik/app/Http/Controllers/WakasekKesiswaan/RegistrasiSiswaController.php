<?php

namespace App\Http\Controllers\WakasekKesiswaan;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use Illuminate\Http\Request;

class RegistrasiSiswaController extends Controller
{
    public function index()
    {
        $siswa = Siswa::with('kelas')
            ->whereNotNull('spmb_id')
            ->orderBy('nama')
            ->paginate(15);

        return view('kesiswaan.registrasi.index', compact('siswa'));
    }

    public function updateNis(Request $request, Siswa $siswa)
    {
        $request->validate([
            'nis' => 'required|unique:siswa,nis,' . $siswa->id,
        ]);

        $siswa->update(['nis' => $request->nis]);

        return redirect()->route('kesiswaan.registrasi.index')
            ->with('success', "NIS {$siswa->nama} berhasil disimpan.");
    }
}