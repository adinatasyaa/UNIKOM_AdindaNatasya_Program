<?php

namespace App\Http\Controllers\WakasekKesiswaan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Kelas;
use App\Models\Guru;
use App\Models\PembagianKelas;
use App\Models\PembagianSiswa;
use Illuminate\Support\Facades\DB;

class PembagianKelasController extends Controller
{
    public function index()
    {
        $riwayatPembagian = PembagianKelas::with(['kelas', 'guru'])->get();
        return view('kesiswaan.pembagian.index', compact('riwayatPembagian'));
    }

    public function create()
	{
    $daftarKelas = Kelas::all();

    $waliTerpakai = Kelas::whereNotNull('wali_kelas_id')->pluck('wali_kelas_id');
    $daftarGuru = Guru::whereNotIn('id', $waliTerpakai)->get();

    return view('kesiswaan.pembagian.create', compact('daftarKelas', 'daftarGuru'));
	}

    public function store(Request $request)
{
    $request->validate([
    	'jumlah_kelas'      => 'required|integer|min:1|max:10',
    	'tahun_ajaran'      => 'required',
    	'semester'          => 'required',
    	'jenis'             => 'required|in:siswa_baru,kenaikan_kelas',
    	'wali_kelas_ids'    => 'required|array',
    	'wali_kelas_ids.*'  => 'required|exists:guru,id',
]);

    $tahun           = $request->tahun_ajaran;
    $semester        = $request->semester;
    $jenis           = $request->jenis;
    $tingkatAsal     = $request->tingkat_asal;
    $jumlahKelasBaru = (int) $request->jumlah_kelas;
    $waliKelasInput  = $request->wali_kelas_ids ?? [];

    $tingkatTujuan = $jenis === 'kenaikan_kelas' ? (string) ((int) $tingkatAsal + 1) : '7';

    $kelasSudahDipakai = PembagianKelas::where('tahun_ajaran', $tahun)
        ->where('semester', $semester)
        ->pluck('kelas_id');

    $kelasTersedia = Kelas::where('tingkat', $tingkatTujuan)
        ->where('tahun_ajaran', $tahun)
        ->whereNotIn('id', $kelasSudahDipakai)
        ->orderBy('nama_kelas')
        ->limit($jumlahKelasBaru)
        ->get();

    if ($kelasTersedia->count() < $jumlahKelasBaru) {
        return redirect()->back()->with('error', 'Kelas kosong yang tersedia di tingkat ' . $tingkatTujuan . ' tahun ' . $tahun . ' tidak cukup. Tersedia: ' . $kelasTersedia->count() . ', diminta: ' . $jumlahKelasBaru . '. Silakan tambah data kelas dulu di menu Operator.');
    }

    $kelasIds = [];
    $guruIds  = [];

    foreach ($kelasTersedia as $i => $kelasItem) {
        $kelasItem->update([
            'wali_kelas_id' => $waliKelasInput[$i] ?? null,
        ]);

    $kelasIds[] = $kelasItem->id;
    $guruIds[$kelasItem->id] = $waliKelasInput[$i] ?? null;
    }

    if ($jenis === 'kenaikan_kelas') {
       $query = Siswa::where('siswa.status', 'aktif')
           ->join('kelas', 'siswa.kelas_id', '=', 'kelas.id')
           ->where('kelas.tingkat', $tingkatAsal);

        try {
            $siswaList = $query->leftJoin('penilaian', 'siswa.id', '=', 'penilaian.siswa_id')
                ->select('siswa.id', DB::raw('AVG(penilaian.nilai_akhir) as rata_rata_nilai'))
                ->groupBy('siswa.id')
                ->orderByDesc('rata_rata_nilai')
                ->get();
        } catch (\Illuminate\Database\QueryException $e) {
            $siswaList = $query->select('siswa.id')->get();
        }
    } else {
        $siswaList = Siswa::where('status', 'aktif')
            ->whereNull('kelas_id')
            ->select('id')
            ->orderBy('nama')
            ->get();
    }

    if ($siswaList->isEmpty()) {
        return redirect()->back()->with('error', 'Tidak ada siswa yang perlu dibagi (semua siswa sudah memiliki kelas atau belum aktif).');
    }

    DB::transaction(function () use ($kelasIds, $guruIds, $tahun, $semester, $siswaList, $jenis) {

        $terisi = [];
        foreach ($kelasIds as $kid) {
            $terisi[$kid] = PembagianSiswa::where('kelas_id', $kid)
                ->where('tahun_ajaran', $tahun)
                ->where('semester', $semester)
                ->count();
        }

       $urutanFinal = $siswaList;

        $indexKelas = 0;
        $jumlahKelas = count($kelasIds);
        $kapasitasDefault = 20;

        foreach ($urutanFinal as $siswa) {
            $percobaan = 0;
            $ditempatkan = false;

            while ($percobaan < $jumlahKelas) {
                $kelasIdSekarang = $kelasIds[$indexKelas];

                if ($terisi[$kelasIdSekarang] < $kapasitasDefault) {
                    PembagianSiswa::create([
                        'siswa_id'         => $siswa->id,
                        'kelas_id'         => $kelasIdSekarang,
                        'tahun_ajaran'     => $tahun,
                        'semester'         => $semester,
                        'status_pembagian' => 'draft',
                    ]);
                    $terisi[$kelasIdSekarang]++;
                    $ditempatkan = true;
                }

                $indexKelas = ($indexKelas + 1) % $jumlahKelas;

                if ($ditempatkan) break;
                $percobaan++;
            }
        }

        foreach ($kelasIds as $idKelas) {
        PembagianKelas::updateOrCreate(
            ['kelas_id' => $idKelas, 'tahun_ajaran' => $tahun, 'semester' => $semester],
            ['guru_id' => $guruIds[$idKelas], 'status_persetujuan' => 'menunggu', 'jenis' => $jenis]
        );
    }
    });

    return redirect()->route('kesiswaan.pembagian.index')
        ->with('success', 'Pembagian kelas berhasil dilakukan! Status masih DRAFT, silakan rilis setelah memastikan datanya benar.');
}

    public function show(string $id)
{
    $pembagianKelas = PembagianKelas::with(['kelas', 'guru'])->findOrFail($id);
    $daftarSiswa = PembagianSiswa::with('siswa')
        ->where('kelas_id', $pembagianKelas->kelas_id)
        ->where('tahun_ajaran', $pembagianKelas->tahun_ajaran)
        ->where('semester', $pembagianKelas->semester)
        ->get();
    $kelasLain = Kelas::where('id', '!=', $pembagianKelas->kelas_id)->get();

    $rataRataNilai = [];
    foreach ($daftarSiswa as $ds) {
        $rata = DB::table('penilaian')
            ->where('siswa_id', $ds->siswa_id)
            ->avg('nilai_akhir');
        $rataRataNilai[$ds->siswa_id] = $rata ? round($rata, 1) : null;
    }

    return view('kesiswaan.pembagian.show', compact('pembagianKelas', 'daftarSiswa', 'kelasLain', 'rataRataNilai'));
	}
   public function edit(string $id)
	{
    $pembagianKelas = PembagianKelas::with('kelas')->findOrFail($id);

    $waliTerpakai = Kelas::whereNotNull('wali_kelas_id')
        ->where('id', '!=', $pembagianKelas->kelas_id)
        ->pluck('wali_kelas_id');
    $daftarGuru = Guru::whereNotIn('id', $waliTerpakai)->get();

    return view('kesiswaan.pembagian.edit', compact('pembagianKelas', 'daftarGuru'));
	}

    public function update(Request $request, string $id)
	{
    $request->validate(['guru_id' => 'required']);
    $pembagian = PembagianKelas::findOrFail($id);

    DB::transaction(function () use ($pembagian, $request) {
        $pembagian->update([
            'guru_id'            => $request->guru_id,
            'status_persetujuan' => 'disetujui',
        ]);

        Kelas::where('id', $pembagian->kelas_id)->update([
            'wali_kelas_id' => $request->guru_id,
        ]);

        $daftarSiswa = PembagianSiswa::where('kelas_id', $pembagian->kelas_id)
            ->where('tahun_ajaran', $pembagian->tahun_ajaran)
            ->where('semester', $pembagian->semester)
            ->get();

        foreach ($daftarSiswa as $ps) {
            Siswa::where('id', $ps->siswa_id)->update(['kelas_id' => $pembagian->kelas_id]);
            $ps->update(['status_pembagian' => 'final']);
        }
    });

    return redirect()->route('kesiswaan.pembagian.index')->with('success', 'Kelas berhasil disetujui dan siswa sudah ditempatkan!');
	}

    public function destroy(string $id)
    {
        $pembagian = PembagianKelas::findOrFail($id);
        DB::transaction(function () use ($pembagian) {
            PembagianSiswa::where('kelas_id', $pembagian->kelas_id)
                ->where('tahun_ajaran', $pembagian->tahun_ajaran)
                ->where('semester', $pembagian->semester)
                ->delete();
            $pembagian->delete();
        });

        return redirect()->route('kesiswaan.pembagian.index')->with('success', 'Data pembagian kelas berhasil di-reset!');
    }

    public function pindahSiswa(Request $request, $id)
    {
        $request->validate(['kelas_baru_id' => 'required']);
        $pembagianSiswa = PembagianSiswa::findOrFail($id);
        $pembagianSiswa->update(['kelas_id' => $request->kelas_baru_id]);

        return redirect()->back()->with('success', 'Siswa berhasil dipindahkan kelas!');
    }

    public function rilisKeSiswa(Request $request)
{
        $tahun_ajaran = $request->input('tahun_ajaran');
        $semester     = $request->input('semester');

        $dataFix = PembagianSiswa::where('tahun_ajaran', $tahun_ajaran)
            ->where('semester', $semester)
            ->get();

        foreach ($dataFix as $d) {
            Siswa::where('id', $d->siswa_id)->update(['kelas_id' => $d->kelas_id]);
            $d->update(['status_pembagian' => 'final']);
        }

        return redirect()->back()->with('success', 'Status Pembagian Kelas sekarang telah FIX dan kelas siswa sudah diperbarui!');
    }
}