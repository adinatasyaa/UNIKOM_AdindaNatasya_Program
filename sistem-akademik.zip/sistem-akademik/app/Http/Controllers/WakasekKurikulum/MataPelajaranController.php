<?php

namespace App\Http\Controllers\WakasekKurikulum;

use App\Http\Controllers\Controller;
use App\Models\MataPelajaran;
use Illuminate\Http\Request;

class MataPelajaranController extends Controller
{
    public function index()
    {
        $mapel = MataPelajaran::with('guru')->orderBy('nama_mapel')->paginate(10);
        return view('wakasek_kurikulum.mapel.index', compact('mapel'));
    }

    public function updateAlokasi(Request $request, MataPelajaran $mapel)
    {
        $request->validate([
            'alokasi_waktu' => 'required|integer|min:1|max:40',
        ]);

        $mapel->update(['alokasi_waktu' => $request->alokasi_waktu]);

        return redirect()->route('kurikulum.mapel.index')
            ->with('success', "Alokasi waktu {$mapel->nama_mapel} ({$mapel->kode_mapel}) berhasil diatur menjadi {$request->alokasi_waktu} jam/minggu.");
    }
}