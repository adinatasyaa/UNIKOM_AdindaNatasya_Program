<?php

namespace App\Http\Controllers\WakasekKurikulum;

use App\Http\Controllers\Controller;
use App\Models\Spmb;
use App\Models\Siswa;
use App\Models\PengumumanSpmb;
use App\Models\KuotaTesSpmb;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class SpmbController extends Controller
{
    public function index()
    {
        $spmb = Spmb::orderBy('created_at', 'desc')->paginate(10);
        $total_pending  = Spmb::where('status', 'pending')->count();
        $total_diterima = Spmb::where('status', 'diterima')->count();
        $total_ditolak  = Spmb::where('status', 'ditolak')->count();
        $total_konfirmasi = Spmb::where('status', 'konfirmasi')->count();

        $kuotaTerakhir = KuotaTesSpmb::orderByDesc('updated_at')->first();

        return view('wakasek_kurikulum.spmb.index', compact(
            'spmb', 'total_pending', 'total_diterima', 'total_ditolak', 'total_konfirmasi', 'kuotaTerakhir'
        ));
    }

    public function show($id)
    {
        $spmb = Spmb::findOrFail($id);
        $batasWaktuTes = KuotaTesSpmb::max('tanggal_akhir');

        return view('wakasek_kurikulum.spmb.show', compact('spmb', 'batasWaktuTes'));
    }

    public function update(Request $request, $id)
    {
        $spmb = Spmb::findOrFail($id);

        $batasWaktuTes = KuotaTesSpmb::max('tanggal_akhir');

        $request->validate([
            'status'       => 'required|in:pending,diterima,ditolak,konfirmasi',
            'tanggal_tes'  => [
                'nullable',
                'date',
                $batasWaktuTes ? "before_or_equal:{$batasWaktuTes}" : '',
            ],
            'jam_tes'      => 'nullable',
            'ruangan' => 'required_if:status,diterima|string|max:50',
            'keterangan'   => 'nullable|string',
        ]);

        $tanggalTes = $request->tanggal_tes;
        $tanggalDigeser = false;

        if ($tanggalTes) {
            $tanggalAsli = $tanggalTes;
            $tanggalTes = $this->cariTanggalTersedia($tanggalTes, $spmb->id);

            if ($tanggalTes !== $tanggalAsli) {
                $tanggalDigeser = true;
            }
        }

        $spmb->update([
            'status'      => $request->status,
            'tanggal_tes' => $tanggalTes,
            'jam_tes'     => $request->jam_tes,
            'ruangan'     => $request->ruangan,
            'keterangan'  => $request->keterangan,
        ]);

        if (in_array($request->status, ['diterima', 'ditolak', 'konfirmasi'])) {
            PengumumanSpmb::updateOrCreate(
                ['nama_siswa' => $spmb->nama_lengkap],
                [
                    'asal_sekolah' => $spmb->asal_sekolah,
                    'status'       => $request->status,
                ]
            );
        }

        if ($request->status === 'konfirmasi') {
            $sudahJadiSiswa = \App\Models\Siswa::where('spmb_id', $spmb->id)->exists();

        if (!$sudahJadiSiswa) {
            \App\Models\Siswa::create([
                'spmb_id'       => $spmb->id,
                'nis'           => null,
                'nama'          => $spmb->nama_lengkap,
                'jenis_kelamin' => $spmb->jenis_kelamin,
                'kelas_id'      => null,
                'status'        => 'aktif',
            ]);
        }
    }

        $pesan = $tanggalDigeser
            ? "Status diperbarui! Catatan: tanggal tes digeser otomatis ke {$tanggalTes} karena kuota tanggal yang dipilih sudah penuh."
            : 'Status pendaftaran SPMB berhasil diperbarui!';

        return redirect()->route('kurikulum.spmb.index')
            ->with('success', $pesan);
    }

    public function storeKuota(Request $request)
	{
    $request->validate([
        'tanggal_mulai' => 'required|date',
        'tanggal_akhir' => 'required|date|after_or_equal:tanggal_mulai',
        'kuota_maks'    => 'required|integer|min:1',
    ]);

    KuotaTesSpmb::updateOrCreate(
        ['tanggal_mulai' => $request->tanggal_mulai],
        [
            'tanggal_akhir' => $request->tanggal_akhir,
            'kuota_maks'    => $request->kuota_maks,
        ]
    );

    return redirect()->route('kurikulum.spmb.index')
        ->with('success', 'Kuota tanggal tes berhasil disimpan!');
	}

    public function kuotaJson()
    {
        $ranges = KuotaTesSpmb::all();
        $data = [];

        foreach ($ranges as $range) {
            $tgl = $range->tanggal_mulai->copy();

            while ($tgl->lte($range->tanggal_akhir)) {
                $terpakai = Spmb::whereDate('tanggal_tes', $tgl->toDateString())->count();

                $data[] = [
                    'tanggal'    => $tgl->toDateString(),
                    'kuota_maks' => $range->kuota_maks,
                    'terpakai'   => $terpakai,
                    'penuh'      => $terpakai >= $range->kuota_maks,
                ];

                $tgl->addDay();
            }
        }

        return response()->json($data);
    }

    private function cariTanggalTersedia($tanggalAwal, $excludeId = null)
    {
        $tanggal = \Carbon\Carbon::parse($tanggalAwal);

        for ($i = 0; $i < 90; $i++) {
            $kuota = KuotaTesSpmb::untukTanggal($tanggal->toDateString());

            if ($kuota) {
                $terpakai = Spmb::whereDate('tanggal_tes', $tanggal->toDateString())
                    ->when($excludeId, fn($q) => $q->where('id', '!=', $excludeId))
                    ->count();

                if ($terpakai < $kuota->kuota_maks) {
                    return $tanggal->toDateString();
                }
            } else {
                return $tanggal->toDateString();
            }

            $tanggal->addDay();
        }

        return $tanggalAwal;
    }

    public function destroy($id)
    {
        $spmb = Spmb::findOrFail($id);

        PengumumanSpmb::where('nama_siswa', $spmb->nama_lengkap)->delete();

        if ($spmb->berkas_rapor && file_exists(public_path('uploads/spmb/' . $spmb->berkas_rapor))) {
            unlink(public_path('uploads/spmb/' . $spmb->berkas_rapor));
        }

        Siswa::where('spmb_id', $spmb->id)->delete();   

        $spmb->delete();

        return redirect()->route('kurikulum.spmb.index')
            ->with('success', 'Data pendaftaran SPMB berhasil dihapus!');
    }
    public function dataSeleksi()
{
    $spmb = Spmb::whereIn('status', ['diterima', 'konfirmasi'])
        ->orderBy('tanggal_tes')
        ->orderBy('nama_lengkap')
        ->get();

    return view('wakasek_kurikulum.spmb.data_seleksi', compact('spmb'));
}

public function downloadSeleksi()
{
    $spmb = Spmb::whereIn('status', ['diterima', 'konfirmasi'])
        ->orderBy('tanggal_tes')
        ->orderBy('nama_lengkap')
        ->get();

    $logoPath = public_path('logoPDF.jpg');
    $logoBase64 = base64_encode(file_get_contents($logoPath));

    $pdf = Pdf::loadView('wakasek_kurikulum.spmb.data_seleksi_pdf', compact('spmb', 'logoBase64'))
        ->setPaper('a4', 'portrait');

    return $pdf->download('absensi-tes-spmb.pdf');
}

    public function hasilSeleksi()
{
    $spmb = Spmb::whereIn('status', ['diterima', 'konfirmasi'])
        ->orderBy('nama_lengkap')
        ->get();

    return view('wakasek_kurikulum.spmb.hasil_seleksi', compact('spmb'));
}

    public function updateHasilSeleksi(Request $request, $id)
    {
        $request->validate([
            'hasil_seleksi' => 'required|in:lulus,tidak_lulus',
        ]);

        $spmb = Spmb::findOrFail($id);
        $spmb->update(['hasil_seleksi' => $request->hasil_seleksi]);

        return redirect()->route('kurikulum.spmb.hasil_seleksi')
            ->with('success', "Hasil seleksi {$spmb->nama_lengkap} berhasil disimpan.");
    }
}