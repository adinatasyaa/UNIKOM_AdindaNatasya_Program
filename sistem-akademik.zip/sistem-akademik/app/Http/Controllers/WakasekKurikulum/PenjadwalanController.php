<?php

namespace App\Http\Controllers\WakasekKurikulum;

use App\Http\Controllers\Controller;
use App\Models\PenjadwalanMataPelajaran;
use App\Models\PersetujuanJadwal;
use App\Models\Kelas;
use App\Models\MataPelajaran;
use App\Models\Guru;
use Illuminate\Http\Request;

class PenjadwalanController extends Controller
{
    public function index(Request $request)
	{
    $table = (new PenjadwalanMataPelajaran)->getTable();

    $query = PenjadwalanMataPelajaran::with(['kelas', 'mataPelajaran', 'guru'])
        ->join('kelas', "$table.kelas_id", '=', 'kelas.id')
        ->select("$table.*");

    if ($request->filled('kelas_id')) {
        $query->where("$table.kelas_id", $request->kelas_id);
    }

    if ($request->filled('hari')) {
        $query->where("$table.hari", $request->hari);
    }

    if ($request->filled('tahun_ajaran')) {
        $query->where("$table.tahun_ajaran", $request->tahun_ajaran);
    }

    $jadwal = $query
        ->orderBy('kelas.nama_kelas')
        ->orderByRaw("FIELD($table.hari, 'Senin','Selasa','Rabu','Kamis','Jumat')")
        ->orderBy("$table.jam_mulai")
        ->paginate(10)
        ->withQueryString();

    $kelasList = Kelas::where('status', 'aktif')->orderBy('nama_kelas')->get();

    return view('wakasek_kurikulum.penjadwalan.index', compact('jadwal', 'kelasList'));
	}

    public function create()
    {
        $kelas      = Kelas::where('status', 'aktif')->orderBy('nama_kelas')->get();
        $mapel      = MataPelajaran::where('status', 'aktif')->orderBy('nama_mapel')->get();
        $guru       = Guru::where('status', 'aktif')->orderBy('nama')->get();

        return view('wakasek_kurikulum.penjadwalan.create', compact('kelas', 'mapel', 'guru'));
    }

    public function getMapelByGuru($guru_id)
    {
    $mapel = MataPelajaran::where('guru_id', $guru_id)
        ->where('status', 'aktif')
        ->select('id', 'kode_mapel')
        ->get();

    return response()->json($mapel);
    }

   public function store(Request $request)
	{
    $request->validate([
        'kelas_id'          => 'required|exists:kelas,id',
        'mata_pelajaran_id' => 'required|exists:mata_pelajaran,id',
        'guru_id'           => 'required|exists:guru,id',
        'hari'              => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat',
        'jam_mulai'         => 'required',
        'jam_selesai'       => 'required|after:jam_mulai',
        'tahun_ajaran'      => 'required|string',
        'semester'          => 'required|in:1,2',
    ]);

    $mulai = \Carbon\Carbon::parse($request->jam_mulai);
    $selesai = \Carbon\Carbon::parse($request->jam_selesai);
    $durasiMenit = $mulai->diffInMinutes($selesai);

    if ($durasiMenit > 240) {
        return back()->withErrors(['jam_selesai' => 'Durasi jadwal tidak boleh lebih dari 4 jam.'])->withInput();
    }

    $bentrokGuru = PenjadwalanMataPelajaran::where('guru_id', $request->guru_id)
        ->where('hari', $request->hari)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester)
        ->where(function ($q) use ($request) {
            $q->where('jam_mulai', '<', $request->jam_selesai)
              ->where('jam_selesai', '>', $request->jam_mulai);
        })
        ->exists();

    if ($bentrokGuru) {
        return back()->withErrors([
            'jam_selesai' => 'Guru ini sudah punya jadwal mengajar di jam yang bentrok pada hari yang sama.'
        ])->withInput();
    }

    $bentrokKelas = PenjadwalanMataPelajaran::where('kelas_id', $request->kelas_id)
        ->where('hari', $request->hari)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester)
        ->where(function ($q) use ($request) {
            $q->where('jam_mulai', '<', $request->jam_selesai)
              ->where('jam_selesai', '>', $request->jam_mulai);
        })
        ->exists();

    if ($bentrokKelas) {
        return back()->withErrors([
            'jam_selesai' => 'Kelas ini sudah punya jadwal mata pelajaran lain di jam yang bentrok.'
        ])->withInput();
    }

    $jumlahJam = (int) round($durasiMenit / 40);

    $mapel = MataPelajaran::findOrFail($request->mata_pelajaran_id);

    $terpakai = PenjadwalanMataPelajaran::where('mata_pelajaran_id', $request->mata_pelajaran_id)
        ->where('kelas_id', $request->kelas_id)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester)
        ->sum('jumlah_jam');

    $sisa = $mapel->alokasi_waktu - $terpakai;

    if ($jumlahJam > $sisa) {
        return back()->withErrors([
            'jam_selesai' => "Kuota jam {$mapel->nama_mapel} untuk kelas ini sudah/hampir habis. Alokasi: {$mapel->alokasi_waktu} jam/minggu, terpakai: {$terpakai} jam, sisa: {$sisa} jam. Input ini butuh {$jumlahJam} jam."
        ])->withInput();
    }

    $jadwal = PenjadwalanMataPelajaran::create([
        'kelas_id'          => $request->kelas_id,
        'mata_pelajaran_id' => $request->mata_pelajaran_id,
        'guru_id'           => $request->guru_id,
        'hari'              => $request->hari,
        'jam_mulai'         => $request->jam_mulai,
        'jam_selesai'       => $request->jam_selesai,
        'jumlah_jam'        => $jumlahJam,
        'tahun_ajaran'      => $request->tahun_ajaran,
        'semester'          => $request->semester,
        'status'            => 'menunggu_persetujuan',
    ]);

    return redirect()->route('kurikulum.penjadwalan.index')
        ->with('success', "Jadwal berhasil ditambahkan ({$jumlahJam} jam pelajaran) dan menunggu persetujuan Kepala Sekolah!");
	}

public function update(Request $request, $id)
{
    $request->validate([
        'kelas_id'          => 'required|exists:kelas,id',
        'mata_pelajaran_id' => 'required|exists:mata_pelajaran,id',
        'guru_id'           => 'required|exists:guru,id',
        'hari'              => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat',
        'jam_mulai'         => 'required',
        'jam_selesai'       => 'required|after:jam_mulai',
        'tahun_ajaran'      => 'required|string',
        'semester'          => 'required|in:1,2',
    ]);

    $jadwal = PenjadwalanMataPelajaran::findOrFail($id);

    $mulai = \Carbon\Carbon::parse($request->jam_mulai);
    $selesai = \Carbon\Carbon::parse($request->jam_selesai);
    $durasiMenit = $mulai->diffInMinutes($selesai);

    if ($durasiMenit > 240) {
        return back()->withErrors(['jam_selesai' => 'Durasi jadwal tidak boleh lebih dari 4 jam.'])->withInput();
    }

    $bentrokGuru = PenjadwalanMataPelajaran::where('guru_id', $request->guru_id)
        ->where('hari', $request->hari)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester)
        ->where('id', '!=', $jadwal->id)
        ->where(function ($q) use ($request) {
            $q->where('jam_mulai', '<', $request->jam_selesai)
              ->where('jam_selesai', '>', $request->jam_mulai);
        })
        ->exists();

    if ($bentrokGuru) {
        return back()->withErrors([
            'jam_selesai' => 'Guru ini sudah punya jadwal mengajar di jam yang bentrok pada hari yang sama.'
        ])->withInput();
    }

    $bentrokKelas = PenjadwalanMataPelajaran::where('kelas_id', $request->kelas_id)
        ->where('hari', $request->hari)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester)
        ->where('id', '!=', $jadwal->id)
        ->where(function ($q) use ($request) {
            $q->where('jam_mulai', '<', $request->jam_selesai)
              ->where('jam_selesai', '>', $request->jam_mulai);
        })
        ->exists();

    if ($bentrokKelas) {
        return back()->withErrors([
            'jam_selesai' => 'Kelas ini sudah punya jadwal mata pelajaran lain di jam yang bentrok.'
        ])->withInput();
    }

    $jumlahJam = (int) round($durasiMenit / 40);

    $mapel = MataPelajaran::findOrFail($request->mata_pelajaran_id);

    $terpakai = PenjadwalanMataPelajaran::where('mata_pelajaran_id', $request->mata_pelajaran_id)
        ->where('kelas_id', $request->kelas_id)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester)
        ->where('id', '!=', $jadwal->id)
        ->sum('jumlah_jam');

    $sisa = $mapel->alokasi_waktu - $terpakai;

    if ($jumlahJam > $sisa) {
        return back()->withErrors([
            'jam_selesai' => "Kuota jam {$mapel->nama_mapel} untuk kelas ini sudah/hampir habis. Alokasi: {$mapel->alokasi_waktu} jam/minggu, terpakai (selain jadwal ini): {$terpakai} jam, sisa: {$sisa} jam. Input ini butuh {$jumlahJam} jam."
        ])->withInput();
    }

    $jadwal->update([
        'kelas_id'          => $request->kelas_id,
        'mata_pelajaran_id' => $request->mata_pelajaran_id,
        'guru_id'           => $request->guru_id,
        'hari'              => $request->hari,
        'jam_mulai'         => $request->jam_mulai,
        'jam_selesai'       => $request->jam_selesai,
        'jumlah_jam'        => $jumlahJam,
        'tahun_ajaran'      => $request->tahun_ajaran,
        'semester'          => $request->semester,
    ]);

    return redirect()->route('kurikulum.penjadwalan.index')
        ->with('success', "Jadwal berhasil diperbarui ({$jumlahJam} jam pelajaran)!");
}

    public function show($id)
    {
        $jadwal = PenjadwalanMataPelajaran::with(['kelas', 'mataPelajaran', 'guru', 'persetujuan.guru'])
            ->findOrFail($id);

        return view('wakasek_kurikulum.penjadwalan.show', compact('jadwal'));
    }

    public function edit($id)
    {
        $jadwal     = PenjadwalanMataPelajaran::findOrFail($id);
        $kelas      = Kelas::where('status', 'aktif')->orderBy('nama_kelas')->get();
        $mapel      = MataPelajaran::where('status', 'aktif')->orderBy('nama_mapel')->get();
        $guru       = Guru::where('status', 'aktif')->orderBy('nama')->get();

        return view('wakasek_kurikulum.penjadwalan.edit', compact('jadwal', 'kelas', 'mapel', 'guru'));
    }

    public function destroy($id)
    {
        $jadwal = PenjadwalanMataPelajaran::findOrFail($id);
        $jadwal->delete();

        return redirect()->route('kurikulum.penjadwalan.index')
            ->with('success', 'Jadwal berhasil dihapus!');
    }

    public function kirimPersetujuan($id)
    {
        $jadwal = PenjadwalanMataPelajaran::findOrFail($id);

        PersetujuanJadwal::updateOrCreate(
            ['jadwal_id' => $jadwal->id, 'guru_id' => $jadwal->guru_id],
            ['status' => 'menunggu', 'catatan' => null]
        );

        $jadwal->update(['status' => 'menunggu_persetujuan']);

        return redirect()->route('kurikulum.penjadwalan.index')
            ->with('success', 'Jadwal berhasil dikirim ke guru untuk persetujuan!');
    }

    public function publish($id)
    {
        $jadwal = PenjadwalanMataPelajaran::findOrFail($id);
    
        if ($jadwal->status !== 'disetujui') {
            return redirect()->back()->with('error', 'Jadwal harus disetujui oleh guru terlebih dahulu!');
    }

    $jadwal->update(['status' => 'disetujui']); 

    return redirect()->route('kurikulum.penjadwalan.index')
            ->with('success', 'Jadwal berhasil dipublish dan sekarang bisa dilihat oleh siswa!');
    }

    public function sisaKuota(Request $request)
    {
    $request->validate([
        'kelas_id'          => 'required|exists:kelas,id',
        'mata_pelajaran_id' => 'required|exists:mata_pelajaran,id',
        'tahun_ajaran'      => 'required|string',
        'semester'          => 'required|in:1,2',
    ]);

    $mapel = MataPelajaran::findOrFail($request->mata_pelajaran_id);

    $query = PenjadwalanMataPelajaran::where('mata_pelajaran_id', $request->mata_pelajaran_id)
        ->where('kelas_id', $request->kelas_id)
        ->where('tahun_ajaran', $request->tahun_ajaran)
        ->where('semester', $request->semester);

    if ($request->filled('exclude_id')) {
        $query->where('id', '!=', $request->exclude_id);
    }

    $terpakai = $query->sum('jumlah_jam');

    return response()->json([
        'nama_mapel' => $mapel->nama_mapel,
        'alokasi'    => $mapel->alokasi_waktu,
        'terpakai'   => $terpakai,
        'sisa'       => $mapel->alokasi_waktu - $terpakai,
    ]);
    }
}