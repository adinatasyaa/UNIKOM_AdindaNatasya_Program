<?php

namespace App\Http\Controllers\GuruPiket;

use App\Http\Controllers\Controller;
use App\Models\AbsensiPiket;
use App\Models\Siswa;
use App\Models\Guru;
use Illuminate\Http\Request;

class AbsensiPiketController extends Controller
{
    public function index()
    {
        $guru = Guru::where('email', auth()->user()->email)->first();

        $absensi = AbsensiPiket::orderBy('tanggal', 'desc');

        if ($guru) {
            $absensi = $absensi->where('guru_piket_id', $guru->id);
        }

        $absensi = $absensi->paginate(10);

        return view('guru_piket.absensi.index', compact('absensi'));
    }

    public function create()
    {
        return view('guru_piket.absensi.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_siswa'   => 'required|string',
            'nama_kelas'   => 'required|string',
            'tanggal'      => 'required|date',
            'status'       => 'required|in:terlambat,izin_pulang,tidak_hadir,izin',
            'keterangan'   => 'nullable|string',
            'tahun_ajaran' => 'required|string',
            'semester'     => 'required|in:1,2',
        ]);

        $guru = Guru::where('email', auth()->user()->email)->first();

        AbsensiPiket::create([
            'siswa_id'      => null,
            'nama_siswa'    => $request->nama_siswa,
            'nama_kelas'    => $request->nama_kelas,
            'guru_piket_id' => $guru?->id,
            'tanggal'       => $request->tanggal,
            'status'        => $request->status,
            'keterangan'    => $request->keterangan,
            'tahun_ajaran'  => $request->tahun_ajaran,
            'semester'      => $request->semester,
        ]);

        return redirect()->route('guru_piket.absensi.index')
            ->with('success', 'Data absensi piket berhasil disimpan!');
    }

    public function edit($id)
    {
       $data_absensi = AbsensiPiket::findOrFail($id);
        
        return view('guru_piket.absensi.edit', [
            'absensi' => $data_absensi
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_siswa'   => 'required|string',
            'nama_kelas'   => 'required|string',
            'tanggal'      => 'required|date',
            'status'       => 'required|in:terlambat,izin_pulang,tidak_hadir,izin',
            'keterangan'   => 'nullable|string',
            'tahun_ajaran' => 'required|string',
            'semester'     => 'required|in:1,2',
        ]);

       $data_absensi = AbsensiPiket::findOrFail($id);
        $data_absensi->update($request->all());

        return redirect()->route('guru_piket.absensi.index')
            ->with('success', 'Data absensi piket berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $absensi = AbsensiPiket::findOrFail($id);
        $absensi->delete();

        return redirect()->route('guru_piket.absensi.index')
            ->with('success', 'Data absensi piket berhasil dihapus!');
    }
}