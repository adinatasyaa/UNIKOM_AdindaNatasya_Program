<?php

namespace App\Http\Controllers\GuruPiket;

use App\Http\Controllers\Controller;
use App\Models\PembagianGuruPiket;
use App\Models\Guru;

class PembagianGuruPiketController extends Controller
{
    public function index()
    {
        $guru = Guru::where('email', auth()->user()->email)->first();

        $data = PembagianGuruPiket::with('guru')
                    ->where('guru_id', $guru?->id)
                    ->orderBy('hari')
                    ->get();

        return view('guru_piket.pembagian_guru_piket.index', compact('data'));
    }
}