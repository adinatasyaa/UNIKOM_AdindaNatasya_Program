<?php

namespace App\Http\Controllers\Operator;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\SiswaImport;

class SiswaController extends Controller
{
   public function index(Request $request)
{
    $query = Siswa::with('kelas');

    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('nama', 'like', "%{$search}%")
              ->orWhere('nis', 'like', "%{$search}%");
        });
    }

    $siswa = $query->orderBy('nama')->paginate(10)->withQueryString();

    return view('operator.siswa.index', compact('siswa'));
}
    public function create()
{
    $kelas = \App\Models\Kelas::where('status', 'aktif')->orderBy('nama_kelas')->get();
    return view('operator.siswa.create', compact('kelas'));
}

    public function store(Request $request)
    {
        $request->validate([
            'nis' => 'required|unique:siswa,nis',
            'nama' => 'required|string|max:255',
            'kelas_id' => 'nullable|exists:kelas,id',
            'jenis_kelamin' => 'nullable|in:L,P',
            'tempat_lahir' => 'nullable|string',
            'tanggal_lahir' => 'nullable|date',
            'status' => 'required|in:aktif,tidak_aktif',

        ]);

        Siswa::create($request->all());

        return redirect()->route('operator.siswa.index')
            ->with('success', 'Data siswa berhasil ditambahkan!');
    }

    public function edit(Siswa $siswa)
{
    $kelas = \App\Models\Kelas::orderBy('nama_kelas')->get();

    return view('operator.siswa.edit', compact('siswa', 'kelas'));
}

    public function update(Request $request, Siswa $siswa)
    {
        $request->validate([
            'nis'                => 'required|unique:siswa,nis,' . $siswa->id,
            'nama'               => 'required|string|max:255',
            'kelas_id'           => 'required|exists:kelas,id',
            'jenis_kelamin'      => 'nullable|in:L,P',
            'email'              => 'nullable|email|unique:users,email,' . optional($siswa->user)->id,
            'tempat_lahir'       => 'nullable|string',
            'tanggal_lahir'      => 'nullable|date',
            'status'             => 'required|in:aktif,tidak_aktif',
        ]);

        $siswa->update($request->all());

    if (!empty($siswa->email)) {
        if ($siswa->user) {
            $siswa->user->update([
                'email' => $request->email,
                'name'  => $request->nama,
            ]);
        } else {
            \App\Models\User::create([
                'name'     => $siswa->nama,
                'email'    => $siswa->email,
                'role'     => 'siswa',
                'password' => \Illuminate\Support\Facades\Hash::make('labschool123'),
                'siswa_id' => $siswa->id,
            ]);
        }
    }

    return redirect()->route('operator.siswa.index')
        ->with('success', 'Data siswa berhasil diperbarui!');
    }

    public function destroy(Siswa $siswa)
    {
        $siswa->delete();
        return redirect()->route('operator.siswa.index')
            ->with('success', 'Data siswa berhasil dihapus!');
    }

    public function import(Request $request)
	{
    $request->validate([
        'file' => 'required|mimes:xlsx,xls',
    ]);

    $sheetData = Excel::toArray([], $request->file('file'));
    $headings = array_map('strtolower', array_map('trim', $sheetData[0][0] ?? []));

    $requiredHeadings = ['nis', 'nama'];
    $missing = array_diff($requiredHeadings, $headings);

    if (!empty($missing)) {
        return redirect()->route('operator.siswa.index')
            ->with('error', 'Format file salah. Kolom wajib tidak ditemukan: ' . implode(', ', $missing));
    }

    Excel::import(new SiswaImport, $request->file('file'));

    return redirect()->route('operator.siswa.index')
        ->with('success', 'Data siswa berhasil diimport!');
	}
}