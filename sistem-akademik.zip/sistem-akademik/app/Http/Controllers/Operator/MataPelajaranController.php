<?php

namespace App\Http\Controllers\Operator;

use App\Http\Controllers\Controller;
use App\Models\MataPelajaran;
use App\Models\Guru;
use Illuminate\Http\Request;

class MataPelajaranController extends Controller
{
    public function index(Request $request)
    {
    $query = MataPelajaran::with('guru');

    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('nama_mapel', 'like', "%{$search}%")
              ->orWhere('kode_mapel', 'like', "%{$search}%")
              ->orWhereHas('guru', function ($gq) use ($search) {
                  $gq->where('nama', 'like', "%{$search}%");
              });
        });
    }

    $mapel = $query->orderBy('nama_mapel')
        ->paginate(10)
        ->withQueryString();

    return view('operator.mapel.index', compact('mapel'));
    }

    public function create()
    {
        $guru = Guru::where('status', 'aktif')->orderBy('nama')->get();
        return view('operator.mapel.create', compact('guru'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'kode_mapel' => 'required|unique:mata_pelajaran,kode_mapel',
            'nama_mapel' => 'required|string|max:255',
            'guru_id'    => 'nullable|exists:guru,id',
            'status'     => 'required|in:aktif,tidak_aktif',
        ]);

        MataPelajaran::create([
            'kode_mapel'    => $request->kode_mapel,
            'nama_mapel'    => $request->nama_mapel,
            'guru_id'       => $request->guru_id,
            'status'        => $request->status,
            'alokasi_waktu' => 0,
        ]);

        return redirect()
            ->route('operator.mapel.index')
            ->with('success', 'Mata pelajaran berhasil ditambahkan! Alokasi waktu perlu diatur oleh Wakasek Kurikulum.');
    }

    public function edit(MataPelajaran $mapel)
    {
        $guru = Guru::where('status', 'aktif')->orderBy('nama')->get();
        return view('operator.mapel.edit', compact('mapel', 'guru'));
    }

    public function update(Request $request, MataPelajaran $mapel)
    {
        $request->validate([
            'kode_mapel' => 'required|unique:mata_pelajaran,kode_mapel,' . $mapel->id,
            'nama_mapel' => 'required|string|max:255',
            'guru_id'    => 'nullable|exists:guru,id',
            'status'     => 'required|in:aktif,tidak_aktif',
        ]);

        $mapel->update([
            'kode_mapel' => $request->kode_mapel,
            'nama_mapel' => $request->nama_mapel,
            'guru_id'    => $request->guru_id,
            'status'     => $request->status,
        ]);

        return redirect()->route('operator.mapel.index')
            ->with('success', 'Mata pelajaran berhasil diperbarui!');
    }

    public function destroy(MataPelajaran $mapel)
    {
        $mapel->delete();
        return redirect()->route('operator.mapel.index')
            ->with('success', 'Mata pelajaran berhasil dihapus!');
    }
}