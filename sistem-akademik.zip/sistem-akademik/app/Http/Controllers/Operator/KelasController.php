<?php

namespace App\Http\Controllers\Operator;

use App\Http\Controllers\Controller;
use App\Models\Kelas;
use App\Models\Guru;
use Illuminate\Http\Request;

class KelasController extends Controller
{
   public function index(Request $request)
{
    $query = Kelas::with('waliKelas');

    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('nama_kelas', 'like', "%{$search}%")
              ->orWhere('tahun_ajaran', 'like', "%{$search}%")
              ->orWhereHas('waliKelas', function ($wq) use ($search) {
                  $wq->where('nama', 'like', "%{$search}%");
              });
        });
    }

    $kelas = $query->orderBy('tingkat')
        ->orderBy('nama_kelas')
        ->paginate(10)
        ->withQueryString();

    return view('operator.kelas.index', compact('kelas'));
}

    public function create()
    {
        $guru = Guru::where('status', 'aktif')
            ->orderBy('nama')
            ->get();

        return view('operator.kelas.create', compact('guru'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_kelas'    => 'required|string|max:20',
            'tingkat'       => 'required|in:7,8,9',
            'tahun_ajaran'  => 'required|string|max:20',
            'wali_kelas_id' => 'nullable|exists:guru,id',
            'status'        => 'required|in:aktif,tidak_aktif',
        ]);

        Kelas::create($request->all());

        return redirect()
            ->route('operator.kelas.index')
            ->with('success', 'Data kelas berhasil ditambahkan!');
    }

    public function edit(Kelas $kelas)
    {
        $guru = Guru::where('status', 'aktif')
            ->orderBy('nama')
            ->get();

        return view('operator.kelas.edit', compact('kelas', 'guru'));
    }

    public function update(Request $request, Kelas $kelas)
    {
        $request->validate([
            'nama_kelas'    => 'required|string|max:20',
            'tingkat'       => 'required|in:7,8,9',
            'tahun_ajaran'  => 'required|string|max:20',
            'wali_kelas_id' => 'nullable|exists:guru,id',
            'status'        => 'required|in:aktif,tidak_aktif',
        ]);

        $kelas->update($request->all());

        return redirect()
            ->route('operator.kelas.index')
            ->with('success', 'Data kelas berhasil diperbarui!');
    }

    public function destroy(Kelas $kelas)
    {
        $kelas->delete();

        return redirect()
            ->route('operator.kelas.index')
            ->with('success', 'Data kelas berhasil dihapus!');
    }
}