<?php

namespace App\Http\Controllers\Operator;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Predikat;

class PredikatController extends Controller
{
    public function index()
    {
        $predikat = Predikat::orderBy('nilai_min', 'desc')->get();

        return view('operator.predikat.index', compact('predikat'));
    }

    public function create()
    {
        
        return view('operator.predikat.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'predikat' => 'required|max:1',
            'nilai_min' => 'required|integer',
            'nilai_max' => 'required|integer',
            'keterangan' => 'required|string',
        ]);

        Predikat::create($request->all());

        return redirect()->route('operator.predikat.index')
            ->with('success', 'Predikat berhasil ditambahkan');
    }

    public function show(string $id)
    {
        //
    }

    public function edit(string $id)
    {
        $predikat = Predikat::findOrFail($id);

        return view('operator.predikat.edit', compact('predikat'));
    }

    public function update(Request $request, string $id)
    {
        $request->validate([
            'predikat' => 'required|max:1',
            'nilai_min' => 'required|integer',
            'nilai_max' => 'required|integer',
            'keterangan' => 'required|string',
        ]);

        $predikat = Predikat::findOrFail($id);

        $predikat->update($request->all());

        return redirect()->route('operator.predikat.index')
            ->with('success', 'Predikat berhasil diperbarui');
    }

    public function destroy(string $id)
    {
        $predikat = Predikat::findOrFail($id);

        $predikat->delete();

        return redirect()->route('operator.predikat.index')
            ->with('success', 'Predikat berhasil dihapus');
    }
}