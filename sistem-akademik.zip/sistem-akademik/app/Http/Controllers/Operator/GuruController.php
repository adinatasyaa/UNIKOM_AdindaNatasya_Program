<?php

namespace App\Http\Controllers\Operator;

use App\Http\Controllers\Controller;
use App\Models\Guru;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\GuruImport;

class GuruController extends Controller
{
    public function index(Request $request)
    {
        $query = Guru::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('nama', 'like', "%{$search}%")
                ->orWhere('nip', 'like', "%{$search}%");
            });
        }

        $guru = $query->orderBy('nama')->paginate(10)->withQueryString();

        return view('operator.guru.index', compact('guru'));
    }

    public function create()
    {
        return view('operator.guru.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nip'           => 'nullable|unique:guru,nip',
            'nama'          => 'required|string|max:255',
            'jenis_kelamin' => 'nullable|in:L,P',
            'no_telp'       => 'nullable|string',
            'email'         => 'nullable|email',
            'role'          => 'required|in:guru,wali_kelas,kepala_sekolah,wakasek_kurikulum,wakasek_kesiswaan,operator,guru_piket',
        ]);

        Guru::create($request->all());

        return redirect()->route('operator.guru.index')
            ->with('success', 'Data guru berhasil ditambahkan!');
    }

    public function edit(Guru $guru)
    {
        return view('operator.guru.edit', compact('guru'));
    }

    public function update(Request $request, Guru $guru)
    {
        $request->validate([
            'nip'           => 'nullable|unique:guru,nip,' . $guru->id,
            'nama'          => 'required|string|max:255',
            'jenis_kelamin' => 'nullable|in:L,P',
            'no_telp'       => 'nullable|string',
            'email'         => 'nullable|email',
            'role'          => 'required|in:guru,wali_kelas,kepala_sekolah,wakasek_kurikulum,wakasek_kesiswaan,operator,guru_piket',
        ]);

        $guru->update($request->all());

           if (!empty($guru->email)) {
        $existingUser = $guru->user ?? \App\Models\User::where('email', $guru->email)->first();

        if ($existingUser) {
            $existingUser->update([
                'email'   => $request->email,
                'name'    => $request->nama,
                'role'    => $request->role,
                'guru_id' => $guru->id,
            ]);
        } else {
            \App\Models\User::create([
                'name'     => $guru->nama,
                'email'    => $guru->email,
                'role'     => $guru->role,
                'password' => \Illuminate\Support\Facades\Hash::make('labschool123'),
                'guru_id'  => $guru->id,
            ]);
        }
    }

        return redirect()->route('operator.guru.index')
            ->with('success', 'Data guru berhasil diperbarui!');
    }

    public function destroy(Guru $guru)
    {
        $guru->delete();
        return redirect()->route('operator.guru.index')
            ->with('success', 'Data guru berhasil dihapus!');
    }

    public function import(Request $request)
{
    $request->validate([
        'file' => 'required|mimes:xlsx,xls',
    ]);

    $sheetData = Excel::toArray([], $request->file('file'));
    $headings = array_map('strtolower', array_map('trim', $sheetData[0][0] ?? []));

    $requiredHeadings = ['nama'];
    $missing = array_diff($requiredHeadings, $headings);

    $siswaMarkers = ['nis', 'nama_kelas', 'spmb_id'];
    $hasSiswaMarker = count(array_intersect($siswaMarkers, $headings)) > 0;

    if (!empty($missing) || $hasSiswaMarker) {
        return redirect()->route('operator.guru.index')
            ->with('error', 'Format file tidak sesuai untuk import data guru. Gunakan format: nip, nama, jenis_kelamin, no_telp, email, role, status.');
    }

    Excel::import(new GuruImport, $request->file('file'));

    return redirect()->route('operator.guru.index')
        ->with('success', 'Data guru berhasil diimport!');
}
}