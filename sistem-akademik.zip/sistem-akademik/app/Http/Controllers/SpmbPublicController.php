<?php

namespace App\Http\Controllers;

use App\Models\Spmb;
use App\Models\PengumumanSpmb;
use App\Models\Siswa;
use Illuminate\Http\Request;

class SpmbPublicController extends Controller
{
    public function index()
    {
        return view('spmb.index');
    }

    public function create()
    {
        return view('spmb.create');
    }

    public function store(Request $request)
{
    $request->validate([
        'nama_lengkap'         => 'required|string|max:255',
        'jenis_kelamin'        => 'required|in:L,P',
        'asal_sekolah'         => 'required|string|max:255',
        'no_kontak_siswa'      => 'required|string|max:20',
        'nama_orang_tua'       => 'required|string|max:255',
        'alamat'               => 'required|string',
        'no_kontak_orang_tua'  => 'required|string|max:20',
        'sumber_informasi'     => 'required|in:Saudara,Tetangga,Website/Social Media,Kunjungan langsung,Lainnya',

        'kartu_keluarga'       => 'required|file|mimes:jpg,jpeg,pdf|max:2048',
        'akte_kelahiran'       => 'required|file|mimes:jpg,jpeg,pdf|max:2048',
        'ktp_orang_tua'        => 'required|file|mimes:jpg,jpeg,pdf|max:2048',
    ], [
        'kartu_keluarga.required' => 'Kartu Keluarga wajib diupload.',
        'akte_kelahiran.required' => 'Akte Kelahiran wajib diupload.',
        'ktp_orang_tua.required'  => 'KTP Orang Tua wajib diupload.',
        '*.mimes' => 'File harus berformat JPG atau PDF.',
        '*.max'   => 'Ukuran file maksimal 2MB.',
    ]);

    $pathKartuKeluarga = $request->file('kartu_keluarga')
        ->storeAs('dokumen_spmb', 'kk_' . uniqid() . '.' . $request->file('kartu_keluarga')->getClientOriginalExtension(), 'public');

    $pathAkteKelahiran = $request->file('akte_kelahiran')
        ->storeAs('dokumen_spmb', 'akte_' . uniqid() . '.' . $request->file('akte_kelahiran')->getClientOriginalExtension(), 'public');

    $pathKtpOrangTua = $request->file('ktp_orang_tua')
        ->storeAs('dokumen_spmb', 'ktp_' . uniqid() . '.' . $request->file('ktp_orang_tua')->getClientOriginalExtension(), 'public');

    $spmb = Spmb::create([
        'id_pendaftaran'       => $this->generateIdPendaftaran(),
        'nama_lengkap'         => $request->nama_lengkap,
        'jenis_kelamin'        => $request->jenis_kelamin,
        'asal_sekolah'         => $request->asal_sekolah,
        'no_kontak_siswa'      => $request->no_kontak_siswa,
        'nama_orang_tua'       => $request->nama_orang_tua,
        'alamat'               => $request->alamat,
        'no_kontak_orang_tua'  => $request->no_kontak_orang_tua,
        'sumber_informasi'     => $request->sumber_informasi,
        'kartu_keluarga'       => $pathKartuKeluarga,
        'akte_kelahiran'       => $pathAkteKelahiran,
        'ktp_orang_tua'        => $pathKtpOrangTua,
        'status'               => 'pending'
    ]);

    session(['pendaftar_id' => $spmb->id]);

    return view('spmb.create', ['berhasilDaftar' => $spmb]);
    }

    public function showKonfirmasi()
    {
        if (!session()->has('pendaftar_id')) {
            return redirect()->route('spmb.create')->with('error', 'Silakan isi formulir terlebih dahulu.');
    }

        $pendaftaran = Spmb::find(session('pendaftar_id'));

        if (!$pendaftaran || $pendaftaran->hasil_seleksi !== 'lulus') {
            return redirect()->route('spmb.pengumuman')->with('error', 'Halaman konfirmasi belum dapat diakses. Silakan cek pengumuman hasil seleksi Anda terlebih dahulu.');
    }

        return view('spmb.konfirmasi', compact('pendaftaran'));
    }

    public function submitKonfirmasi(Request $request)
{
    $request->validate([
        'nama_siswa'      => 'required|string',
        'asal_sekolah'    => 'required|string',
        'nama_orang_tua'  => 'required|string',
    ]);

    $pendaftaran = Spmb::find(session('pendaftar_id'));

    if ($pendaftaran) {
        if (
            strcasecmp(trim($pendaftaran->nama_lengkap), trim($request->nama_siswa)) == 0 &&
            strcasecmp(trim($pendaftaran->asal_sekolah), trim($request->asal_sekolah)) == 0 &&
            strcasecmp(trim($pendaftaran->nama_orang_tua), trim($request->nama_orang_tua)) == 0 
        ) {
            $pendaftaran->update([
                'status' => 'konfirmasi'
            ]);

            $sudahJadiSiswa = Siswa::where('spmb_id', $pendaftaran->id)->exists();

            if (!$sudahJadiSiswa) {
                Siswa::create([
                    'spmb_id'       => $pendaftaran->id,
                    'nis'           => null,
                    'nama'          => $pendaftaran->nama_lengkap,
                    'jenis_kelamin' => $pendaftaran->jenis_kelamin,
                    'kelas_id'      => null,
                    'status'        => 'aktif',
                ]);
            }

            return redirect()->route('spmb.cek_status')->with('success', 'Konfirmasi data berhasil! Data Anda akan diproses oleh sekolah untuk pembagian kelas.');
        }
    }

    return redirect()->back()->with('error', 'Data konfirmasi tidak cocok dengan data pendaftaran awal. Silakan periksa ejaan nama Anda kembali.');
}

    public function jadwalTes()
    {
        if (!session()->has('pendaftar_id')) {
            return redirect()->route('spmb.index'); 
        }

        $pendaftaran = Spmb::find(session('pendaftar_id'));

        if (!$pendaftaran) {
            return redirect()->route('spmb.index')->with('error', 'Data tidak ditemukan.');
        }

        return view('spmb.cek_status', compact('pendaftaran'));
    }

    private function generateIdPendaftaran(): string
{
    $bulan = now()->month;
    $tahunAwal = $bulan >= 7 ? now()->year : now()->year - 1;
    $tahunAjaran = $tahunAwal . '/' . ($tahunAwal + 1);

    $terakhir = Spmb::where('id_pendaftaran', 'like', $tahunAjaran . '-%')
        ->orderByDesc('id_pendaftaran')
        ->value('id_pendaftaran');

    if ($terakhir) {
        $nomorTerakhir = (int) substr($terakhir, -2);
    } else {
        $nomorTerakhir = 0;
    }

    $nomorUrut = str_pad($nomorTerakhir + 1, 2, '0', STR_PAD_LEFT);

    return $tahunAjaran . '-' . $nomorUrut;
}

    
    public function cekStatus()
    {
        $pendaftaran = null;
        return view('spmb.cek_status', compact('pendaftaran'));
    }

    public function prosesCekStatus(Request $request)
    {
        $request->validate([
            'id_pendaftaran' => 'required|string',
        ]);

        $pendaftaran = Spmb::where('id_pendaftaran', trim($request->id_pendaftaran))->first();

        if (!$pendaftaran) {
            return redirect()->back()->with('error', 'Data pendaftaran dengan ID tersebut tidak ditemukan.');
    }

        session(['pendaftar_id' => $pendaftaran->id]);

        return view('spmb.cek_status', compact('pendaftaran'));
    }

    public function pengumuman()
    {
        $pendaftaran = null;
        $pengumuman = collect(); 
        return view('spmb.pengumuman', compact('pendaftaran', 'pengumuman')); 
    }

    public function prosesCariPengumuman(Request $request)
    {
        $request->validate([
            'id_pendaftaran' => 'required|string',
        ]);

        $pendaftaran = Spmb::where('id_pendaftaran', trim($request->id_pendaftaran))->first();

        if (!$pendaftaran || $pendaftaran->hasil_seleksi === 'menunggu') {
            return redirect()->back()->with('error', 'Masukkan ID Pendaftaran Anda untuk melihat hasil kelulusan setelah pengumuman tersedia.');
        }

        session(['pendaftar_id' => $pendaftaran->id]); 

        $pengumuman = collect([$pendaftaran]);

        return view('spmb.pengumuman', compact('pendaftaran', 'pengumuman'));
    }
}