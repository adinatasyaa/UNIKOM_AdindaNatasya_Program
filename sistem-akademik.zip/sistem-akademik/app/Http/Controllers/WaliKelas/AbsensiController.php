<?php

namespace App\Http\Controllers\WaliKelas;

use App\Http\Controllers\Controller;
use App\Models\Absensi;
use App\Models\AbsensiDetail;
use App\Models\AbsensiPiket;
use App\Models\Kelas;
use App\Models\Guru;
use Illuminate\Http\Request;

class AbsensiController extends Controller
{
    public function index(Request $request)
    {
        $guru = Guru::where('email', auth()->user()->email)->first();

        $kelas = $guru ? Kelas::where('wali_kelas_id', $guru->id)->get() : collect();

        $kelasIds = $kelas->pluck('id');
        $namaKelas = $kelas->pluck('nama_kelas');

        $kelasFilter = $request->kelas_id;

        $absensiQuery = Absensi::with(['kelas', 'mataPelajaran', 'guru'])
            ->whereIn('kelas_id', $kelasIds);

        if ($kelasFilter) {
            $absensiQuery->where('kelas_id', $kelasFilter);
        }

        $absensi = $absensiQuery->orderBy('tanggal', 'desc')->paginate(10);

        $absensiPiketQuery = AbsensiPiket::whereIn('nama_kelas', $namaKelas);

        if ($kelasFilter) {
            $namaKelasFilter = Kelas::find($kelasFilter)?->nama_kelas;
            $absensiPiketQuery->where('nama_kelas', $namaKelasFilter);
        }

        $absensiPiket = $absensiPiketQuery->orderBy('tanggal', 'desc')->get();

        return view('wali_kelas.absensi.index', compact('absensi', 'kelas', 'absensiPiket'));
    }

    public function show($id)
    {
        $absensi = Absensi::with(['kelas', 'mataPelajaran', 'guru', 'detail.siswa', 'detail.updatedBy'])
            ->findOrFail($id);

        return view('wali_kelas.absensi.show', compact('absensi'));
    }

    public function update(Request $request, $detail_id)
    {
        $request->validate([
            'status_kehadiran' => 'required|in:Hadir,Izin,Sakit,Alpa',
            'keterangan'       => 'nullable|string',
        ]);

        AbsensiDetail::where('id', $detail_id)->update([
            'status_kehadiran' => $request->status_kehadiran,
            'keterangan'       => $request->keterangan,
            'updated_by'       => auth()->id(),
        ]);

        return redirect()->back()
            ->with('success', 'Absensi berhasil diperbarui!');
    }
}