<?php

namespace App\Http\Controllers\WaliKelas;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PembagianKelas;
use App\Models\PembagianSiswa;
use Illuminate\Support\Facades\Auth;

class PembagianKelasController extends Controller
{
    public function index(Request $request)
{
    $guruId = Auth::user()->guru_id;

    $kelasSaya = [];
    if ($guruId) {
        $kelasSaya = PembagianKelas::with(['kelas'])
            ->where('guru_id', $guruId)
            ->get();
    }

    return view('wali_kelas.pembagian_kelas.index', compact('kelasSaya'));
}

    public function show($id)
    {
        $pembagianKelas = PembagianKelas::with(['kelas'])->findOrFail($id);
        
        $daftarSiswa = PembagianSiswa::with('siswa')
            ->where('kelas_id', $pembagianKelas->kelas_id)
            ->where('tahun_ajaran', $pembagianKelas->tahun_ajaran)
            ->where('semester', $pembagianKelas->semester)
            ->get();

        return view('wali_kelas.pembagian_kelas.show', compact('pembagianKelas', 'daftarSiswa'));
    }

}