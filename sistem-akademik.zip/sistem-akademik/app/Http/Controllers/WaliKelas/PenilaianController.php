<?php

namespace App\Http\Controllers\WaliKelas;

use App\Http\Controllers\Controller;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\Penilaian;
use App\Models\Guru;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class PenilaianController extends Controller
{
    public function index()
    {
        $guru = Guru::where('email', auth()->user()->email)->first();
        $kelas = Kelas::where('wali_kelas_id', $guru?->id)->orderBy('nama_kelas')->get();

        return view('wali_kelas.penilaian.index', compact('kelas'));
    }

    public function show($kelas_id)
    {
        $guru = Guru::where('email', auth()->user()->email)->first();
        $kelas = Kelas::where('id', $kelas_id)
            ->where('wali_kelas_id', $guru?->id)
            ->firstOrFail();

        $siswa = Siswa::where('kelas_id', $kelas_id)
            ->where('status', 'aktif')
            ->orderBy('nama')
            ->get();

        $dataSiswa = [];
        foreach ($siswa as $s) {
            $penilaian = Penilaian::with('mataPelajaran')
                ->where('siswa_id', $s->id)
                ->where('kelas_id', $kelas_id)
                ->get();

            $totalMapel = $penilaian->count();
            $lengkapCount = $penilaian->where('status', '!=', 'belum_lengkap')->count();

            $dataSiswa[] = [
                'siswa'      => $s,
                'penilaian'  => $penilaian,
                'lengkap'    => $totalMapel > 0 && $lengkapCount == $totalMapel,
            ];
        }

        return view('wali_kelas.penilaian.show', compact('kelas', 'dataSiswa'));
    }

    public function detailSiswa($kelas_id, $siswa_id)
    {
        $guru = Guru::where('email', auth()->user()->email)->first();
        $kelas = Kelas::where('id', $kelas_id)
            ->where('wali_kelas_id', $guru?->id)
            ->firstOrFail();

        $siswa = Siswa::findOrFail($siswa_id);

        $penilaian = Penilaian::with('mataPelajaran')
            ->where('siswa_id', $siswa_id)
            ->where('kelas_id', $kelas_id)
            ->get();

        return view('wali_kelas.penilaian.detail', compact('kelas', 'siswa', 'penilaian'));
    }

    public function unduhRapor($kelas_id, $siswa_id)
    {
    $guru = Guru::where('email', auth()->user()->email)->first();
    $kelas = Kelas::where('id', $kelas_id)
        ->where('wali_kelas_id', $guru?->id)
        ->firstOrFail();

    $siswa = Siswa::findOrFail($siswa_id);

    $terbaru = Penilaian::where('siswa_id', $siswa_id)
        ->where('kelas_id', $kelas_id)
        ->orderByDesc('tahun_ajaran')
        ->orderByDesc('semester')
        ->first();

    $penilaian = Penilaian::with('mataPelajaran')
        ->where('siswa_id', $siswa_id)
        ->where('kelas_id', $kelas_id)
        ->when($terbaru, fn($q) => $q
            ->where('tahun_ajaran', $terbaru->tahun_ajaran)
            ->where('semester', $terbaru->semester))
        ->get();

    $logoPath = public_path('logoPDF.jpg');
    $logoBase64 = base64_encode(file_get_contents($logoPath));

    $pdf = Pdf::loadView('wali_kelas.penilaian.rapor_pdf', compact('kelas', 'siswa', 'penilaian', 'logoBase64'));

    return $pdf->download("Rapor-{$siswa->nama}-{$kelas->nama_kelas}.pdf");
    }
}