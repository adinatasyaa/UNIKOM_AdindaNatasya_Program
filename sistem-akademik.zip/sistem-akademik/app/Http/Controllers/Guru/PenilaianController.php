<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\BobotPenilaian;
use App\Models\Penilaian;
use App\Models\NilaiDetail;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\Predikat;
use App\Models\Guru;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class PenilaianController extends Controller
{
    public function pilihKelas($bobot_id = null)
    {
    $guru = Guru::where('email', auth()->user()->email)->first();

    $daftarBobot = BobotPenilaian::with('mataPelajaran')
        ->where('guru_id', $guru?->id)
        ->orderBy('created_at', 'desc')
        ->get();

    if ($daftarBobot->isEmpty()) {
        return redirect()->route('guru.bobot.index')
            ->with('error', 'Anda belum membuat Bobot Penilaian. Silakan buat dulu.');
    }

    $bobot = $bobot_id
        ? $daftarBobot->firstWhere('id', $bobot_id)
        : $daftarBobot->first();

    if (!$bobot) {
        $bobot = $daftarBobot->first();
    }

    $bobot = BobotPenilaian::with(['mataPelajaran', 'komponen'])->findOrFail($bobot->id);

    $kelas = \App\Models\PenjadwalanMataPelajaran::where('guru_id', $bobot->guru_id)
        ->where('mata_pelajaran_id', $bobot->mata_pelajaran_id)
        ->where('status', 'disetujui')
        ->with('kelas')
        ->get()
        ->pluck('kelas')
        ->filter()
        ->unique('id')
        ->sortBy('nama_kelas')
        ->values();

    return view('guru.penilaian.pilih_kelas', compact('bobot', 'kelas', 'daftarBobot'));
    }

    public function index($bobot_id, $kelas_id)
    {
        $bobot = BobotPenilaian::with(['mataPelajaran', 'komponen'])->findOrFail($bobot_id);
        $kelas = Kelas::findOrFail($kelas_id);

        $siswa = Siswa::where('kelas_id', $kelas_id)
            ->where('status', 'aktif')
            ->orderBy('nama')
            ->get();

        $dataSiswa = [];
        foreach ($siswa as $s) {
            $penilaian = Penilaian::firstOrCreate([
                'siswa_id'          => $s->id,
                'kelas_id'          => $kelas_id,
                'mata_pelajaran_id' => $bobot->mata_pelajaran_id,
                'guru_id'           => $bobot->guru_id,
                'tahun_ajaran'      => $bobot->tahun_ajaran,
                'semester'          => $bobot->semester,
            ]);

            $nilaiPerKomponen = [];
            foreach ($bobot->komponen as $k) {
                $detail = NilaiDetail::firstOrCreate([
                    'penilaian_id'       => $penilaian->id,
                    'komponen_bobot_id'  => $k->id,
                ]);
                $nilaiPerKomponen[$k->id] = $detail->nilai;
            }

            $dataSiswa[] = [
                'siswa'      => $s,
                'penilaian'  => $penilaian,
                'nilai'      => $nilaiPerKomponen,
            ];
        }

        return view('guru.penilaian.index', compact('bobot', 'kelas', 'dataSiswa'));
    }

    public function store(Request $request, $bobot_id, $kelas_id)
    {
        $bobot = BobotPenilaian::with('komponen')->findOrFail($bobot_id);
        $aksi  = $request->input('aksi', 'sementara'); // sementara / final

        foreach ($request->nilai as $penilaian_id => $komponenNilai) {
            $penilaian = Penilaian::findOrFail($penilaian_id);

            $totalNilai = 0;
            $lengkap = true;

            foreach ($komponenNilai as $komponen_id => $nilai) {
                NilaiDetail::updateOrCreate(
                    ['penilaian_id' => $penilaian_id, 'komponen_bobot_id' => $komponen_id],
                    ['nilai' => $nilai !== '' ? $nilai : null]
                );

                if ($nilai === '' || $nilai === null) {
                    $lengkap = false;
                } else {
                    $komponen = $bobot->komponen->firstWhere('id', $komponen_id);
                    $totalNilai += ($nilai * $komponen->persentase / 100);
                }
            }

            $predikat = null;
                if ($lengkap) {
            $predikatData = Predikat::where('nilai_min', '<=', $totalNilai)
                ->orderByDesc('nilai_min')
                ->first();
            $predikat = $predikatData?->predikat;
            }

            $penilaian->update([
                'nilai_akhir' => $lengkap ? round($totalNilai, 2) : null,
                'predikat'    => $predikat,
                'status'      => $aksi === 'final' ? 'final' : ($lengkap ? 'lengkap' : 'belum_lengkap'),
            ]);
        }

        $pesan = $aksi === 'final' ? 'Nilai berhasil disimpan secara FINAL!' : 'Nilai berhasil disimpan sementara!';

        return redirect()->route('guru.penilaian.index', [$bobot_id, $kelas_id])
            ->with('success', $pesan);
    }

    public function unduhLaporan($bobot_id, $kelas_id)
    {
    $bobot = BobotPenilaian::with(['mataPelajaran', 'komponen'])->findOrFail($bobot_id);
    $kelas = Kelas::findOrFail($kelas_id);

    $siswa = Siswa::where('kelas_id', $kelas_id)
        ->where('status', 'aktif')
        ->orderBy('nama')
        ->get();

    $dataSiswa = [];
    foreach ($siswa as $s) {
        $penilaian = Penilaian::where([
            'siswa_id'          => $s->id,
            'kelas_id'          => $kelas_id,
            'mata_pelajaran_id' => $bobot->mata_pelajaran_id,
            'guru_id'           => $bobot->guru_id,
            'tahun_ajaran'      => $bobot->tahun_ajaran,
            'semester'          => $bobot->semester,
        ])->first();

        $nilaiPerKomponen = [];
        foreach ($bobot->komponen as $k) {
            $detail = NilaiDetail::where([
                'penilaian_id'      => $penilaian?->id,
                'komponen_bobot_id' => $k->id,
            ])->first();
            $nilaiPerKomponen[$k->id] = $detail->nilai ?? '-';
        }

        $dataSiswa[] = [
            'siswa'     => $s,
            'penilaian' => $penilaian,
            'nilai'     => $nilaiPerKomponen,
        ];
    }

    $logoPath = public_path('logoPDF.jpg');
    $logoBase64 = base64_encode(file_get_contents($logoPath));

    $pdf = Pdf::loadView('guru.penilaian.laporan_pdf', compact('bobot', 'kelas', 'dataSiswa', 'logoBase64'))
        ->setPaper('a4', 'landscape');

    return $pdf->download("Laporan-Nilai-{$bobot->mataPelajaran->nama_mapel}-{$kelas->nama_kelas}.pdf");
    }
}