<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\PenjadwalanMataPelajaran;
use App\Models\PersetujuanJadwal;
use Illuminate\Http\Request;

class PersetujuanJadwalController extends Controller
{
    public function index()
    {
        $persetujuan = PersetujuanJadwal::with(['jadwal.kelas', 'jadwal.mataPelajaran', 'jadwal.guru'])
            ->where('status', 'menunggu_persetujuan') 
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('guru.persetujuan.index', compact('persetujuan'));
    }

    public function prosesPersetujuan(Request $request, $id)
    {
        $request->validate([
            'aksi' => 'required|in:setuju,tolak',
            'catatan' => 'required_if:aksi,tolak|nullable|string|max:255',
        ]);

        $persetujuan = PersetujuanJadwal::findOrFail($id);
        $jadwal = PenjadwalanMataPelajaran::findOrFail($persetujuan->jadwal_id);

        $status = $request->aksi === 'setuju' ? 'disetujui' : 'ditolak';
        $persetujuan->update(['status' => $status, 'catatan' => $request->catatan]);
        $jadwal->update(['status' => $status]);

        return redirect()->route('guru.persetujuan-jadwal.index')->with('success', 'Jadwal berhasil ' . $status);
    }
}