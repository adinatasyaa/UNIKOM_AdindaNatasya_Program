<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\PenjadwalanMataPelajaran;
use App\Models\Guru;

class JadwalMengajarController extends Controller
{
    public function index()
    {
        $guru = Guru::where('email', auth()->user()->email)->first();

        $jadwal = PenjadwalanMataPelajaran::with(['kelas', 'mataPelajaran'])
            ->where('guru_id', $guru?->id)
            ->where('status', 'disetujui')
            ->orderBy('hari')
            ->orderBy('jam_mulai')
            ->get();

        return view('guru.jadwal_mengajar.index', compact('jadwal'));
    }
}