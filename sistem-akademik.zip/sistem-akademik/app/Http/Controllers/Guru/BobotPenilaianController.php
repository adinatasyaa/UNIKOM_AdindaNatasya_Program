<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\BobotPenilaian;
use App\Models\KomponenBobot;
use App\Models\Guru;
use App\Models\MataPelajaran;
use App\Models\Penilaian;
use App\Models\NilaiDetail;
use App\Models\Predikat;
use Illuminate\Http\Request;

class BobotPenilaianController extends Controller
    {
    public function index()
    {
    $guru = Guru::where('email', auth()->user()->email)->first();

    $bobot = BobotPenilaian::with(['mataPelajaran', 'komponen'])
        ->where('guru_id', $guru?->id)
        ->orderBy('created_at', 'desc')
        ->get();

    foreach ($bobot as $b) {
        $b->daftarKelas = \App\Models\PenjadwalanMataPelajaran::where('guru_id', $b->guru_id)
            ->where('mata_pelajaran_id', $b->mata_pelajaran_id)
            ->where('status', 'disetujui')
            ->with('kelas')
            ->get()
            ->pluck('kelas.nama_kelas')
            ->filter()
            ->unique()
            ->sort()
            ->values();
    }

    return view('guru.bobot.index', compact('bobot'));
    }

    public function create()
    {
    $guru = Guru::where('email', auth()->user()->email)->first();

    $mapel = MataPelajaran::whereIn('id', function ($query) use ($guru) {
        $query->select('mata_pelajaran_id')
            ->from('penjadwalan_mata_pelajaran')
            ->where('guru_id', $guru?->id)
            ->where('status', 'disetujui');
    })
        ->orderBy('nama_mapel')
        ->get();

    return view('guru.bobot.create', compact('mapel'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'mata_pelajaran_id'     => 'required|exists:mata_pelajaran,id',
            'tahun_ajaran'          => 'required|string',
            'semester'              => 'required|in:1,2',
            'komponen'              => 'required|array|min:1',
            'komponen.*.nama'       => 'required|string',
            'komponen.*.jenis'      => 'required|in:tugas,uts,uas',
            'komponen.*.persentase' => 'required|integer|min:1|max:100',
        ]);

        $total = array_sum(array_column($request->komponen, 'persentase'));
        if ($total != 100) {
            return back()->withErrors(['komponen' => "Total persentase harus 100%! Saat ini total: {$total}%"])
                ->withInput();
        }

        $guru = Guru::where('email', auth()->user()->email)->first();

        if (!$guru) {
            return back()->withErrors(['guru' => 'Akun Anda belum terhubung dengan data Guru. Silakan hubungi Operator.'])
                ->withInput();
        }

        $cek = BobotPenilaian::where('guru_id', $guru->id)
            ->where('mata_pelajaran_id', $request->mata_pelajaran_id)
            ->where('tahun_ajaran', $request->tahun_ajaran)
            ->where('semester', $request->semester)
            ->first();

        if ($cek) {
            return back()->withErrors(['mata_pelajaran_id' => 'Bobot untuk mata pelajaran, tahun ajaran, dan semester ini sudah ada. Silakan edit yang sudah ada.'])
                ->withInput();
        }

        $bobot = BobotPenilaian::create([
            'guru_id'           => $guru->id,
            'mata_pelajaran_id' => $request->mata_pelajaran_id,
            'tahun_ajaran'      => $request->tahun_ajaran,
            'semester'          => $request->semester,
            'status'            => 'aktif',
        ]);

        foreach ($request->komponen as $k) {
            KomponenBobot::create([
                'bobot_penilaian_id' => $bobot->id,
                'nama_komponen'      => $k['nama'],
                'jenis'              => $k['jenis'],
                'persentase'         => $k['persentase'],
            ]);
        }

        return redirect()->route('guru.penilaian.pilih_kelas', $bobot->id)
            ->with('success', 'Bobot penilaian berhasil disimpan! Silakan pilih kelas untuk input nilai siswa.');
    }

    public function show($id)
    {
    $bobot = BobotPenilaian::with(['komponen', 'mataPelajaran'])->findOrFail($id);

    $bobot->daftarKelas = \App\Models\PenjadwalanMataPelajaran::where('guru_id', $bobot->guru_id)
        ->where('mata_pelajaran_id', $bobot->mata_pelajaran_id)
        ->where('status', 'disetujui')
        ->with('kelas')
        ->get()
        ->pluck('kelas.nama_kelas')
        ->filter()
        ->unique()
        ->sort()
        ->values();

    $daftarNilai = Penilaian::with(['siswa', 'kelas'])
        ->where('guru_id', $bobot->guru_id)
        ->where('mata_pelajaran_id', $bobot->mata_pelajaran_id)
        ->where('tahun_ajaran', $bobot->tahun_ajaran)
        ->where('semester', $bobot->semester)
        ->get()
        ->filter(fn($item) => $item->siswa && $item->siswa->kelas_id == $item->kelas_id)
        ->sortBy(fn($item) => ($item->kelas->nama_kelas ?? '') . '-' . ($item->siswa->nama ?? ''))
        ->values();

    return view('guru.bobot.show', compact('bobot', 'daftarNilai'));
    }

    public function edit($id)
    {
        $guru  = Guru::where('email', auth()->user()->email)->first();
        $bobot = BobotPenilaian::with('komponen')->findOrFail($id);
        $mapel = MataPelajaran::where('guru_id', $guru?->id)
            ->orWhere('status', 'aktif')
            ->orderBy('nama_mapel')
            ->get();

        return view('guru.bobot.edit', compact('bobot', 'mapel'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'mata_pelajaran_id'     => 'required|exists:mata_pelajaran,id',
            'tahun_ajaran'          => 'required|string',
            'semester'              => 'required|in:1,2',
            'komponen'              => 'required|array|min:1',
            'komponen.*.nama'       => 'required|string',
            'komponen.*.jenis'      => 'required|in:tugas,uts,uas',
            'komponen.*.persentase' => 'required|integer|min:1|max:100',
        ]);

        $total = array_sum(array_column($request->komponen, 'persentase'));
        if ($total != 100) {
            return back()->withErrors(['komponen' => "Total persentase harus 100%! Saat ini total: {$total}%"])
                ->withInput();
        }

        $bobot = BobotPenilaian::findOrFail($id);
        $bobot->update([
            'mata_pelajaran_id' => $request->mata_pelajaran_id,
            'tahun_ajaran'      => $request->tahun_ajaran,
            'semester'          => $request->semester,
        ]);

        KomponenBobot::where('bobot_penilaian_id', $bobot->id)->delete();

        foreach ($request->komponen as $k) {
            KomponenBobot::create([
                'bobot_penilaian_id' => $bobot->id,
                'nama_komponen'      => $k['nama'],
                'jenis'              => $k['jenis'],
                'persentase'         => $k['persentase'],
            ]);
        }

        return redirect()->route('guru.bobot.index')
            ->with('success', 'Bobot penilaian berhasil diperbarui! Nilai yang sudah diinput perlu diisi ulang sesuai komponen baru.');
    }

    public function destroy($id)
    {
        $bobot = BobotPenilaian::findOrFail($id);
        $bobot->delete();

        return redirect()->route('guru.bobot.index')
            ->with('success', 'Bobot penilaian berhasil dihapus!');
    }

    public function recalculatePredikat()
    {
        $guru = Guru::where('email', auth()->user()->email)->first();

        $penilaian = Penilaian::where('guru_id', $guru?->id)
            ->whereNotNull('nilai_akhir')
            ->get();

        foreach ($penilaian as $p) {
            $predikatData = Predikat::where('nilai_min', '<=', $p->nilai_akhir)
                ->where('nilai_max', '>=', $p->nilai_akhir)
                ->first();

            $p->update(['predikat' => $predikatData?->predikat]);
        }

        return redirect()->back()
            ->with('success', 'Predikat semua siswa berhasil diperbarui sesuai setting terbaru!');
    }

    public function getTahunSemesterByMapel($mapel_id)
    {
    $guru = Guru::where('email', auth()->user()->email)->first();

    $kombinasi = \App\Models\PenjadwalanMataPelajaran::where('guru_id', $guru?->id)
        ->where('mata_pelajaran_id', $mapel_id)
        ->where('status', 'disetujui')
        ->select('tahun_ajaran', 'semester')
        ->distinct()
        ->get();

    return response()->json($kombinasi);
    }
}