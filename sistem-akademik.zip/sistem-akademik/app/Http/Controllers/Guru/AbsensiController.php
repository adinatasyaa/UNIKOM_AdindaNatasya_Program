<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\Absensi;
use App\Models\AbsensiDetail;
use App\Models\Kelas;
use App\Models\MataPelajaran;
use App\Models\Guru;
use App\Models\Siswa;
use Illuminate\Http\Request;

class AbsensiController extends Controller
{
    public function index()
{
    $guru = Guru::where('email', auth()->user()->email)->first();

    $absensi = Absensi::with(['kelas', 'mataPelajaran']);

    if ($guru) {
        $absensi = $absensi->where('guru_id', $guru->id);
    }

    $absensi = $absensi->orderBy('tanggal', 'desc')->paginate(10);

    return view('guru.absensi.index', compact('absensi'));
}

   public function create()
{
    $guru = Guru::where('email', auth()->user()->email)->first();

    $daftarKelas = \App\Models\PenjadwalanMataPelajaran::where('guru_id', $guru->id)
        ->where('status', 'disetujui')
        ->with('kelas')
        ->get()
        ->pluck('kelas')
        ->filter()
        ->unique('id')
        ->sortBy('nama_kelas')
        ->values();

    return view('guru.absensi.create', compact('guru', 'daftarKelas'));
}

public function getJadwalByKelas($kelas_id)
{
    $guru = Guru::where('email', auth()->user()->email)->first();

    $hariIni = \Carbon\Carbon::now()->locale('id')->isoFormat('dddd');

    $jadwal = \App\Models\PenjadwalanMataPelajaran::with('mataPelajaran')
        ->where('guru_id', $guru->id)
        ->where('kelas_id', $kelas_id)
        ->where('hari', $hariIni)
        ->where('status', 'disetujui')
        ->first();

    if (!$jadwal) {
        return response()->json([
            'error' => 'Tidak ada jadwal mengajar Anda di kelas ini untuk hari ' . $hariIni . '.'
        ], 404);
    }

    $siswa = Siswa::where('status', 'aktif')
        ->where('kelas_id', $kelas_id)
        ->orderBy('nama')
        ->get();

    return response()->json([
        'jadwal' => [
            'mata_pelajaran_id'   => $jadwal->mata_pelajaran_id,
            'mata_pelajaran_nama' => $jadwal->mataPelajaran->nama_mapel,
            'jam_pelajaran'       => \Carbon\Carbon::parse($jadwal->jam_mulai)->format('H:i') . ' - ' . \Carbon\Carbon::parse($jadwal->jam_selesai)->format('H:i'),
            'semester'            => $jadwal->semester,
            'tahun_ajaran'        => $jadwal->tahun_ajaran,
        ],
        'siswa' => $siswa,
    ]);
}

    public function store(Request $request)
    {
        $request->validate([
            'kelas_id'          => 'required|exists:kelas,id',
            'mata_pelajaran_id' => 'required|exists:mata_pelajaran,id',
            'tanggal'           => 'required|date',
            'jam_pelajaran'     => 'required|string',
            'tahun_ajaran'      => 'required|string',
            'semester'          => 'required|in:1,2',
            'kehadiran'         => 'required|array',
        ]);

        $guru = Guru::where('email', auth()->user()->email)->first();

        $absensi = Absensi::create([
            'kelas_id'          => $request->kelas_id,
            'guru_id'           => $guru->id,
            'mata_pelajaran_id' => $request->mata_pelajaran_id,
            'tanggal'           => $request->tanggal,
            'jam_pelajaran'     => $request->jam_pelajaran,
            'tahun_ajaran'      => $request->tahun_ajaran,
            'semester'          => $request->semester,
        ]);

        foreach ($request->kehadiran as $siswa_id => $data) {
            AbsensiDetail::create([
                'absensi_id'       => $absensi->id,
                'siswa_id'         => $siswa_id,
                'status_kehadiran' => $data['status'],
                'keterangan'       => $data['keterangan'] ?? null,
                'updated_by'       => auth()->id(),
            ]);
        }

        return redirect()->route('guru.absensi.index')
            ->with('success', 'Absensi berhasil disimpan!');
    }

    public function show($id)
    {
        $absensi = Absensi::with(['kelas', 'mataPelajaran', 'guru', 'detail.siswa', 'detail.updatedBy'])
            ->findOrFail($id);

        return view('guru.absensi.show', compact('absensi'));
    }

    public function edit($id)
    {
        $absensi = Absensi::with(['detail.siswa'])->findOrFail($id);
        $kelas   = Kelas::where('status', 'aktif')->orderBy('nama_kelas')->get();
        $mapel   = MataPelajaran::where('status', 'aktif')->orderBy('nama_mapel')->get();

        return view('guru.absensi.edit', compact('absensi', 'kelas', 'mapel'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'kehadiran' => 'required|array',
        ]);

        $absensi = Absensi::findOrFail($id);

        foreach ($request->kehadiran as $detail_id => $data) {
            AbsensiDetail::where('id', $detail_id)->update([
                'status_kehadiran' => $data['status'],
                'keterangan'       => $data['keterangan'] ?? null,
                'updated_by'       => auth()->id(),
            ]);
        }

        return redirect()->route('guru.absensi.show', $absensi->id)
            ->with('success', 'Absensi berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $absensi = Absensi::findOrFail($id);

        AbsensiDetail::where('absensi_id', $absensi->id)->delete();
        $absensi->delete();

        return redirect()->route('guru.absensi.index')
            ->with('success', 'Absensi berhasil dihapus!');
    }

    public function getSiswaByKelas($kelas_id)
{
    $siswa = Siswa::where('status', 'aktif')
        ->where('kelas_id', $kelas_id)
        ->orderBy('nama')
        ->get();

    return response()->json($siswa);
}
}