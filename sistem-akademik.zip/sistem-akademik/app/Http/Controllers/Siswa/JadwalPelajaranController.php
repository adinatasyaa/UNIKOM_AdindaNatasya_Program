<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use App\Models\PenjadwalanMataPelajaran;
use Illuminate\Support\Facades\Auth;

class JadwalPelajaranController extends Controller
{
    public function index()
    {
        $siswa = Siswa::where('email', Auth::user()->email)->first();

        $jadwal = collect();

        if ($siswa && $siswa->kelas_id) {
            $jadwal = PenjadwalanMataPelajaran::with([
                        'kelas',
                        'guru',
                        'mataPelajaran'
                    ])
                    ->where('kelas_id', $siswa->kelas_id)
                    ->where('status', 'disetujui')
                    ->orderBy('hari')
                    ->orderBy('jam_mulai')
                    ->get();
        }

        return view('siswa.jadwal.index', compact('jadwal'));
    }
}