<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use App\Models\Penilaian;
use Illuminate\Support\Facades\Auth;

class PenilaianController extends Controller
{
    public function index()
    {
        $siswa = Siswa::where('email', Auth::user()->email)->first();

        $data = collect();

        if ($siswa) {
            $data = Penilaian::with([
                'guru',
                'kelas',
                'mataPelajaran',
                'detail.komponenBobot'
            ])
            ->where('siswa_id', $siswa->id)
            ->where('status', 'final')
            ->get();
        }

        return view('siswa.penilaian.index', compact('data'));
    }
}