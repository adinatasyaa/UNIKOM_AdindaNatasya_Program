<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use App\Models\AbsensiDetail;
use Illuminate\Support\Facades\Auth;

class AbsensiController extends Controller
{
    public function index()
    {
        $siswa = Siswa::where('email', Auth::user()->email)->first();

        $absensi = collect();

        if ($siswa) {
            $absensi = AbsensiDetail::with([
                'absensi.guru',
                'absensi.kelas',
                'absensi.mataPelajaran',
            ])
            ->where('siswa_id', $siswa->id)
            ->latest()
            ->get();
        }

        return view('siswa.absensi.index', compact('absensi'));
    }
}