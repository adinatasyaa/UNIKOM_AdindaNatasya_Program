<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use App\Models\PembagianSiswa;
use Illuminate\Support\Facades\Auth;

class PembagianKelasController extends Controller
{
    public function index()
    {
        $siswa = Siswa::where('email', Auth::user()->email)->first();

        $data = collect();

        if ($siswa) {
            $data = PembagianSiswa::with('kelas')
                        ->where('siswa_id', $siswa->id)
                        ->where('status_pembagian', 'final')
                        ->orderByDesc('tahun_ajaran')
                        ->get();
        }

        return view('siswa.pembagian_kelas.index', compact('data'));
    }
}