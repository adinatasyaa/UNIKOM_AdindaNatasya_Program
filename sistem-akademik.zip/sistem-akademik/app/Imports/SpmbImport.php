<?php

namespace App\Imports;

use App\Models\Spmb; 
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class SpmbImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        $jk = strtoupper(trim($row['jenis_kelamin'] ?? ''));
        if ($jk == 'LAKI-LAKI' || $jk == 'L') {
            $jk = 'L';
        } elseif ($jk == 'PEREMPUAN' || $jk == 'P') {
            $jk = 'P';
        } else {
            $jk = 'L'; 
        }

        return new Spmb([
            'nama_lengkap'         => $row['nama_lengkap'],
            'jenis_kelamin'        => $jk,
            'asal_sekolah'         => $row['asal_sekolah'] ?? null,
            'no_kontak_siswa'      => $row['no_kontak_siswa'] ?? null,
            'nama_orang_tua'       => $row['nama_orang_tua'] ?? null,
            'alamat'               => $row['alamat'] ?? null,
            'no_kontak_orang_tua'  => $row['no_kontak_orang_tua'] ?? null,
            'sumber_informasi'     => $row['sumber_informasi'] ?? null,
            'status'               => 'pending', 
        ]);
    }
}