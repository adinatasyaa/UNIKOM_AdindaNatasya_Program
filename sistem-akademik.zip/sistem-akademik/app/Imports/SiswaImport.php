<?php

namespace App\Imports;

use App\Models\Siswa;
use App\Models\Kelas;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class SiswaImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
{
    $nis = trim($row['nis'] ?? '');
    if (empty($nis)) {
        return null;
    }

    $jk = strtoupper(trim($row['jenis_kelamin'] ?? ''));
    if ($jk == 'LAKI-LAKI' || $jk == 'L') $jk = 'L';
    elseif ($jk == 'PEREMPUAN' || $jk == 'P') $jk = 'P';
    else $jk = null;

    $nama_kelas_excel = trim($row['nama_kelas'] ?? '');
    $kelas = Kelas::where('nama_kelas', $nama_kelas_excel)->first();
    $kelas_id = $kelas ? $kelas->id : null;

    $siswaLama = Siswa::where('nis', $nis)->first();

    return Siswa::updateOrCreate(
        ['nis' => $nis],
        [
            'nama'          => $row['nama'] ?: ($siswaLama->nama ?? null),
            'kelas_id'      => $kelas_id ?: ($siswaLama->kelas_id ?? null),
            'jenis_kelamin' => $jk ?: ($siswaLama->jenis_kelamin ?? null),
            'tempat_lahir'  => $row['tempat_lahir'] ?? ($siswaLama->tempat_lahir ?? null),
            'tanggal_lahir' => $row['tanggal_lahir'] ?? ($siswaLama->tanggal_lahir ?? null),
            'email'         => $row['email'] ?? ($siswaLama->email ?? null),
            'status'        => $row['status'] ?? ($siswaLama->status ?? 'aktif'),
            'spmb_id'       => $row['spmb_id'] ?? ($siswaLama->spmb_id ?? null),
        ]
    );
}
}