<?php

namespace App\Imports;

use App\Models\Guru;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class GuruImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        $nama = trim($row['nama'] ?? '');
        if (empty($nama)) {
            return null;
        }

        $nip = trim($row['nip'] ?? '');

        $guruLama = !empty($nip)
            ? Guru::where('nip', $nip)->first()
            : Guru::where('nama', $nama)->first();

        $jk = strtoupper(trim($row['jenis_kelamin'] ?? ''));
        if ($jk == 'LAKI-LAKI' || $jk == 'L') $jk = 'L';
        elseif ($jk == 'PEREMPUAN' || $jk == 'P') $jk = 'P';
        else $jk = $guruLama->jenis_kelamin ?? null;

        $roleMap = [
            'guru' => 'guru',
            'guru piket' => 'guru',
            'wali kelas' => 'wali_kelas',
            'wakasek kurikulum' => 'wakasek_kurikulum',
            'wakasek kesiswaan' => 'wakasek_kesiswaan',
            'operator' => 'operator',
        ];
        $roleInput = strtolower(trim($row['role'] ?? 'guru'));
        $role = $roleMap[$roleInput] ?? ($guruLama->role ?? 'guru');

        $status = $row['status'] ?? $guruLama->status ?? 'aktif';

        $matchKey = !empty($nip) ? ['nip' => $nip] : ['nama' => $nama];

        return Guru::updateOrCreate(
            $matchKey,
            [
                'nip'           => $nip ?: ($guruLama->nip ?? null),
                'nama'          => $nama,
                'jenis_kelamin' => $jk,
                'no_telp'       => $row['no_telp'] ?? ($guruLama->no_telp ?? null),
                'email'         => $row['email'] ?? ($guruLama->email ?? null),
                'role'          => $role,
                'status'        => $status,
            ]
        );
    }
}