<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Predikat extends Model
{
    protected $table = 'predikats';

    protected $fillable = [
        'predikat',
        'nilai_min',
        'nilai_max',
        'keterangan'
    ];
}