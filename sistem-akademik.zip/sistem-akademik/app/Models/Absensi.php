<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
    protected $table = 'absensi';

    protected $fillable = [
        'kelas_id',
        'guru_id',
        'mata_pelajaran_id',
        'tanggal',
        'tahun_ajaran',
        'semester',
        'jam_pelajaran',
    ];

    public function kelas()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }

    public function mataPelajaran()
    {
        return $this->belongsTo(MataPelajaran::class, 'mata_pelajaran_id');
    }

    public function detail()
    {
        return $this->hasMany(AbsensiDetail::class, 'absensi_id');
    }
}