<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersetujuanJadwal extends Model
{
    protected $table = 'persetujuan_jadwal';

    protected $fillable = [
        'jadwal_id',
        'guru_id',
        'status',
        'catatan',
    ];

    public function jadwal()
    {
        return $this->belongsTo(PenjadwalanMataPelajaran::class, 'jadwal_id');
    }

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }
}