<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BobotPenilaian extends Model
{
    protected $table = 'bobot_penilaian';

    protected $fillable = [
        'guru_id',
        'mata_pelajaran_id',
        'tahun_ajaran',
        'semester',
        'status',
    ];

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }

    public function mataPelajaran()
    {
        return $this->belongsTo(MataPelajaran::class, 'mata_pelajaran_id');
    }

    public function komponen()
    {
        return $this->hasMany(KomponenBobot::class, 'bobot_penilaian_id');
    }
}