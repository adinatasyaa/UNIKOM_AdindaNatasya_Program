<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PenjadwalanMataPelajaran extends Model
{
    protected $table = 'penjadwalan_mata_pelajaran';

    protected $fillable = [
        'kelas_id',
        'mata_pelajaran_id',
        'guru_id',
        'hari',
        'jam_mulai',
        'jam_selesai',
        'jumlah_jam',
        'tahun_ajaran',
        'semester',
        'status',
];

    public function kelas()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }

    public function mataPelajaran()
    {
        return $this->belongsTo(MataPelajaran::class, 'mata_pelajaran_id');
    }

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }

    public function persetujuan()
    {
        return $this->hasMany(PersetujuanJadwal::class, 'jadwal_id');
    }
}