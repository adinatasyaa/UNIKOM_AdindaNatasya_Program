<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PengumumanSpmb extends Model
{
    protected $table = 'pengumuman_spmb';

    protected $fillable = [
        'nama_siswa',
        'asal_sekolah',
        'status',
    ];
}