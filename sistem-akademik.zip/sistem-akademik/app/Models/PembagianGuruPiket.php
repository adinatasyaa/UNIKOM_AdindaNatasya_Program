<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PembagianGuruPiket extends Model
{
    use HasFactory;

    protected $table = 'pembagian_guru_piket';

    protected $fillable = [
        'guru_id',
        'hari',
        'tahun_ajaran',
        'semester',
    ];

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }
}