<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Spmb extends Model
{
    use HasFactory;

    protected $table = 'spmb'; 

   protected $fillable = [
    'id_pendaftaran',
    'nama_lengkap',
    'jenis_kelamin',
    'asal_sekolah',
    'no_kontak_siswa',
    'nama_orang_tua',
    'alamat',
    'no_kontak_orang_tua',
    'kartu_keluarga',
    'akte_kelahiran',
    'ktp_orang_tua',
    'sumber_informasi',
    'status',
    'hasil_seleksi',
    'tanggal_tes',
    'jam_tes',
    'ruangan',
    'keterangan'
];
}