<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Penilaian extends Model
{
    protected $table = 'penilaian';

    protected $fillable = [
        'siswa_id',
        'kelas_id',
        'mata_pelajaran_id',
        'guru_id',
        'tahun_ajaran',
        'semester',
        'nilai_akhir',
        'predikat',
        'status',
    ];

    public function siswa()
    {
        return $this->belongsTo(Siswa::class, 'siswa_id');
    }

    public function kelas()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }

    public function mataPelajaran()
    {
        return $this->belongsTo(MataPelajaran::class, 'mata_pelajaran_id');
    }

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }

    public function detail()
    {
        return $this->hasMany(NilaiDetail::class, 'penilaian_id');
    }

    public function getKeteranganAttribute()
    {
    if (!$this->nilai_akhir) {
        return null;
    }

    $predikat = Predikat::where('nilai_min', '<=', $this->nilai_akhir)
        ->orderByDesc('nilai_min')
        ->first();

    return $predikat->keterangan ?? null;
    }
}