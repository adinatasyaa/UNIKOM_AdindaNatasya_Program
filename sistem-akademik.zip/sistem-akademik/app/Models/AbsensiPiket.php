<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AbsensiPiket extends Model
{
    protected $table = 'absensi_piket';

    protected $fillable = [
        'siswa_id',
        'nama_siswa',
        'nama_kelas',
        'guru_piket_id',
        'tanggal',
        'status',
        'keterangan',
        'tahun_ajaran',
        'semester',
    ];

    public function siswa()
    {
        return $this->belongsTo(Siswa::class, 'siswa_id');
    }

    public function guruPiket()
    {
        return $this->belongsTo(Guru::class, 'guru_piket_id');
    }
}