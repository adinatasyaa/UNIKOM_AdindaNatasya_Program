<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NilaiDetail extends Model
{
    protected $table = 'nilai_detail';

    protected $fillable = [
        'penilaian_id',
        'komponen_bobot_id',
        'nilai',
    ];

    public function penilaian()
    {
        return $this->belongsTo(Penilaian::class, 'penilaian_id');
    }

    public function komponenBobot()
    {
        return $this->belongsTo(KomponenBobot::class, 'komponen_bobot_id');
    }
}