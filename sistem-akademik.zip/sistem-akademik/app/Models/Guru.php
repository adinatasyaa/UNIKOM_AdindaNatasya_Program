<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    protected $table = 'guru';
    
    protected $fillable = [
        'nip',
        'nama',
        'jenis_kelamin',
        'no_telp',
        'email',
        'role',
        'status',
    ];

    public function user()
    {
        return $this->hasOne(\App\Models\User::class, 'guru_id');
    }
}