<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KuotaTesSpmb extends Model
{
    protected $table = 'kuota_tes_spmb';
    protected $fillable = ['tanggal_mulai', 'tanggal_akhir', 'kuota_maks'];
    protected $casts = [
        'tanggal_mulai' => 'date',
        'tanggal_akhir' => 'date',
    ];

    public static function untukTanggal($tanggal)
    {
        $tgl = \Carbon\Carbon::parse($tanggal)->toDateString();

        return self::whereDate('tanggal_mulai', '<=', $tgl)
            ->whereDate('tanggal_akhir', '>=', $tgl)
            ->first();
    }
}