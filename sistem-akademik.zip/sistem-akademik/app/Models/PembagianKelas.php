<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PembagianKelas extends Model
{
    use HasFactory;

    protected $table = 'pembagian_kelas';

    protected $fillable = [
    'kelas_id',
    'guru_id',
    'tahun_ajaran',
    'semester',
    'status_persetujuan',
    'jenis',
];

    public function kelas()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }
}