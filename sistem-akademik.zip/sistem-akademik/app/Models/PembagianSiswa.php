<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PembagianSiswa extends Model
{
    use HasFactory;

    protected $table = 'pembagian_siswa';

    protected $fillable = [
        'siswa_id', 
        'kelas_id', 
        'tahun_ajaran', 
        'semester', 
        'status_pembagian'
    ];

    public function siswa()
    {
        return $this->belongsTo(Siswa::class, 'siswa_id');
    }

    public function kelas()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }
}