<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    protected $table = 'kelas';
    
    protected $fillable = [
        'nama_kelas',
        'tingkat',
        'tahun_ajaran',
        'wali_kelas_id',
        'status',
    ];

    public function waliKelas()
    {
        return $this->belongsTo(Guru::class, 'wali_kelas_id');
    }
    
    public function siswa()
    {
        return $this->hasMany(PembagianSiswa::class, 'kelas_id');
    }

    public function siswaAktif()
    {
    return $this->hasMany(\App\Models\Siswa::class, 'kelas_id');
    }
}