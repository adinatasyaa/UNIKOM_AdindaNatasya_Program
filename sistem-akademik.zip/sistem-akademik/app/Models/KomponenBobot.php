<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KomponenBobot extends Model
{
    protected $table = 'komponen_bobot';

    protected $fillable = [
        'bobot_penilaian_id',
        'nama_komponen',
        'jenis',
        'persentase',
    ];

    public function bobotPenilaian()
    {
        return $this->belongsTo(BobotPenilaian::class, 'bobot_penilaian_id');
    }

    public function nilaiDetail()
    {
        return $this->hasMany(NilaiDetail::class, 'komponen_bobot_id');
    }
}