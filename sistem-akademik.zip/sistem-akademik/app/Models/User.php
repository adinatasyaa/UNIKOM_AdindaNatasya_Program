<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'guru_id',
        'siswa_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'guru_id');
    }

    public function siswa()
    {
        return $this->belongsTo(Siswa::class, 'siswa_id');
    }

    public function isOperator()
    {
        return $this->role === 'operator';
    }

    public function isWakasekKurikulum()
    {
        return $this->role === 'wakasek_kurikulum';
    }

    public function isWakasekKesiswaan()
    {
        return $this->role === 'wakasek_kesiswaan';
    }

    public function isKepalaSekolah()
{
    return $this->role === 'kepala_sekolah';
}

    public function isGuru()
    {
        return in_array($this->role, ['guru', 'wali_kelas', 'wakasek_kurikulum', 'wakasek_kesiswaan']);
    }

    public function isWaliKelas()
    {
        return $this->role === 'wali_kelas';
    }

    public function isSiswa()
    {
        return $this->role === 'siswa';
    }

    public function isOrangTua()
    {
        return $this->role === 'orang_tua';
    }
}