<?php $__env->startSection('page-title', 'Tambah Guru'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Tambah Data Guru</h5>
    </div>

    <div class="card-body">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('operator.guru.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">NIP</label>
                    <input type="text"
                           name="nip"
                           class="form-control"
                           value="<?php echo e(old('nip')); ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Guru <span class="text-danger">*</span></label>
                    <input type="text"
                           name="nama"
                           class="form-control"
                           value="<?php echo e(old('nama')); ?>"
                           required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Jenis Kelamin</label>

                    <select name="jenis_kelamin" class="form-select">
                        <option value="">-- Pilih --</option>

                        <option value="L"
                            <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>>
                            Laki-laki
                        </option>

                        <option value="P"
                            <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>>
                            Perempuan
                        </option>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">No Telepon</label>

                    <input type="text"
                           name="no_telp"
                           class="form-control"
                           value="<?php echo e(old('no_telp')); ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>

                    <input type="email"
                           name="email"
                           class="form-control"
                           value="<?php echo e(old('email')); ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Role</label>

                    <select name="role" class="form-select" required>

                        <option value="">-- Pilih Role --</option>

                        <option value="guru"
                            <?php echo e(old('role') == 'guru' ? 'selected' : ''); ?>>
                            Guru
                        </option>

                        <option value="wali_kelas"
                            <?php echo e(old('role') == 'wali_kelas' ? 'selected' : ''); ?>>
                            Wali Kelas
                        </option>

                         <option value="kepala_sekolah"
                            <?php echo e(old('role') == 'kepala_sekolah' ? 'selected' : ''); ?>>
                            Kepala Sekolah
                        </option>

                        <option value="wakasek_kurikulum"
                            <?php echo e(old('role') == 'wakasek_kurikulum' ? 'selected' : ''); ?>>
                            Wakasek Kurikulum
                        </option>

                        <option value="wakasek_kesiswaan"
                            <?php echo e(old('role') == 'wakasek_kesiswaan' ? 'selected' : ''); ?>>
                            Wakasek Kesiswaan
                        </option>

                        <option value="operator"
                            <?php echo e(old('role') == 'operator' ? 'selected' : ''); ?>>
                            Operator
                        </option>

                        <option value="guru_piket"
                            <?php echo e(old('role') == 'guru_piket' ? 'selected' : ''); ?>>
                            Guru Piket
                        </option>

                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Status</label>

                    <select name="status" class="form-select">

                        <option value="aktif"
                            <?php echo e(old('status') == 'aktif' ? 'selected' : ''); ?>>
                            Aktif
                        </option>

                        <option value="tidak_aktif"
                            <?php echo e(old('status') == 'tidak_aktif' ? 'selected' : ''); ?>>
                            Tidak Aktif
                        </option>

                    </select>
                </div>

            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i>
                    Simpan
                </button>

                <a href="<?php echo e(route('operator.guru.index')); ?>"
                   class="btn btn-secondary">
                    Kembali
                </a>
            </div>

        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/guru/create.blade.php ENDPATH**/ ?>