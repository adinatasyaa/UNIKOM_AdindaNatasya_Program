<?php $__env->startSection('page-title', 'Penilaian Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Kelengkapan Nilai — <?php echo e($kelas->nama_kelas); ?></h5>
        <a href="<?php echo e(route('wali_kelas.penilaian.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Ganti Kelas
        </a>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Wali Kelas hanya dapat <strong>melihat</strong> nilai siswa. Penginputan nilai dilakukan oleh Guru Mata Pelajaran.
            Baris berwarna <span style="background:#f8d7da; padding:2px 8px; border-radius:4px;">merah</span> menandakan siswa belum melengkapi nilai di salah satu mata pelajaran.
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead style="font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Jumlah Mapel Dinilai</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="<?php echo e(!$d['lengkap'] ? 'background-color:#f8d7da;' : ''); ?>">
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($d['siswa']->nis); ?></td>
                        <td><?php echo e($d['siswa']->nama); ?></td>
                        <td><?php echo e($d['penilaian']->count()); ?> mata pelajaran</td>
                        <td>
                            <?php if($d['lengkap']): ?>
                                <span class="badge bg-success">Lengkap</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Belum Lengkap</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('wali_kelas.penilaian.detail', [$kelas->id, $d['siswa']->id])); ?>" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i> Lihat Detail
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada siswa di kelas ini</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/penilaian/show.blade.php ENDPATH**/ ?>