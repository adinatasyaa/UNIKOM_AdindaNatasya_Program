<?php $__env->startSection('page-title', 'Absensi Piket'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Absensi Piket</h5>
        <a href="<?php echo e(route('guru_piket.absensi.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Input Absensi Piket
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                        <th>Semester</th>
                        <th>Tahun Ajaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($absensi->firstItem() + $index); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($a->tanggal)->format('d/m/Y')); ?></td>
                        <td><?php echo e($a->nama_siswa ?? '-'); ?></td>
                        <td><?php echo e($a->nama_kelas ?? '-'); ?></td>
                        <td>
                            <?php if($a->status == 'terlambat'): ?>
                                <span class="badge bg-warning">Terlambat</span>
                            <?php elseif($a->status == 'izin_pulang'): ?>
                                <span class="badge bg-info">Izin Pulang</span>
                            <?php elseif($a->status == 'izin'): ?>
                                <span class="badge bg-primary">Izin</span>
                            <?php elseif($a->status == 'tidak_hadir'): ?>
                                <span class="badge bg-danger">Tidak Hadir</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($a->keterangan ?? '-'); ?></td>
                        <td>Semester <?php echo e($a->semester); ?></td>
                        <td><?php echo e($a->tahun_ajaran); ?></td>
                        <td class="text-center">
                            <div class="d-flex gap-1 justify-content-center">
                                <a href="<?php echo e(route('guru_piket.absensi.edit', $a->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('guru_piket.absensi.destroy', ['id' => $a->id])); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?> 
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data absensi ini?')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted">Belum ada data absensi piket</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($absensi->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru_piket/absensi/index.blade.php ENDPATH**/ ?>