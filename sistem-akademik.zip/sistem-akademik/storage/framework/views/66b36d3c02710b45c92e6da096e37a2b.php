<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <link rel="icon" type="image/jpeg" href="<?php echo e(asset('logoSekolah.jpg')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Sistem Akademik')); ?> - SMP Labschool UPI Kampus Cibiru</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background-color: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background-color: #212121;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
            overflow-y: auto;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: #fff;
            background-color: rgba(255,255,255,0.1);
        }
        .sidebar-brand {
            color: #fff;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            max-width: calc(100% - 250px);
        }
        .topbar {
            background-color: #fff;
            border-bottom: 1px solid #dee2e6;
            padding: 10px 20px;
            margin-bottom: 20px;
        }
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .card-body {
            overflow-x: auto;
        }

        main, .content-wrapper {
            max-width: 100%;
            overflow-x: hidden; 
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-brand">
            <?php if(auth()->guard()->check()): ?>
            <div class="d-flex align-items-center gap-2 mb-2">
                <img src="https://ui-avatars.com/api/?name=<?php echo e(auth()->user()->name); ?>&background=fff&color=1a237e&size=40"
                     class="rounded-circle" width="40" height="40">
                <div>
                    <div style="font-size:13px; font-weight:600;"><?php echo e(auth()->user()->name); ?></div>
                    <div style="font-size:11px; opacity:0.7;">
                        <?php echo e(ucwords(str_replace('_', ' ', auth()->user()->role))); ?>

                    </div>
                </div>
            </div>
            <small style="opacity:0.6; font-size:11px;">SMP Labschool UPI Kampus Cibiru</small>
            <?php endif; ?>
        </div>
        <nav class="mt-3">
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == 'operator'): ?>
                    <a href="<?php echo e(route('operator.dashboard')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('operator.dashboard') ? 'active' : ''); ?>">
                            <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>

                    <a href="<?php echo e(route('operator.siswa.index')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('operator.siswa.*') ? 'active' : ''); ?>">
                            <i class="bi bi-people me-2"></i> Data Siswa
                    </a>

                    <a href="<?php echo e(route('operator.guru.index')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('operator.guru.*') ? 'active' : ''); ?>">
                            <i class="bi bi-person-badge me-2"></i> Data Guru
                    </a>

                    <a href="<?php echo e(route('operator.kelas.index')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('operator.kelas.*') ? 'active' : ''); ?>">
                            <i class="bi bi-door-open me-2"></i> Data Kelas
                    </a>
                    <a href="<?php echo e(route('operator.mapel.index')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('operator.mapel.*') ? 'active' : ''); ?>">
                            <i class="bi bi-book me-2"></i> Data Mata Pelajaran
                    </a>

                    <a href="<?php echo e(route('operator.predikat.index')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('operator.predikat.*') ? 'active' : ''); ?>">
                            <i class="bi bi-gear me-2"></i> Setting Predikat
                    </a>
                    
            <?php elseif(auth()->user()->role == 'kepala_sekolah'): ?>
                <a href="<?php echo e(route('kepala_sekolah.dashboard')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('kepala_sekolah') ? 'active' : ''); ?>">
                            <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>

                <a href="<?php echo e(route('kepala_sekolah.jadwal.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('kepala_sekolah.jadwal.*') ? 'active' : ''); ?>">
                            <i class="bi bi-calendar-week me-2"></i>Jadwal Mata Pelajaran
                </a>
                  
                <a href="<?php echo e(route('kepala_sekolah.pembagian-guru-piket.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('kepala_sekolah.pembagian-guru-piket.*') ? 'active' : ''); ?>">
                            <i class="bi bi-person-check-fill me-2"></i>Pembagian Guru Piket
                </a>

                <a href="<?php echo e(route('kepala_sekolah.pembagian-kelas.index')); ?>"
                    class="nav-link <?php echo e(request()->routeIs('kepala_sekolah.pembagian-kelas.*') ? 'active' : ''); ?>">
                        <i class="bi bi-diagram-3 me-2"></i>Pembagian Kelas
                </a>

                <a href="<?php echo e(route('kepala_sekolah.absensi.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('kepala_sekolah.absensi.*') ? 'active' : ''); ?>">
                            <i class="bi bi-clipboard-check me-2"></i>Absensi
                </a>

                <a href="<?php echo e(route('kepala_sekolah.penilaian.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('kepala_sekolah.penilaian.*') ? 'active' : ''); ?>">
                            <i class="bi bi-clipboard-data me-2"></i>Penilaian
                </a>
   
                <?php elseif(auth()->user()->role == 'wakasek_kurikulum'): ?>
                <a href="<?php echo e(route('kurikulum.dashboard')); ?>" 
                    class="nav-link <?php echo e(request()->routeIs('kurikulum.dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>

                <a href="<?php echo e(route('kurikulum.spmb.index')); ?>" 
                    class="nav-link <?php echo e(request()->routeIs('kurikulum.spmb.index', 'kurikulum.spmb.show') ? 'active' : ''); ?>">
                        <i class="bi bi-person-plus me-2"></i> Data SPMB
                </a>

                <a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" 
                    class="nav-link <?php echo e(request()->routeIs('kurikulum.spmb.data_seleksi', 'kurikulum.spmb.data_seleksi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-check me-2"></i> Data Seleksi
                </a>

                <a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" 
                    class="nav-link <?php echo e(request()->routeIs('kurikulum.spmb.hasil_seleksi', 'kurikulum.spmb.hasil_seleksi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-award me-2"></i> Data Hasil Seleksi
                </a>

                <a href="<?php echo e(route('kurikulum.mapel.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.mapel.*') ? 'active' : ''); ?>">
                    <i class="bi bi-book me-2"></i> Kelola Mata Pelajaran
                </a>
                
                <a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" 
                    class="nav-link <?php echo e(request()->routeIs('kurikulum.penjadwalan.*') ? 'active' : ''); ?>">
                        <i class="bi bi-calendar-event me-2"></i> Penjadwalan
                </a>

                <?php elseif(auth()->user()->role == 'wakasek_kesiswaan'): ?>
                    <a href="<?php echo e(route('kesiswaan.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('kesiswaan.dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>

                    <a href="<?php echo e(route('kesiswaan.registrasi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kesiswaan.registrasi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-person-lines-fill me-2"></i> Daftar Siswa Registrasi
                    </a>

                    <a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" 
                        class="nav-link <?php echo e(request()->routeIs('kesiswaan.pembagian.*') ? 'active' : ''); ?>">
                            <i class="bi bi-people me-2"></i> Pembagian Kelas
                    </a>
                    
                
                <?php elseif(auth()->user()->role == 'guru'): ?>
                    <a href="<?php echo e(route('guru.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('guru.dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>

                    <a href="<?php echo e(route('guru.absensi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('guru.absensi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-check me-2"></i> Absensi
                    </a>

                    <a href="<?php echo e(route('guru.bobot.index')); ?>" class="nav-link <?php echo e(request()->routeIs('guru.bobot.*') || request()->routeIs('guru.penilaian.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-data me-2"></i> Penilaian
                    </a>

                    <a href="<?php echo e(route('guru.jadwal_mengajar.index')); ?>" class="nav-link <?php echo e(request()->routeIs('guru.jadwal_mengajar.*') ? 'active' : ''); ?>">
                        <i class="bi bi-calendar3 me-2"></i> Jadwal Mengajar
                    </a>

                <?php elseif(auth()->user()->role == 'wali_kelas'): ?>
                    <a href="<?php echo e(route('wali_kelas.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('wali_kelas.dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>

                    <a href="<?php echo e(route('wali_kelas.absensi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('wali_kelas.absensi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-check me-2"></i> Absensi
                    </a>

                    <a href="<?php echo e(route('wali_kelas.penilaian.index')); ?>" class="nav-link <?php echo e(request()->routeIs('wali_kelas.penilaian.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-data me-2"></i> Penilaian
                    </a>
                    
                    <a href="<?php echo e(route('wali_kelas.pembagian_kelas.index')); ?>" class="nav-link <?php echo e(request()->routeIs('wali_kelas.pembagian_kelas.*') ? 'active' : ''); ?>">
                        <i class="bi bi-diagram-3 me-2"></i> Pembagian Kelas
                    </a>
                    
                <?php elseif(auth()->user()->role == 'guru_piket'): ?>
                    <a href="<?php echo e(route('guru_piket.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('guru_piket.dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>

                    <a href="<?php echo e(route('guru_piket.pembagian-guru-piket.index')); ?>" class="nav-link <?php echo e(request()->routeIs('guru_piket.pembagian-guru-piket.*') ? 'active' : ''); ?>">
                        <i class="bi bi-person-check me-2"></i>Jadwal Guru Piket
                    </a>

                    <a href="<?php echo e(route('guru_piket.absensi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('guru_piket.absensi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-check me-2"></i> Absensi Piket
                    </a>

                <?php elseif(auth()->user()->role == 'siswa'): ?>
                    <a href="<?php echo e(route('siswa.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('siswa.dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>

                    <a href="<?php echo e(route('siswa.pembagian-kelas.index')); ?>"class="nav-link <?php echo e(request()->routeIs('siswa.pembagian-kelas.*') ? 'active' : ''); ?>">
                        <i class="bi bi-diagram-3 me-2"></i>Pembagian Kelas
                    </a>

                    <a href="<?php echo e(route('siswa.jadwal.index')); ?>" class="nav-link <?php echo e(request()->routeIs('siswa.jadwal.*') ? 'active' : ''); ?>">
                        <i class="bi bi-calendar3 me-2"></i> Jadwal Pelajaran
                    </a>

                    <a href="<?php echo e(route('siswa.absensi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('siswa.absensi.*') ? 'active' : ''); ?>">
                        <i class="bi bi-clipboard-check me-2"></i> Absensi
                    </a>

                    <a href="<?php echo e(route('siswa.penilaian.index')); ?>" class="nav-link <?php echo e(request()->routeIs('siswa.penilaian.*') ? 'active' : ''); ?>">
                        <i class="bi bi-journal-text me-2"></i> Penilaian
                    </a>

                <?php endif; ?>
            <?php endif; ?>
        </nav>
    </div>

    <div class="main-content">
        <div class="topbar d-flex justify-content-between align-items-center rounded">
            <h6 class="mb-0"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h6>
            <?php if(auth()->guard()->check()): ?>
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(auth()->user()->name); ?>&background=1a237e&color=fff&size=32"
                         class="rounded-circle me-1" width="28" height="28">
                    <?php echo e(auth()->user()->name); ?>

                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                            <i class="bi bi-person-gear me-1"></i> Profil & Ganti Password
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item text-danger">
                                <i class="bi bi-box-arrow-right me-1"></i> Logout
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/layouts/app.blade.php ENDPATH**/ ?>