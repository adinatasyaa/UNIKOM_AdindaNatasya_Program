

<?php $__env->startSection('page-title', 'Data Seleksi'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kurikulum.dashboard')); ?>" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
<a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="nav-link"><i class="bi bi-person-plus me-2"></i> Data SPMB</a>
<a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" class="nav-link active"><i class="bi bi-clipboard-check me-2"></i> Data Seleksi</a>
<a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" class="nav-link"><i class="bi bi-award me-2"></i> Data Hasil Seleksi</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Seleksi (Absensi Tes)</h5>
        <a href="<?php echo e(route('kurikulum.spmb.data_seleksi.download')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-download me-1"></i> Download PDF
        </a>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID Pendaftaran</th>
                    <th>Nama Siswa</th>
                    <th>Ruangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $spmb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($s->id_pendaftaran); ?></td>
                    <td><?php echo e($s->nama_lengkap); ?></td>
                    <td><?php echo e($s->ruangan ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted">Belum ada siswa yang dijadwalkan tes</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/spmb/data_seleksi.blade.php ENDPATH**/ ?>