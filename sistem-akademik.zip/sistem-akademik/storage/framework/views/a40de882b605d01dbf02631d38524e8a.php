<?php $__env->startSection('page-title', 'Detail Absensi'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Absensi</h5>
        <a href="<?php echo e(route('wali_kelas.absensi.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Mata Pelajaran</td>
                        <td><strong><?php echo e($absensi->mataPelajaran->nama_mapel ?? '-'); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Kelas</td>
                        <td><?php echo e($absensi->kelas->nama_kelas ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Guru</td>
                        <td><?php echo e($absensi->guru->nama ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td><?php echo e(\Carbon\Carbon::parse($absensi->tanggal)->format('d/m/Y')); ?></td>
                    </tr>
                    <tr>
                        <td>Jam Pelajaran</td>
                        <td><?php echo e($absensi->jam_pelajaran); ?></td>
                    </tr>
                    <tr>
                        <td>Semester</td>
                        <td>Semester <?php echo e($absensi->semester); ?></td>
                    </tr>
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td><?php echo e($absensi->tahun_ajaran); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <h6 class="fw-bold mb-3">Daftar Kehadiran Siswa</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Status Kehadiran</th>
                        <th>Keterangan</th>
                        <th>Diperbarui Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $absensi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($d->siswa->nis ?? '-'); ?></td>
                        <td><?php echo e($d->siswa->nama ?? '-'); ?></td>
                        <td>
                            <?php if($d->status_kehadiran == 'Hadir'): ?>
                                <span class="badge" style="background:#28a745;">Hadir</span>
                            <?php elseif($d->status_kehadiran == 'Izin'): ?>
                                <span class="badge" style="background:#007bff;">Izin</span>
                            <?php elseif($d->status_kehadiran == 'Sakit'): ?>
                                <span class="badge" style="background:#fd7e14;">Sakit</span>
                            <?php elseif($d->status_kehadiran == 'Alpa'): ?>
                                <span class="badge" style="background:#dc3545;">Alpa</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($d->keterangan ?? '-'); ?></td>
                        <td><?php echo e($d->updatedBy->name ?? '-'); ?></td>
                        <td>
                            <!-- Form Update Wali Kelas -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                data-bs-target="#editModal<?php echo e($d->id); ?>">
                                <i class="bi bi-pencil"></i>
                            </button>

                            <div class="modal fade" id="editModal<?php echo e($d->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Update Kehadiran - <?php echo e($d->siswa->nama ?? '-'); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form action="<?php echo e(route('wali_kelas.absensi.update', $d->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Status Kehadiran</label>
                                                    <select name="status_kehadiran" class="form-select" required>
                                                        <option value="Hadir" <?php echo e($d->status_kehadiran == 'Hadir' ? 'selected' : ''); ?>>Hadir</option>
                                                        <option value="Izin" <?php echo e($d->status_kehadiran == 'Izin' ? 'selected' : ''); ?>>Izin</option>
                                                        <option value="Sakit" <?php echo e($d->status_kehadiran == 'Sakit' ? 'selected' : ''); ?>>Sakit</option>
                                                        <option value="Alpa" <?php echo e($d->status_kehadiran == 'Alpa' ? 'selected' : ''); ?>>Alpa</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Keterangan</label>
                                                    <textarea name="keterangan" class="form-control" rows="3"><?php echo e($d->keterangan); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data kehadiran</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/absensi/show.blade.php ENDPATH**/ ?>