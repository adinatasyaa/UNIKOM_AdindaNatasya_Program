

<?php $__env->startSection('page-title', 'Pembagian Kelas'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h4>Pembagian Kelas</h4>
            <p class="text-muted">
                Informasi pembagian kelas yang telah ditetapkan oleh sekolah.
            </p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>


            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>
        </div>
    <?php endif; ?>


    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Data Pembagian Kelas</strong>
        </div>
        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">

                    <tr>
                        <th width="60">No</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                        <th>Kelas</th>
                        <th>Status</th>
                    </tr>

                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->tahun_ajaran); ?></td>
                        <td><?php echo e($item->semester); ?></td>
                        <td><strong><?php echo e($item->kelas->nama_kelas ?? '-'); ?></strong></td>
                        <td>
                            <?php if($item->status_pembagian == 'final'): ?>
                                <span class="badge bg-success">Final</span>
                            <?php elseif($item->status_pembagian == 'draft'): ?>
                                <span class="badge bg-secondary">Draft</span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e(ucfirst($item->status_pembagian)); ?></span>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5"
                            class="text-center py-4 text-muted">
                            Belum ada data pembagian kelas.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/siswa/pembagian_kelas/index.blade.php ENDPATH**/ ?>