

<?php $__env->startSection('page-title', 'Pembagian Guru Piket'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Pembagian Guru Piket</h5>

        <a href="<?php echo e(route('kepala_sekolah.pembagian-guru-piket.create')); ?>"
           class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i>
            Tambah Guru Piket
        </a>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Guru</th>
                    <th>Hari</th>
                    <th>Tahun Ajaran</th>
                    <th>Semester</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->guru->nama); ?></td>
                    <td><?php echo e($item->hari); ?></td>
                    <td><?php echo e($item->tahun_ajaran); ?></td>
                    <td><?php echo e($item->semester); ?></td>
                    <td class="text-center text-nowrap">
                        <a href="<?php echo e(route('kepala_sekolah.pembagian-guru-piket.edit', $item->id)); ?>"
                           class="btn btn-warning btn-sm"
                           title="Edit">
                            <i class="bi bi-pencil-square"></i>
                        </a>

                        <form action="<?php echo e(route('kepala_sekolah.pembagian-guru-piket.destroy', $item->id)); ?>"
                              method="POST"
                              class="d-inline"
                              onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    class="btn btn-danger btn-sm"
                                    title="Hapus">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">
                        Belum ada pembagian guru piket.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kepala_sekolah/index.blade.php ENDPATH**/ ?>