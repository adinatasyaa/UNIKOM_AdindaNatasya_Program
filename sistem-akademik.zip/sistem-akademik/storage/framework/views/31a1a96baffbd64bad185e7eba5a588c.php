<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .header-table td { border: none; vertical-align: middle; padding: 0; }
        .header-table .logo-cell { width: 70px; }
        .header-table .logo-cell img { width: 60px; height: auto; }
        .header-table .text-cell { text-align: center; }
        .header-table h3 { margin: 0; font-size: 16px; }
        .header-table p { margin: 2px 0 0 0; font-size: 12px; }
        hr { border: none; border-top: 2px solid #333; margin: 5px 0 15px 0; }
        table.data { width: 100%; border-collapse: collapse; }
        table.data th, table.data td { border: 1px solid #333; padding: 6px 8px; text-align: center; }
        table.data th { background: #eee; }
        table.data td.mapel { text-align: left; }
        .info { margin-bottom: 10px; }
        .info td { border: none; padding: 2px 0; text-align: left; }
        .ttd { margin-top: 40px; }
    </style>
</head>
<body>
    <table class="header-table">
        <tr>
            <td class="logo-cell">
                <img src="data:image/jpeg;base64,<?php echo e($logoBase64); ?>">
            </td>
           <td class="text-cell">
                <h3>LAPORAN NILAI SISWA</h3>
                <p>SMP LABSCHOOL UPI KAMPUS CIBIRU</p>
           </td>
            <td class="logo-cell"></td>
        </tr>
    </table>
    <hr>

    <table class="info">
        <tr><td width="120">Nama</td><td>: <?php echo e($siswa->nama); ?></td></tr>
        <tr><td>NIS</td><td>: <?php echo e($siswa->nis); ?></td></tr>
        <tr><td>Kelas</td><td>: <?php echo e($kelas->nama_kelas); ?></td></tr>
        <tr><td>Semester</td><td>: <?php echo e($penilaian->first()->semester ?? '-'); ?></td></tr>
        <tr><td>Tahun Ajaran</td><td>: <?php echo e($penilaian->first()->tahun_ajaran ?? '-'); ?></td></tr>
    </table>

    <table class="data">
        <thead>
            <tr>
                <th style="width: 5%;">No</th>
                <th>Mata Pelajaran</th>
                <th>Nilai Akhir</th>
                <th>Predikat</th>
                <th>Keterangan</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td class="mapel"><?php echo e($p->mataPelajaran->nama_mapel ?? '-'); ?></td>
                <td><?php echo e($p->nilai_akhir ?? '-'); ?></td>
                <td><?php echo e($p->predikat ?? '-'); ?></td>
                <td><?php echo e($p->keterangan ?? '-'); ?></td>
                <td><?php echo e(ucfirst(str_replace('_', ' ', $p->status))); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">Belum ada data nilai</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="ttd">
        <p>Bandung, <?php echo e(now()->translatedFormat('d F Y')); ?></p>
        <br><p><?php echo e(auth()->user()->name ?? 'Wali Kelas'); ?></p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/penilaian/rapor_pdf.blade.php ENDPATH**/ ?>