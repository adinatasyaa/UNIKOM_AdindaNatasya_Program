<?php $__env->startSection('page-title', 'Edit Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Mata Pelajaran</h5>

        <a href="<?php echo e(route('operator.mapel.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('operator.mapel.update', $mapel)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Kode Mata Pelajaran <span class="text-danger">*</span></label>
                    <input type="text" name="kode_mapel" class="form-control"
                        value="<?php echo e(old('kode_mapel', $mapel->kode_mapel)); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nama Mata Pelajaran <span class="text-danger">*</span></label>
                    <input type="text" name="nama_mapel" class="form-control"
                        value="<?php echo e(old('nama_mapel', $mapel->nama_mapel)); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Guru Pengampu</label>
                    <select name="guru_id" class="form-select">
                        <option value="">-- Pilih Guru --</option>
                        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($g->id); ?>"
                                <?php echo e(old('guru_id', $mapel->guru_id) == $g->id ? 'selected' : ''); ?>>
                                <?php echo e($g->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
               <div class="col-md-6">
                    <label class="form-label">Alokasi Waktu</label>
                    <div class="input-group">
                        <input type="text" class="form-control" value="<?php echo e($mapel->alokasi_waktu); ?>" disabled>
                        <span class="input-group-text">jam/minggu</span>
                    </div>
                        <small class="text-muted">Diatur oleh Wakasek Kurikulum, tidak dapat diubah di sini.</small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status <span class="text-danger">*</span></label>
                    <select name="status" class="form-select" required>
                        <option value="aktif" <?php echo e(old('status', $mapel->status) == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="tidak_aktif" <?php echo e(old('status', $mapel->status) == 'tidak_aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Update
                </button>
                <a href="<?php echo e(route('operator.mapel.index')); ?>" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/mapel/edit.blade.php ENDPATH**/ ?>