<?php $__env->startSection('page-title', 'Edit Guru'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Edit Data Guru</h5>
    </div>

```
<div class="card-body">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('operator.guru.update', $guru->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">

            <div class="col-md-6 mb-3">
                <label class="form-label">NIP</label>
                <input type="text" name="nip" class="form-control"
                    value="<?php echo e(old('nip', $guru->nip)); ?>">
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">Nama Guru</label>
                <input type="text" name="nama" class="form-control"
                    value="<?php echo e(old('nama', $guru->nama)); ?>" required>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">Jenis Kelamin</label>
                <select name="jenis_kelamin" class="form-select">

                    <option value="">-- Pilih --</option>

                    <option value="L"
                        <?php echo e(old('jenis_kelamin', $guru->jenis_kelamin) == 'L' ? 'selected' : ''); ?>>
                        Laki-laki
                    </option>

                    <option value="P"
                        <?php echo e(old('jenis_kelamin', $guru->jenis_kelamin) == 'P' ? 'selected' : ''); ?>>
                        Perempuan
                    </option>

                </select>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">No Telepon</label>
                <input type="text" name="no_telp" class="form-control"
                    value="<?php echo e(old('no_telp', $guru->no_telp)); ?>">
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control"
                    value="<?php echo e(old('email', $guru->email)); ?>">
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-select" required>

                    <option value="guru"
                        <?php echo e(old('role', $guru->role) == 'guru' ? 'selected' : ''); ?>>
                        Guru
                    </option>

                    <option value="wali_kelas"
                        <?php echo e(old('role', $guru->role) == 'wali_kelas' ? 'selected' : ''); ?>>
                        Wali Kelas
                    </option>

                     <option value="kepala_sekolah"
                        <?php echo e(old('role', $guru->role) == 'kepala_sekolah' ? 'selected' : ''); ?>>
                        Kepala Sekolah
                    </option>

                    <option value="wakasek_kurikulum"
                        <?php echo e(old('role', $guru->role) == 'wakasek_kurikulum' ? 'selected' : ''); ?>>
                        Wakasek Kurikulum
                    </option>

                    <option value="wakasek_kesiswaan"
                        <?php echo e(old('role', $guru->role) == 'wakasek_kesiswaan' ? 'selected' : ''); ?>>
                        Wakasek Kesiswaan
                    </option>

                    <option value="operator"
                        <?php echo e(old('role', $guru->role) == 'operator' ? 'selected' : ''); ?>>
                        Operator
                    </option>

                     <option value="guru_piket"
                        <?php echo e(old('role', $guru->role) == 'guru_piket' ? 'selected' : ''); ?>>
                        Guru Piket
                    </option>

                </select>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">Status</label>

                <select name="status" class="form-select">

                    <option value="aktif"
                        <?php echo e(old('status', $guru->status) == 'aktif' ? 'selected' : ''); ?>>
                        Aktif
                    </option>

                    <option value="tidak_aktif"
                        <?php echo e(old('status', $guru->status) == 'tidak_aktif' ? 'selected' : ''); ?>>
                        Tidak Aktif
                    </option>

                </select>
            </div>

        </div>

        <button type="submit" class="btn btn-primary">
            <i class="bi bi-pencil-square me-1"></i>
            Update
        </button>

        <a href="<?php echo e(route('operator.guru.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>

    </form>

</div>
```

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/guru/edit.blade.php ENDPATH**/ ?>