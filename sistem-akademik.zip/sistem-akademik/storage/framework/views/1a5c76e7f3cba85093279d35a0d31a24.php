<?php $__env->startSection('page-title', 'Input Nilai'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    
<div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Input Nilai — <?php echo e($bobot->mataPelajaran->nama_mapel ?? '-'); ?> (<?php echo e($kelas->nama_kelas); ?>)</h5>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('guru.penilaian.pilih_kelas', $bobot->id)); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Ganti Kelas
        </a>
        <a href="<?php echo e(route('guru.penilaian.unduh', [$bobot->id, $kelas->id])); ?>" class="btn btn-success btn-sm">
            <i class="bi bi-download me-1"></i> Unduh Laporan
        </a>
    </div>
</div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <table class="table table-bordered mb-4">
            <tr>
                <td width="30%">Mata Pelajaran</td>
                <td><strong><?php echo e($bobot->mataPelajaran->nama_mapel ?? '-'); ?></strong></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td><?php echo e($kelas->nama_kelas); ?></td>
            </tr>
            <tr>
                <td>Semester</td>
                <td>Semester <?php echo e($bobot->semester); ?></td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td><?php echo e($bobot->tahun_ajaran); ?></td>
            </tr>
        </table>
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Bobot: 
            <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-secondary"><?php echo e($k->nama_komponen); ?> (<?php echo e($k->persentase); ?>%)</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <form action="<?php echo e(route('guru.penilaian.store', [$bobot->id, $kelas->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead style="font-weight:600;">
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($k->nama_komponen); ?><br><small>(<?php echo e($k->persentase); ?>%)</small></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th>Nilai Akhir</th>
                            <th>Predikat</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr style="<?php echo e($d['penilaian']->status == 'belum_lengkap' ? 'background-color:#f8d7da;' : ''); ?>">
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($d['siswa']->nis); ?></td>
                            <td><?php echo e($d['siswa']->nama); ?></td>
                            <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <input type="number" step="0.01" min="0" max="100"
                                    name="nilai[<?php echo e($d['penilaian']->id); ?>][<?php echo e($k->id); ?>]"
                                    class="form-control form-control-sm"
                                    value="<?php echo e($d['nilai'][$k->id]); ?>"
                                    <?php echo e($d['penilaian']->status == 'final' ? 'readonly' : ''); ?>>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><strong><?php echo e($d['penilaian']->nilai_akhir ?? '-'); ?></strong></td>
                            <td class="text-center">
                                <?php if($d['penilaian']->predikat): ?>
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <span class="badge bg-primary"><?php echo e($d['penilaian']->predikat); ?></span>
                                        <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                            <?php echo e($d['penilaian']->keterangan); ?>

                                        </span>
                                    </div>
                                <?php else: ?>
                                 -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($d['penilaian']->status == 'final'): ?>
                                    <span class="badge bg-success">Final</span>
                                <?php elseif($d['penilaian']->status == 'lengkap'): ?>
                                    <span class="badge bg-info">Lengkap</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Belum Lengkap</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted">Belum ada siswa di kelas ini</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3 d-flex gap-2">
                <button type="submit" name="aksi" value="sementara" class="btn btn-warning">
                    <i class="bi bi-save me-1"></i> Simpan Sementara
                </button>
                <button type="submit" name="aksi" value="final" class="btn btn-success"
                    onclick="return confirm('Yakin ingin menyimpan nilai secara FINAL? Data tidak bisa diubah lagi setelah ini.')">
                    <i class="bi bi-check-circle me-1"></i> Simpan Final
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/penilaian/index.blade.php ENDPATH**/ ?>