

<?php $__env->startSection('page-title','Approval Pembagian Kelas'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="card">

    <div class="card-header">
        <h5>Approval Pembagian Kelas</h5>
    </div>

    <div class="card-body">
        <table class="table table-bordered">

    <thead>
        <tr>
            <th>No</th>
            <th>Kelas</th>
            <th>Wali Kelas</th>
            <th>Tahun Ajaran</th>
            <th>Semester</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <tr>

        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($item->kelas->nama_kelas); ?></td>
        <td><?php echo e($item->guru->nama); ?></td>
        <td><?php echo e($item->tahun_ajaran); ?></td>
        <td><?php echo e($item->semester); ?></td>
    <td>

    <?php if($item->status_persetujuan=='menunggu'): ?>
    <span class="badge bg-warning">
        Menunggu Persetujuan
    </span>

    <?php elseif($item->status_persetujuan=='disetujui'): ?>
    <span class="badge bg-success">
        Disetujui
    </span>
    <?php else: ?>

    <span class="badge bg-danger">
        Ditolak
    </span>

    <?php endif; ?>
</td>
    <td>

    <?php if($item->status_persetujuan=='menunggu'): ?>

    <form action="<?php echo e(route('kepala_sekolah.pembagian-kelas.setujui',$item->id)); ?>"method="POST"class="d-inline">

    <?php echo csrf_field(); ?>

        <button class="btn btn-success btn-sm">
            Setujui
        </button>

    </form>

    <form action="<?php echo e(route('kepala_sekolah.pembagian-kelas.tolak',$item->id)); ?>"method="POST"class="d-inline">

    <?php echo csrf_field(); ?>

        <button class="btn btn-danger btn-sm">
            Tolak
        </button>

    </form>

    <?php else: ?>

    <?php endif; ?>

    </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <tr>

        <td colspan="7" class="text-center">
            Belum ada data.
    </td>
</tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kepala_sekolah/pembagian_kelas/index.blade.php ENDPATH**/ ?>