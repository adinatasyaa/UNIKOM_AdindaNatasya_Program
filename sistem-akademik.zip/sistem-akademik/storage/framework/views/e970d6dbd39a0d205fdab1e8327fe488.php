<?php $__env->startSection('page-title', 'Penilaian'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="mb-3">
        <h4>Data Penilaian</h4>
        <p class="text-muted">
            Nilai siswa berdasarkan kelas.
        </p>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            <form method="GET"
                  action="<?php echo e(route('kepala_sekolah.penilaian.index')); ?>">
                <div class="row">
                    <div class="col-md-4">
                        <label>Pilih Kelas</label>
                        <select name="kelas_id" class="form-select">
                            <option value="">-- Pilih Kelas --</option>

                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>"
                                    <?php echo e(request('kelas_id')==$k->id ? 'selected' : ''); ?>>
                                    <?php echo e($k->nama_kelas); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div class="col-md-2 align-self-end">

                        <button class="btn btn-primary">
                            Tampilkan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if(request('kelas_id')): ?>
    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Daftar Penilaian</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">
                <tr class="text-center">
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Mata Pelajaran</th>
                    <th>Guru</th>
                    <th>Nilai</th>
                    <th>Predikat</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>
                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->siswa->nama ?? '-'); ?></td>
                    <td><?php echo e($item->mataPelajaran->nama_mapel ?? '-'); ?></td>
                    <td><?php echo e($item->guru->nama ?? '-'); ?></td>
                    <td class="text-center fw-bold"><?php echo e($item->nilai_akhir); ?></td>
                    <td class="text-center">
                        <div class="d-flex flex-column align-items-center gap-1">
                            <span class="fw-bold"><?php echo e($item->predikat); ?></span>
                            <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                <?php echo e($item->keterangan); ?>

                            </span>
                        </div>
                    </td>
                    <td class="text-center">
                        <?php if($item->status=='aktif'): ?>
                            <span class="badge bg-success">
                                Aktif
                            </span>
                        <?php else: ?>
                            <span class="badge bg-secondary">
                                <?php echo e(ucfirst($item->status)); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center py-4">
                        Tidak ada data penilaian.
                    </td>
                </tr>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kepala_sekolah/penilaian/index.blade.php ENDPATH**/ ?>