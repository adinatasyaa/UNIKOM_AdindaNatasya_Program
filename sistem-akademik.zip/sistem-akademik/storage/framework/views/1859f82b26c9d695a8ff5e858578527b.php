<?php $__env->startSection('page-title', 'Data Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Kelas</h5>

        <a href="<?php echo e(route('operator.kelas.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Tambah Kelas
        </a>
    </div>

    <div class="card-body">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('operator.kelas.index')); ?>" method="GET" class="mb-3">
            <div class="input-group" style="max-width: 350px;">
                <input type="text" name="search" class="form-control"
                    placeholder="Cari nama kelas, atau wali kelas..." value="<?php echo e(request('search')); ?>">
                <button class="btn btn-outline-secondary" type="submit">
                    <i class="bi bi-search"></i>
                </button>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('operator.kelas.index')); ?>" class="btn btn-outline-danger">
                        <i class="bi bi-x"></i>
                    </a>
                <?php endif; ?>
            </div>
</form>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>Nama Kelas</th>
                        <th>Tingkat</th>
                        <th>Tahun Ajaran</th>
                        <th>Wali Kelas</th>
                        <th>Status</th>
                        <th width="120">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($kelas->firstItem() + $index); ?></td>
                        <td><?php echo e($k->nama_kelas); ?></td>
                        <td><?php echo e($k->tingkat); ?></td>
                        <td><?php echo e($k->tahun_ajaran); ?></td>

                        <td>
                            <?php echo e($k->waliKelas->nama ?? '-'); ?>

                        </td>

                        <td>
                            <span class="badge <?php echo e($k->status == 'aktif' ? 'bg-success' : 'bg-danger'); ?>">
                                <?php echo e(ucfirst($k->status)); ?>

                            </span>
                        </td>

                        <td>
                            <div class="d-flex gap-2">
                                <a href="<?php echo e(route('operator.kelas.edit', $k)); ?>" class="btn btn-warning btn-sm">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('operator.kelas.destroy', $k)); ?>" method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus kelas ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Belum ada data kelas
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php echo e($kelas->links('pagination::bootstrap-5')); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/kelas/index.blade.php ENDPATH**/ ?>