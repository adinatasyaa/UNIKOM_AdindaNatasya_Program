<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PPDB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #fff; }
        .navbar-custom {
            background-color: #fff;
            border-bottom: 2px solid #0a1050;
        }
        .hero {
            background-color: #fff;
            padding: 60px 0 40px 0;
            border-bottom: 1px solid #e9ecef;
        }
        .hero h1 { color: #0a1050; font-weight: 700; }
        .hero p { color: #0a1050; }
        .card-menu {
            border: 1px solid #0a1050;
            border-radius: 12px;
            transition: all 0.3s;
            background-color: #fff;
        }
        .card-menu:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(26,35,126,0.15);
            border-color: #0a1050;
        }
        .card-menu .icon-wrap {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px auto;
        }
        footer {
            background-color: #0a1050;
            color: rgba(255,255,255,0.8);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-custom">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-3">
                <img src="<?php echo e(asset('logo.png')); ?>" width="45" height="45" style="object-fit:contain;">
                <div>
                    <div style="font-weight:700;color:#1a237e;font-size:15px;">SMP Labschool UPI Kampus Cibiru</div>
                    <div style="font-size:11px;color:#888;">Penerimaan Peserta Didik Baru</div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero -->
    <div class="hero text-center">
        <div class="container">
            <div class="mb-3">
                <span style="background:#e8eaf6;color:#1a237e;padding:6px 18px;border-radius:20px;font-size:13px;font-weight:600;">
                    Tahun Ajaran 2026/2027
                </span>
            </div>
            <h1 class="mb-3">Penerimaan Peserta Didik Baru</h1>
            <p class="lead mb-0">SMP Labschool UPI Kampus Cibiru</p>
            <p class="text-muted" style="font-size:14px;">Daftarkan putra/putri Anda sekarang</p>
        </div>
    </div>

    <!-- Menu -->
    <div class="container py-5">
        <div class="row g-4 justify-content-center">
            <div class="col-md-4">
                <a href="<?php echo e(route('ppdb.create')); ?>" class="text-decoration-none">
                    <div class="card card-menu text-center p-4 h-100">
                        <div class="icon-wrap" style="background:#e8eaf6;">
                            <i class="bi bi-pencil-square" style="font-size:1.8rem;color:#1a237e;"></i>
                        </div>
                        <h5 class="fw-bold" style="color:#1a237e;">Formulir Pendaftaran</h5>
                        <p class="text-muted mb-0" style="font-size:14px;">Isi formulir pendaftaran siswa baru secara online</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="<?php echo e(route('ppdb.cek_status')); ?>" class="text-decoration-none">
                    <div class="card card-menu text-center p-4 h-100">
                        <div class="icon-wrap" style="background:#e8f5e9;">
                            <i class="bi bi-search" style="font-size:1.8rem;color:#2e7d32;"></i>
                        </div>
                        <h5 class="fw-bold" style="color:#2e7d32;">Cek Status Pendaftaran</h5>
                        <p class="text-muted mb-0" style="font-size:14px;">Pantau status pendaftaran putra/putri Anda</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="<?php echo e(route('ppdb.pengumuman')); ?>" class="text-decoration-none">
                    <div class="card card-menu text-center p-4 h-100">
                        <div class="icon-wrap" style="background:#fff8e1;">
                            <i class="bi bi-megaphone" style="font-size:1.8rem;color:#f57f17;"></i>
                        </div>
                        <h5 class="fw-bold" style="color:#f57f17;">Pengumuman</h5>
                        <p class="text-muted mb-0" style="font-size:14px;">Lihat pengumuman hasil seleksi PPDB</p>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center py-4 mt-5">
        <div class="container">
            <p class="mb-1" style="font-size:14px;">SMP Labschool UPI Kampus Cibiru</p>
            <small style="opacity:0.7;">© 2026 Hak Cipta Dilindungi</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/ppdb/index.blade.php ENDPATH**/ ?>