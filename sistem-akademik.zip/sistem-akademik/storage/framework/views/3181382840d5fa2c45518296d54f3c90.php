<?php $__env->startSection('page-title', 'Persetujuan Jadwal Mengajar'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Daftar Permohonan Persetujuan Jadwal</h5>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Hari</th>
                        <th>Jam Mengajar</th>
                        <th>Tahun Ajaran / Sem.</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $persetujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->jadwal->kelas->nama_kelas ?? '-'); ?></td>
                        <td><?php echo e($p->jadwal->mataPelajaran->kode_mapel ?? '-'); ?></td>
                        <td><?php echo e($p->jadwal->hari); ?></td>
                        <td><?php echo e($p->jadwal->jam_mulai); ?> - <?php echo e($p->jadwal->jam_selesai); ?></td>
                        <td><?php echo e($p->jadwal->tahun_ajaran); ?> (Smstr <?php echo e($p->jadwal->semester); ?>)</td>
                        <td>
                            <?php if($p->status == 'menunggu'): ?>
                                <span class="badge bg-warning text-dark">Menunggu Review</span>
                            <?php elseif($p->status == 'disetujui'): ?>
                                <span class="badge bg-success">Sudah Disetujui</span>
                            <?php elseif($p->status == 'ditolak'): ?>
                                <span class="badge bg-danger">Anda Tolak</span>
                                <?php if($p->catatan): ?>
                                    <small class="d-block text-muted">Ket: <?php echo e($p->catatan); ?></small>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($p->status == 'menunggu'): ?>
                                <form action="<?php echo e(route('guru.persetujuan-jadwal.proses', $p->id)); ?>" method="POST" class="d-inline"
                                    onsubmit="return confirm('Apakah Anda menyetujui jadwal mengajar ini?')">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="aksi" value="setuju">
                                    <button class="btn btn-success btn-sm" title="Setujui">
                                        <i class="bi bi-check-lg"></i> Setuju
                                    </button>
                                </form>

                                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalTolak<?php echo e($p->id); ?>">
                                    <i class="bi bi-x-lg"></i> Tolak
                                </button>

                                <div class="modal fade" id="modalTolak<?php echo e($p->id); ?>" data-bs-backdrop="static" tabindex="-1">
                                    <div class="modal-dialog">
                                        <form action="<?php echo e(route('guru.persetujuan.proses', $p->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="aksi" value="tolak">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Alasan Penolakan Jadwal</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="text-muted small">Berikan alasan mengapa jadwal ini ditolak (misal: bentrok dengan jam luar sekolah, dsb).</p>
                                                    <div class="mb-3">
                                                        <label class="form-label">Catatan / Alasan <span class="text-danger">*</span></label>
                                                        <textarea name="catatan" class="form-control" rows="3" required placeholder="Tulis alasan di sini..."></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-danger btn-sm">Kirim Penolakan</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <span class="text-muted small">- Tidak ada aksi -</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted">Belum ada permohonan persetujuan jadwal.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/persetujuan/index.blade.php ENDPATH**/ ?>