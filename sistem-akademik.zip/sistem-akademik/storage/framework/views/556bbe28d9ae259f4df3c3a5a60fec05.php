<?php $__env->startSection('page-title', 'Tambah Jadwal'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Tambah Jadwal Mata Pelajaran</h5>
        <a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('kurikulum.penjadwalan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Kelas <span class="text-danger">*</span></label>
                    <select name="kelas_id" id="kelasSelect" class="form-select" required>
                        <option value="">-- Pilih Kelas --</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelas_id') == $k->id ? 'selected' : ''); ?>>
                                <?php echo e($k->nama_kelas); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Mata Pelajaran <span class="text-danger">*</span></label>
                    <select name="mata_pelajaran_id" id="mapelSelect" class="form-select" required>
                        <option value="">-- Pilih Guru terlebih dahulu --</option>
                    </select>
                    <div id="infoKuota" class="mt-2" style="display:none;"></div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Guru <span class="text-danger">*</span></label>
                    <select name="guru_id" id="guruSelect" class="form-select" required>
                        <option value="">-- Pilih Guru --</option>
                        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($g->id); ?>" <?php echo e(old('guru_id') == $g->id ? 'selected' : ''); ?>>
                                <?php echo e($g->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Hari <span class="text-danger">*</span></label>
                    <select name="hari" class="form-select" required>
                        <option value="">-- Pilih Hari --</option>
                        <?php $__currentLoopData = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hari); ?>" <?php echo e(old('hari') == $hari ? 'selected' : ''); ?>>
                                <?php echo e($hari); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Jam Mulai <span class="text-danger">*</span></label>
                    <input type="time" name="jam_mulai" id="jamMulai" class="form-control"
                        value="<?php echo e(old('jam_mulai')); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Jam Selesai <span class="text-danger">*</span></label>
                    <input type="time" name="jam_selesai" id="jamSelesai" class="form-control"
                        value="<?php echo e(old('jam_selesai')); ?>" required>
                    <small class="text-muted">Durasi maksimal 4 jam per sesi. Total jam mingguan mengikuti alokasi waktu mata pelajaran yang dipilih.</small>
                    <div id="errorJam" class="text-danger mt-1" style="display:none;"></div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                    <input type="text" name="tahun_ajaran" id="tahunAjaran" class="form-control"
                        value="<?php echo e(old('tahun_ajaran', '2026/2027')); ?>" placeholder="2026/2027" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Semester <span class="text-danger">*</span></label>
                    <select name="semester" id="semesterSelect" class="form-select" required>
                        <option value="">-- Pilih Semester --</option>
                        <option value="1" <?php echo e(old('semester') == '1' ? 'selected' : ''); ?>>Semester 1</option>
                        <option value="2" <?php echo e(old('semester') == '2' ? 'selected' : ''); ?>>Semester 2</option>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
                <a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
<script>
document.getElementById('guruSelect').addEventListener('change', function() {
    const guruId = this.value;
    const mapelSelect = document.getElementById('mapelSelect');

    mapelSelect.innerHTML = '<option value="">Memuat...</option>';
    document.getElementById('infoKuota').style.display = 'none';

    if (!guruId) {
        mapelSelect.innerHTML = '<option value="">-- Pilih Guru terlebih dahulu --</option>';
        return;
    }

    fetch(`/kurikulum/penjadwalan/mapel-by-guru/${guruId}`)
        .then(res => res.json())
        .then(data => {
            mapelSelect.innerHTML = '';

            if (data.length === 0) {
                mapelSelect.innerHTML = '<option value="">Guru ini belum ditugaskan mata pelajaran</option>';
                return;
            }

            mapelSelect.innerHTML = '<option value="">-- Pilih Mata Pelajaran --</option>';
            data.forEach(m => {
                const selected = data.length === 1 ? 'selected' : '';
                mapelSelect.innerHTML += `<option value="${m.id}" ${selected}>${m.kode_mapel}</option>`;
            });

            cekSisaKuota();
        });
});

function cekSisaKuota() {
    const kelasId = document.getElementById('kelasSelect').value;
    const mapelId = document.getElementById('mapelSelect').value;
    const tahunAjaran = document.getElementById('tahunAjaran').value;
    const semester = document.getElementById('semesterSelect').value;
    const infoBox = document.getElementById('infoKuota');

    if (!kelasId || !mapelId || !tahunAjaran || !semester) {
        infoBox.style.display = 'none';
        return;
    }

    const params = new URLSearchParams({
        kelas_id: kelasId,
        mata_pelajaran_id: mapelId,
        tahun_ajaran: tahunAjaran,
        semester: semester,
    });

    fetch(`<?php echo e(route('kurikulum.penjadwalan.sisa_kuota')); ?>?${params}`)
        .then(res => res.json())
        .then(data => {
            const warna = data.sisa <= 0 ? 'alert-danger' : 'alert-info';
            infoBox.className = `alert ${warna} py-2 px-3 mb-0`;
            infoBox.innerHTML = `<strong>${data.nama_mapel}</strong>: alokasi ${data.alokasi} jam/minggu, sudah terpakai ${data.terpakai} jam, sisa ${data.sisa} jam.`;
            infoBox.style.display = 'block';
        });
}

document.getElementById('kelasSelect').addEventListener('change', cekSisaKuota);
document.getElementById('mapelSelect').addEventListener('change', cekSisaKuota);
document.getElementById('tahunAjaran').addEventListener('change', cekSisaKuota);
document.getElementById('semesterSelect').addEventListener('change', cekSisaKuota);

function validasiDurasiJam() {
    const jamMulai = document.getElementById('jamMulai').value;
    const jamSelesai = document.getElementById('jamSelesai').value;
    const errorBox = document.getElementById('errorJam');

    if (!jamMulai || !jamSelesai) {
        errorBox.style.display = 'none';
        return true;
    }

    const [h1, m1] = jamMulai.split(':').map(Number);
    const [h2, m2] = jamSelesai.split(':').map(Number);
    const menit1 = h1 * 60 + m1;
    const menit2 = h2 * 60 + m2;
    const selisihJam = (menit2 - menit1) / 60;

    if (selisihJam <= 0) {
        errorBox.textContent = 'Jam Selesai harus lebih besar dari Jam Mulai.';
        errorBox.style.display = 'block';
        return false;
    }

    if (selisihJam > 4) {
        errorBox.textContent = 'Durasi jadwal tidak boleh lebih dari 4 jam.';
        errorBox.style.display = 'block';
        return false;
    }

    errorBox.style.display = 'none';
    return true;
}

document.getElementById('jamMulai').addEventListener('change', validasiDurasiJam);
document.getElementById('jamSelesai').addEventListener('change', validasiDurasiJam);

document.querySelector('form').addEventListener('submit', function(e) {
    if (!validasiDurasiJam()) {
        e.preventDefault();
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/penjadwalan/create.blade.php ENDPATH**/ ?>