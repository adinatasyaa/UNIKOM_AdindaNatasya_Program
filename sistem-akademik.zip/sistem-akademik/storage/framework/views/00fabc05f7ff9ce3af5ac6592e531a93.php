<?php $__env->startSection('page-title', 'Jadwal Mengajar'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Jadwal Mengajar Saya</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Berikut adalah jadwal mengajar yang telah ditetapkan oleh Wakasek Kurikulum.
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Hari</th>
                        <th>Jam</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($j->kelas->nama_kelas ?? '-'); ?></td>
                        <td><?php echo e($j->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($j->hari); ?></td>
                        <td><?php echo e(date('H.i', strtotime($j->jam_mulai))); ?> - <?php echo e(date('H.i', strtotime($j->jam_selesai))); ?></td>
                        <td><?php echo e($j->tahun_ajaran); ?></td>
                        <td>Semester <?php echo e($j->semester); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada jadwal mengajar untuk Anda</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/jadwal_mengajar/index.blade.php ENDPATH**/ ?>