<?php $__env->startSection('page-title', 'Data SPMB'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kurikulum.dashboard')); ?>" class="nav-link">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="nav-link">
    <i class="bi bi-calendar-event me-2"></i> Penjadwalan
</a>
<a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="nav-link active">
    <i class="bi bi-person-plus me-2"></i> Data SPMB
</a>
<a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" class="nav-link">
    <i class="bi bi-clipboard-check me-2"></i> Data Seleksi
</a>
<a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" class="nav-link">
    <i class="bi bi-award me-2"></i> Data Hasil Seleksi
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Data Pendaftaran SPMB</h5>
    <div class="d-flex gap-2">
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#kuotaModal">
            <i class="bi bi-calendar-week me-1"></i> Kelola Kuota Tanggal
        </button>
    </div>
</div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                <tr>
                    <th class="text-nowrap">No</th>
                    <th class="text-nowrap">ID Pendaftaran</th>
                    <th class="text-nowrap">Nama Lengkap</th>
                    <th class="text-nowrap">Asal Sekolah</th>
                    <th class="text-nowrap">Orang Tua</th>
                    <th class="text-nowrap">No. Telp</th>
                    <th class="text-nowrap">Tanggal Tes</th>
                    <th class="text-nowrap">Ruangan</th>
                    <th class="text-nowrap">Status</th>
                    <th class="text-nowrap">Aksi</th>
                </tr>
                </thead>
                    </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $spmb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($spmb->firstItem() + $index); ?></td>
                        <td><?php echo e($s->id_pendaftaran ?? '-'); ?></td>
                        <td><?php echo e($s->nama_lengkap); ?></td>
                        <td><?php echo e($s->asal_sekolah); ?></td>
                        <td><?php echo e($s->nama_orang_tua); ?></td>
                        <td><?php echo e($s->no_kontak_orang_tua); ?></td>
                        <td><?php echo e($s->tanggal_tes ? \Carbon\Carbon::parse($s->tanggal_tes)->format('d/m/Y') : '-'); ?></td>
                        <td><?php echo e($s->ruangan ?? '-'); ?></td>
                        <td>
                            <?php if($s->status == 'pending'): ?>
                                <span class="badge bg-warning">Menunggu</span>
                            <?php elseif($s->status == 'diterima'): ?>
                                <span class="badge bg-success">Diterima</span>
                            <?php elseif($s->status == 'konfirmasi'): ?>
                                <span class="badge bg-info">Sudah Konfirmasi</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="d-flex gap-1 justify-content-center">
                                <a href="<?php echo e(route('kurikulum.spmb.show', $s->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <form action="<?php echo e(route('kurikulum.spmb.destroy', $s->id)); ?>" method="POST" class="d-inline"
                                    onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center text-muted">Belum ada data pendaftaran</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($spmb->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<div class="modal fade" id="kuotaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Atur Kuota Tanggal Tes</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('kurikulum.spmb.kuota.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
    <div class="mb-3">
    <label class="form-label">Tanggal Mulai</label>
    <input type="date" name="tanggal_mulai" id="tanggal_mulai_input" class="form-control"
        value="<?php echo e(old('tanggal_mulai', $kuotaTerakhir?->tanggal_mulai?->format('Y-m-d'))); ?>" required>
</div>
<div class="mb-3">
    <label class="form-label">Tanggal Akhir</label>
    <input type="date" name="tanggal_akhir" id="tanggal_akhir_input" class="form-control"
        value="<?php echo e(old('tanggal_akhir', $kuotaTerakhir?->tanggal_akhir?->format('Y-m-d'))); ?>" required>
</div>
    <div class="mb-3">
        <label class="form-label">Kuota Maksimal Siswa (per hari)</label>
        <input type="number" name="kuota_maks" class="form-control" min="1"
            value="<?php echo e(old('kuota_maks', $kuotaTerakhir?->kuota_maks)); ?>" placeholder="Contoh: 20" required>
    </div>
    <small class="text-muted">
        Kuota berlaku untuk setiap tanggal dalam rentang ini.
        Kalau rentang tanggal sudah pernah diatur sebelumnya, kuota akan diperbarui (bukan duplikat).
    </small>
</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> Simpan Kuota
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const tglMulaiInput = document.getElementById('tanggal_mulai_input');
    const tglAkhirInput = document.getElementById('tanggal_akhir_input');

    tglMulaiInput.addEventListener('change', function () {
        tglAkhirInput.min = this.value;
        if (tglAkhirInput.value && tglAkhirInput.value < this.value) {
            tglAkhirInput.value = this.value;
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/spmb/index.blade.php ENDPATH**/ ?>