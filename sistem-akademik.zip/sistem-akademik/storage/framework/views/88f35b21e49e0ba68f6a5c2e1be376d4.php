<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <link rel="icon" type="image/jpeg" href="<?php echo e(asset('logoSekolah.jpg')); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Sistem Akademik')); ?> — SMP Labschool UPI Kampus Cibiru</title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans text-gray-900 antialiased">
        <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">

            <div class="w-full sm:max-w-md mt-6 px-6 py-8 bg-white shadow-md overflow-hidden sm:rounded-lg">

                <div class="text-center mb-6">
                    <img src="<?php echo e(asset('logoSekolah.jpg')); ?>"
                        alt="Logo SMP Labschool"
                        style="width:110px;"
                        class="mx-auto mb-3">

                    <h1 class="text-lg font-semibold text-gray-800 leading-snug">
                        SMP Labschool UPI Kampus Cibiru
                    </h1>
                    <p class="text-sm text-gray-500 mt-1">Silakan login untuk melanjutkan</p>
                </div>

                <?php echo e($slot); ?>

            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/layouts/guest.blade.php ENDPATH**/ ?>