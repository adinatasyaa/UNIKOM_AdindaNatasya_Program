<?php $__env->startSection('page-title', 'Tambah Predikat'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">
        <h5 class="mb-0">Tambah Predikat</h5>
    </div>

    <div class="card-body">

        <form action="<?php echo e(route('operator.predikat.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="form-label">Predikat</label>
                <input type="text"
                       name="predikat"
                       class="form-control"
                       placeholder="A"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nilai Minimum</label>
                <input type="number"
                       name="nilai_min"
                       class="form-control"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nilai Maksimum</label>
                <input type="number"
                       name="nilai_max"
                       class="form-control"
                       required>
            </div>

           <div class="mb-3">
                <label class="form-label">Keterangan</label>
                <select name="keterangan" class="form-control form-select" required>
                    <option value="">-- Pilih Keterangan --</option>
                    <option value="Sangat Baik">Sangat Baik</option>
                    <option value="Baik">Baik</option>
                    <option value="Cukup">Cukup</option>
                    <option value="Perlu Bimbingan">Perlu Bimbingan</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                Simpan
            </button>

            <a href="<?php echo e(route('operator.predikat.index')); ?>"
               class="btn btn-secondary">
                Kembali
            </a>

        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/predikat/create.blade.php ENDPATH**/ ?>