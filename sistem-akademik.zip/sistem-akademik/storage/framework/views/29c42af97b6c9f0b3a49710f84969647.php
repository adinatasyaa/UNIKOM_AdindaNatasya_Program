<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .header-table td { border: none; vertical-align: middle; padding: 0; }
        .header-table .logo-cell { width: 70px; }
        .header-table .logo-cell img { width: 60px; height: auto; }
        .header-table .text-cell { text-align: center; }
        .header-table h3 { margin: 0; font-size: 16px; }
        .header-table p { margin: 2px 0 0 0; font-size: 12px; }
        hr { border: none; border-top: 2px solid #333; margin: 5px 0 15px 0; }
        table.data { width: 100%; border-collapse: collapse; }
        table.data th, table.data td { border: 1px solid #333; padding: 6px 8px; text-align: center; }
        table.data th { background: #eee; }
        table.data td.nama { text-align: left; }
        .info { margin-bottom: 10px; }
        .info td { border: none; padding: 2px 0; text-align: left; }
        .ttd { margin-top: 40px; }
    </style>
</head>
<body>
    <table class="header-table">
        <tr>
            <td class="logo-cell">
                <img src="data:image/jpeg;base64,<?php echo e($logoBase64); ?>">
            </td>
            <td class="text-cell">
                <h3>LAPORAN NILAI SISWA</h3>
                <p>SMP LABSCHOOL UPI KAMPUS CIBIRU</p>
            </td>
            <td class="logo-cell"></td>
        </tr>
    </table>
    <hr>

    <table class="info">
        <tr><td width="120">Mata Pelajaran</td><td>: <?php echo e($bobot->mataPelajaran->nama_mapel); ?></td></tr>
        <tr><td>Kelas</td><td>: <?php echo e($kelas->nama_kelas); ?></td></tr>
        <tr><td>Semester</td><td>: <?php echo e($bobot->semester); ?></td></tr>
        <tr><td>Tahun Ajaran</td><td>: <?php echo e($bobot->tahun_ajaran); ?></td></tr>
    </table>

    <table class="data">
        <thead>
            <tr>
                <th style="width: 4%;">No</th>
                <th style="width: 12%;">NIS</th>
                <th style="width: 22%;">Nama Siswa</th>
                <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($k->nama_komponen); ?> (<?php echo e($k->persentase); ?>%)</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th>Nilai Akhir</th>
                <th>Predikat</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($d['siswa']->nis); ?></td>
                <td class="nama"><?php echo e($d['siswa']->nama); ?></td>
                <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($d['nilai'][$k->id]); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($d['penilaian']->nilai_akhir ?? '-'); ?></td>
                <td><?php echo e($d['penilaian']->predikat ?? '-'); ?></td>
                <td><?php echo e($d['penilaian']->keterangan ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="ttd">
        <p>Bandung, <?php echo e(now()->translatedFormat('d F Y')); ?></p>
        <br><p><?php echo e(auth()->user()->name ?? 'Guru Mata Pelajaran'); ?></p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/penilaian/laporan_pdf.blade.php ENDPATH**/ ?>