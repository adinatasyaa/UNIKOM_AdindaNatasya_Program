<?php $__env->startSection('page-title', 'Absensi Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Rekap Absensi Kelas (Guru Mata Pelajaran)</h5>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Filter Kelas</label>
                <select class="form-select" onchange="window.location='?kelas_id='+this.value">
                    <option value="">-- Semua Kelas --</option>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>>
                            <?php echo e($k->nama_kelas); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kelas</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Jam Pelajaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($absensi->firstItem() + $index); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($a->tanggal)->format('d/m/Y')); ?></td>
                        <td><?php echo e($a->kelas->nama_kelas ?? '-'); ?></td>
                        <td><?php echo e($a->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($a->guru->nama ?? '-'); ?></td>
                        <td><?php echo e($a->jam_pelajaran); ?></td>
                        <td>
                            <a href="<?php echo e(route('wali_kelas.absensi.show', $a->id)); ?>" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data absensi</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($absensi->links('pagination::bootstrap-5')); ?>

    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Informasi Absensi dari Guru Piket</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Informasi keterlambatan, izin pulang, atau ketidakhadiran siswa yang dicatat oleh Guru Piket.
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $absensiPiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($p->tanggal)->format('d/m/Y')); ?></td>
                        <td><?php echo e($p->nama_siswa); ?></td>
                        <td><?php echo e($p->nama_kelas); ?></td>
                        <td>
                            <?php if($p->status == 'terlambat'): ?>
                                <span class="badge bg-warning">Terlambat</span>
                            <?php elseif($p->status == 'izin_pulang'): ?>
                                <span class="badge bg-info">Izin Pulang</span>
                            <?php elseif($p->status == 'izin'): ?>
                                <span class="badge bg-primary">Izin</span>
                            <?php elseif($p->status == 'tidak_hadir'): ?>
                                <span class="badge bg-danger">Tidak Hadir</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($p->keterangan ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada informasi dari Guru Piket</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/absensi/index.blade.php ENDPATH**/ ?>