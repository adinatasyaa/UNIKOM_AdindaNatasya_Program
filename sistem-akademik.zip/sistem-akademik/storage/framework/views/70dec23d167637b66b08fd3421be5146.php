<?php $__env->startSection('page-title', 'Edit Bobot Penilaian'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Bobot Penilaian</h5>
        <a href="<?php echo e(route('guru.bobot.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="alert alert-warning">
            <i class="bi bi-exclamation-triangle me-1"></i>
            Jika kamu mengubah komponen (nama/jumlah), nilai yang sudah diinput sebelumnya untuk komponen tersebut akan terhapus dan perlu diisi ulang.
        </div>

        <form action="<?php echo e(route('guru.bobot.update', $bobot->id)); ?>" method="POST" id="formBobot">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Mata Pelajaran <span class="text-danger">*</span></label>
                    <select name="mata_pelajaran_id" class="form-select" required>
                        <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>" <?php echo e(old('mata_pelajaran_id', $bobot->mata_pelajaran_id) == $m->id ? 'selected' : ''); ?>>
                                <?php echo e($m->nama_mapel); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                    <input type="text" name="tahun_ajaran" class="form-control"
                        value="<?php echo e(old('tahun_ajaran', $bobot->tahun_ajaran)); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Semester <span class="text-danger">*</span></label>
                    <select name="semester" class="form-select" required>
                        <option value="1" <?php echo e(old('semester', $bobot->semester) == '1' ? 'selected' : ''); ?>>Semester 1</option>
                        <option value="2" <?php echo e(old('semester', $bobot->semester) == '2' ? 'selected' : ''); ?>>Semester 2</option>
                    </select>
                </div>
            </div>

            <hr>
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold mb-0">Komponen Penilaian</h6>
                <button type="button" class="btn btn-outline-primary btn-sm" onclick="tambahKomponen()">
                    <i class="bi bi-plus-circle me-1"></i> Tambah Komponen
                </button>
            </div>

            <div id="komponenWrapper">
                <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row g-2 mb-2 komponen-row">
                    <div class="col-md-5">
                        <input type="text" name="komponen[<?php echo e($i); ?>][nama]" class="form-control" value="<?php echo e($k->nama_komponen); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <select name="komponen[<?php echo e($i); ?>][jenis]" class="form-select" required>
                            <option value="tugas" <?php echo e($k->jenis == 'tugas' ? 'selected' : ''); ?>>Tugas</option>
                            <option value="uts" <?php echo e($k->jenis == 'uts' ? 'selected' : ''); ?>>UTS</option>
                            <option value="uas" <?php echo e($k->jenis == 'uas' ? 'selected' : ''); ?>>UAS</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="number" name="komponen[<?php echo e($i); ?>][persentase]" class="form-control persentase-input" value="<?php echo e($k->persentase); ?>" min="1" max="100" required oninput="hitungTotal()">
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-danger btn-sm" onclick="hapusKomponen(this)">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="alert mt-3" id="totalAlert">
                Total Persentase: <strong id="totalPersentase"><?php echo e($bobot->komponen->sum('persentase')); ?></strong>%
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Update Bobot
                </button>
                <a href="<?php echo e(route('guru.bobot.index')); ?>" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>

<script>
let komponenIndex = <?php echo e($bobot->komponen->count()); ?>;

function tambahKomponen() {
    const wrapper = document.getElementById('komponenWrapper');
    const row = document.createElement('div');
    row.className = 'row g-2 mb-2 komponen-row';
    row.innerHTML = `
        <div class="col-md-5">
            <input type="text" name="komponen[${komponenIndex}][nama]" class="form-control" placeholder="Nama komponen" required>
        </div>
        <div class="col-md-3">
            <select name="komponen[${komponenIndex}][jenis]" class="form-select" required>
                <option value="tugas">Tugas</option>
                <option value="uts">UTS</option>
                <option value="uas">UAS</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="number" name="komponen[${komponenIndex}][persentase]" class="form-control persentase-input" placeholder="Persentase %" min="1" max="100" required oninput="hitungTotal()">
        </div>
        <div class="col-md-1">
            <button type="button" class="btn btn-danger btn-sm" onclick="hapusKomponen(this)">
                <i class="bi bi-trash"></i>
            </button>
        </div>
    `;
    wrapper.appendChild(row);
    komponenIndex++;
}

function hapusKomponen(btn) {
    btn.closest('.komponen-row').remove();
    hitungTotal();
}

function hitungTotal() {
    const inputs = document.querySelectorAll('.persentase-input');
    let total = 0;
    inputs.forEach(input => {
        total += parseInt(input.value) || 0;
    });
    document.getElementById('totalPersentase').textContent = total;

    const alertBox = document.getElementById('totalAlert');
    if (total === 100) {
        alertBox.className = 'alert alert-success mt-3';
    } else {
        alertBox.className = 'alert alert-warning mt-3';
    }
}

document.getElementById('formBobot').addEventListener('submit', function(e) {
    const inputs = document.querySelectorAll('.persentase-input');
    let total = 0;
    inputs.forEach(input => {
        total += parseInt(input.value) || 0;
    });
    if (total !== 100) {
        e.preventDefault();
        alert('Total persentase harus 100%! Saat ini: ' + total + '%');
    }
});

hitungTotal();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/bobot/edit.blade.php ENDPATH**/ ?>