<?php $__env->startSection('page-title', 'Detail Pembagian Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Daftar Siswa Kelas <?php echo e($pembagianKelas->kelas->nama_kelas); ?></h4>
        <a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <?php if(session('success')): ?> <div class="alert alert-success"><?php echo e(session('success')); ?></div> <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <?php if($pembagianKelas->jenis !== 'siswa_baru'): ?>
                        <th>Rata-Rata Nilai</th>
                        <th>Kategori</th>
                        <?php endif; ?>
                        <th class="text-center">Pindah Kelas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $nilai = $rataRataNilai[$ds->siswa_id] ?? null;
                        $kategori = '-';
                        $badgeClass = 'secondary';
                        if ($nilai !== null) {
                            if ($nilai >= 80) { $kategori = 'High'; $badgeClass = 'success'; }
                            elseif ($nilai >= 65) { $kategori = 'Medium'; $badgeClass = 'warning'; }
                            else { $kategori = 'Low'; $badgeClass = 'danger'; }
                        }
                    ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><strong><?php echo e($ds->siswa->nama); ?></strong></td>
                        <?php if($pembagianKelas->jenis !== 'siswa_baru'): ?>
                        <td><?php echo e($nilai ?? 'Belum ada nilai'); ?></td>
                        <td><span class="badge bg-<?php echo e($badgeClass); ?>"><?php echo e($kategori); ?></span></td>
                        <?php endif; ?>
                        <td>
                            <form action="<?php echo e(route('kesiswaan.pembagian.pindah', $ds->id)); ?>" method="POST" class="d-flex justify-content-center gap-2">
                                <?php echo csrf_field(); ?>
                                <select class="form-select form-select-sm" name="kelas_baru_id" style="max-width: 180px;" required>
                                    <option value="">-- Pindahkan Ke --</option>
                                    <?php $__currentLoopData = $kelasLain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kl->id); ?>">Kelas <?php echo e($kl->nama_kelas); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-warning">Pindah</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="<?php echo e($pembagianKelas->jenis !== 'siswa_baru' ? 5 : 3); ?>" class="text-center py-4">Belum ada siswa di kelas ini.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kesiswaan/pembagian/show.blade.php ENDPATH**/ ?>