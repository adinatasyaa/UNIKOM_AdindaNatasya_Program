<?php $__env->startSection('page-title', 'Absensi Siswa'); ?>

<?php $__env->startSection('content'); ?>

<div class="card mb-3">
    <div class="card-header">
        <h5 class="mb-0">Data Absensi Siswa</h5>
        <small class="text-muted">Absensi siswa berdasarkan kelas.</small>
    </div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('kepala_sekolah.absensi.index')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <label class="form-label">Pilih Kelas</label>
                    <select name="kelas_id" class="form-select">
                        <option value="">-- Pilih Kelas --</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"
                                <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>>
                                <?php echo e($k->nama_kelas); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button class="btn btn-primary">Tampilkan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if(request('kelas_id')): ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Daftar Absensi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->siswa->nama ?? '-'); ?></td>
                        <td><?php echo e($item->absensi->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($item->absensi->guru->nama ?? '-'); ?></td>
                        <td><?php echo e($item->absensi->tanggal); ?></td>
                        <td>
                            <?php if($item->status_kehadiran == 'Hadir'): ?>
                                <span class="badge bg-success">Hadir</span>
                            <?php elseif($item->status_kehadiran == 'Izin'): ?>
                                <span class="badge bg-info">Izin</span>
                            <?php elseif($item->status_kehadiran == 'Sakit'): ?>
                                <span class="badge bg-warning text-dark">Sakit</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Alpa</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">Tidak ada data absensi.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kepala_sekolah/absensi/index.blade.php ENDPATH**/ ?>