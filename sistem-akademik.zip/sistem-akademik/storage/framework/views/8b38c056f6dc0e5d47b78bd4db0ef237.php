

<?php $__env->startSection('page-title', 'Absensi'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h4>Riwayat Absensi</h4>
            <p class="text-muted">
                Riwayat kehadiran siswa pada setiap mata pelajaran.
            </p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>


            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">

        <div class="card-header">
            <strong>Data Absensi</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Tanggal</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Status Kehadiran</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->absensi?->tanggal ?? '-'); ?></td>
                        <td><?php echo e($item->absensi?->mataPelajaran?->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($item->absensi?->guru?->nama ?? '-'); ?></td>
                        <td>
                           <?php if($item->status_kehadiran == 'Hadir'): ?>
                                <span class="badge bg-success">Hadir</span>
                           <?php elseif($item->status_kehadiran == 'Izin'): ?>
                                <span class="badge bg-info">Izin</span>
                           <?php elseif($item->status_kehadiran == 'Sakit'): ?>
                                <span class="badge bg-warning text-dark">Sakit</span>
                           <?php else: ?>
                                <span class="badge bg-danger">Alpa</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->keterangan ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="6"
                            class="text-center py-4 text-muted">
                            Belum ada data absensi.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/siswa/absensi/index.blade.php ENDPATH**/ ?>