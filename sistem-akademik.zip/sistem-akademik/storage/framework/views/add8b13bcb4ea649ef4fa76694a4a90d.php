<?php $__env->startSection('page-title', 'Pembagian Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="card shadow-sm mx-auto" style="max-width: 600px;">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Proses Pembagian Kelas Baru</h5>
        </div>
        <div class="card-body">
            <?php if(session('error')): ?> <div class="alert alert-danger"><?php echo e(session('error')); ?></div> <?php endif; ?>
            <form action="<?php echo e(route('kesiswaan.pembagian.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label class="form-label fw-bold">Jenis Pembagian</label>
                    <select class="form-select" name="jenis" id="jenisPembagian" required>
                        <option value="siswa_baru">Siswa Baru (Kelas 7) — Pembagian Rata</option>
                        <option value="kenaikan_kelas">Kenaikan Kelas (7→8, 8→9) — Berdasarkan Nilai</option>
                    </select>
                    <div class="mb-3" id="tingkatAsalWrapper" style="display:none;">
                        <label class="form-label fw-bold">Tingkat Asal (siswa yang akan naik)</label>
                        <select class="form-select" name="tingkat_asal">
                            <option value="7">Kelas 7 → akan naik ke Kelas 8</option>
                            <option value="8">Kelas 8 → akan naik ke Kelas 9</option>
                        </select>
                    </div>
                    <small class="text-muted" id="jenisHint">
                        Hanya siswa yang belum punya kelas (kelas_id kosong) yang akan dibagi.
                    </small>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Tahun Ajaran</label>
                    <input type="text" class="form-control" name="tahun_ajaran" placeholder="Contoh: 2025/2026" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Semester</label>
                    <select class="form-select" name="semester" required>
                        <option value="1">Semester 1 (Ganjil)</option>
                        <option value="2">Semester 2 (Genap)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Jumlah Kelas</label>
                    <select class="form-select" name="jumlah_kelas" id="jumlahKelas" required>
                        <option value="">-- Pilih Jumlah Kelas --</option>
                        <option value="1">1 Kelas</option>
                        <option value="2">2 Kelas</option>
                        <option value="3">3 Kelas</option>
                        <option value="4">4 Kelas</option>
                        <option value="5">5 Kelas</option>
                        <option value="6">6 Kelas</option>
                        <option value="7">7 Kelas</option>
                    </select>
                    <small class="text-muted">Nama kelas (misal VII A, VII B) akan dibuat otomatis sesuai jumlah ini.</small>
                </div>

                <div class="mb-3" id="waliKelasWrapper"></div>

                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" class="btn btn-secondary w-50">Batal</a>
                    <button type="submit" class="btn btn-primary w-50">Generate Otomatis</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const daftarGuru = <?php echo json_encode($daftarGuru->map(fn($g) => ['id' => $g->id, 'nama' => $g->nama]), 512) ?>;

document.getElementById('jenisPembagian').addEventListener('change', function() {
    const hint = document.getElementById('jenisHint');
    const tingkatWrapper = document.getElementById('tingkatAsalWrapper');

    if (this.value === 'kenaikan_kelas') {
        hint.textContent = 'Siswa akan diurutkan berdasarkan rata-rata nilai akhir, lalu dibagi rata ke setiap kelas berdasarkan kategori Tinggi/Sedang/Rendah agar setiap kelas seimbang.';
        tingkatWrapper.style.display = 'block';
    } else {
        hint.textContent = 'Siswa akan dibagi rata ke setiap kelas tanpa mempertimbangkan nilai (karena belum ada nilai untuk siswa baru).';
        tingkatWrapper.style.display = 'none';
    }
});

document.getElementById('jumlahKelas').addEventListener('change', function() {
    const wrapper = document.getElementById('waliKelasWrapper');
    const jumlah = parseInt(this.value) || 0;
    wrapper.innerHTML = '';

    if (jumlah === 0) return;

    let optionsHtml = '<option value="">-- Pilih Wali Kelas --</option>';
    daftarGuru.forEach(g => {
        optionsHtml += `<option value="${g.id}">${g.nama}</option>`;
    });

    let html = '<label class="form-label fw-bold">Wali Kelas per Kelas</label>';
    for (let i = 0; i < jumlah; i++) {
        html += `
            <div class="mb-2">
                <small class="text-muted">Kelas ke-${i + 1}</small>
                <select class="form-select" name="wali_kelas_ids[]">${optionsHtml}</select>
            </div>
        `;
    }
    wrapper.innerHTML = html;
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kesiswaan/pembagian/create.blade.php ENDPATH**/ ?>