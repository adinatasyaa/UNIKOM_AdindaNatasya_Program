

<?php $__env->startSection('page-title', 'Kelola Mata Pelajaran'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kurikulum.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.dashboard') ? 'active' : ''); ?>">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.spmb.index', 'kurikulum.spmb.show') ? 'active' : ''); ?>">
    <i class="bi bi-person-plus me-2"></i> Data SPMB
</a>
<a href="<?php echo e(route('kurikulum.mapel.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.mapel.*') ? 'active' : ''); ?>">
    <i class="bi bi-book me-2"></i> Kelola Mata Pelajaran
</a>
<a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.penjadwalan.*') ? 'active' : ''); ?>">
    <i class="bi bi-calendar-event me-2"></i> Penjadwalan
</a>
<a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.spmb.data_seleksi', 'kurikulum.spmb.data_seleksi.*') ? 'active' : ''); ?>">
    <i class="bi bi-clipboard-check me-2"></i> Data Seleksi
</a>
<a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" class="nav-link <?php echo e(request()->routeIs('kurikulum.spmb.hasil_seleksi', 'kurikulum.spmb.hasil_seleksi.*') ? 'active' : ''); ?>">
    <i class="bi bi-award me-2"></i> Data Hasil Seleksi
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Kelola Alokasi Waktu Mata Pelajaran</h5>
        <small class="text-muted">Atur jam pelajaran per minggu untuk tiap mapel sebelum membuat jadwal.</small>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama Mata Pelajaran</th>
                    <th>Guru Pengampu</th>
                    <th>Alokasi Waktu (jam/minggu)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($mapel->firstItem() + $index); ?></td>
                    <td><?php echo e($m->kode_mapel); ?></td>
                    <td><?php echo e($m->nama_mapel); ?></td>
                    <td><?php echo e($m->guru->nama ?? '-'); ?></td>
                    <td>
                        <form action="<?php echo e(route('kurikulum.mapel.update_alokasi', $m->id)); ?>" method="POST" class="d-flex gap-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="number" name="alokasi_waktu" class="form-control form-control-sm" style="width: 90px;" min="1" max="40" value="<?php echo e($m->alokasi_waktu); ?>" required>
                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-muted">Belum ada data mata pelajaran</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($mapel->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/mapel/index.blade.php ENDPATH**/ ?>