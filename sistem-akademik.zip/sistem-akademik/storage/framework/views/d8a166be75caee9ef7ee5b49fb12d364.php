<?php $__env->startSection('page-title', 'Detail PPDB'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kurikulum.dashboard')); ?>" class="nav-link">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('kurikulum.ppdb.index')); ?>" class="nav-link active">
    <i class="bi bi-person-plus me-2"></i> Data PPDB
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Pendaftaran</h5>
        <a href="<?php echo e(route('kurikulum.ppdb.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <h6 class="fw-bold text-primary">Data Siswa</h6>
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Nama Lengkap</td>
                        <td><strong><?php echo e($ppdb->nama_lengkap); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?php echo e($ppdb->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                    </tr>
                    <tr>
                        <td>Tempat Lahir</td>
                        <td><?php echo e($ppdb->tempat_lahir); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td><?php echo e(\Carbon\Carbon::parse($ppdb->tanggal_lahir)->format('d/m/Y')); ?></td>
                    </tr>
                    <tr>
                        <td>Asal Sekolah</td>
                        <td><?php echo e($ppdb->asal_sekolah); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo e($ppdb->alamat); ?></td>
                    </tr>
                </table>

                <h6 class="fw-bold text-primary mt-3">Data Orang Tua</h6>
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Nama Orang Tua</td>
                        <td><?php echo e($ppdb->nama_orang_tua); ?></td>
                    </tr>
                    <tr>
                        <td>No. Telepon</td>
                        <td><?php echo e($ppdb->no_telp_orang_tua); ?></td>
                    </tr>
                </table>
            </div>

            <div class="col-md-6">
                <h6 class="fw-bold text-primary">Berkas</h6>
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Rapor SD</td>
                        <td>
                            <?php if($ppdb->berkas_rapor): ?>
                                <a href="<?php echo e(asset('uploads/ppdb/' . $ppdb->berkas_rapor)); ?>" target="_blank" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye me-1"></i> Lihat
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Belum diupload</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Kartu Keluarga</td>
                        <td>
                            <?php if($ppdb->berkas_kk): ?>
                                <a href="<?php echo e(asset('uploads/ppdb/' . $ppdb->berkas_kk)); ?>" target="_blank" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye me-1"></i> Lihat
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Belum diupload</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Akta Kelahiran</td>
                        <td>
                            <?php if($ppdb->berkas_akta): ?>
                                <a href="<?php echo e(asset('uploads/ppdb/' . $ppdb->berkas_akta)); ?>" target="_blank" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye me-1"></i> Lihat
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Belum diupload</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>

                <h6 class="fw-bold text-primary mt-3">Status Pendaftaran</h6>
                <form action="<?php echo e(route('kurikulum.ppdb.update', $ppdb->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" required>
                            <option value="pending" <?php echo e($ppdb->status == 'pending' ? 'selected' : ''); ?>>Menunggu</option>
                            <option value="diterima" <?php echo e($ppdb->status == 'diterima' ? 'selected' : ''); ?>>Diterima</option>
                            <option value="ditolak" <?php echo e($ppdb->status == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tanggal Tes</label>
                        <input type="date" name="tanggal_tes" class="form-control"
                            value="<?php echo e($ppdb->tanggal_tes); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Keterangan</label>
                        <textarea name="keterangan" class="form-control" rows="3"><?php echo e($ppdb->keterangan); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-save me-1"></i> Simpan Perubahan
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/ppdb/show.blade.php ENDPATH**/ ?>