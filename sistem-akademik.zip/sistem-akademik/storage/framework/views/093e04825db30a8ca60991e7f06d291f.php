<?php $__env->startSection('page-title', 'Dashboard Operator'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('operator.dashboard')); ?>" class="nav-link active">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('operator.siswa.index')); ?>" class="nav-link">
    <i class="bi bi-people me-2"></i> Data Siswa
</a>
<a href="<?php echo e(route('operator.guru.index')); ?>" class="nav-link">
    <i class="bi bi-person-badge me-2"></i> Data Guru
</a>
<a href="<?php echo e(route('operator.kelas.index')); ?>" class="nav-link">
    <i class="bi bi-door-open me-2"></i> Data Kelas
</a>
<a href="<?php echo e(route('operator.mapel.index')); ?>" class="nav-link">
    <i class="bi bi-book me-2"></i> Mata Pelajaran
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted"> SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-4">
        <a href="<?php echo e(route('operator.siswa.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Data Siswa</h5>
                            <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Siswa::count()); ?></p>
                        </div>
                        <i class="bi bi-people fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?php echo e(route('operator.guru.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-success h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Data Guru</h5>
                            <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Guru::count()); ?></p>
                        </div>
                        <i class="bi bi-person-badge fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?php echo e(route('operator.kelas.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-secondary h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Data Kelas</h5>
                            <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Kelas::count()); ?></p>
                        </div>
                        <i class="bi bi-door-open fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?php echo e(route('operator.mapel.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-info h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title"> Data Mata Pelajaran</h5>
                            <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\MataPelajaran::count()); ?></p>
                        </div>
                        <i class="bi bi-book fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>
   <div class="col-md-4">
    <a href="<?php echo e(route('operator.predikat.index')); ?>" class="text-decoration-none">
        <div class="card text-white bg-warning h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Setting Predikat</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Predikat::count()); ?></p>
                    </div>
                    <i class="bi bi-gear fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </a>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/dashboard.blade.php ENDPATH**/ ?>