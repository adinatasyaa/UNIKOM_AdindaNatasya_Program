

<?php $__env->startSection('page-title', 'Dashboard Kepala Sekolah'); ?>

<?php $__env->startSection('sidebar'); ?>

<a href="<?php echo e(route('kepala_sekolah.dashboard')); ?>" class="nav-link active">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>

<a href="<?php echo e(route('kepala_sekolah.jadwal.index')); ?>" class="nav-link">
    <i class="bi bi-calendar3 me-2"></i> Jadwal Mata Pelajaran
</a>

<a href="<?php echo e(route('kepala_sekolah.pembagian-guru-piket.index')); ?>" class="nav-link">
    <i class="bi bi-person-check me-2"></i> Pembagian Guru Piket
</a>

<a href="<?php echo e(route('kepala_sekolah.pembagian-kelas.index')); ?>" class="nav-link">
    <i class="bi bi-diagram-3 me-2"></i> Pembagian Kelas
</a>

<a href="<?php echo e(route('kepala_sekolah.absensi.index')); ?>" class="nav-link">
    <i class="bi bi-clipboard-check me-2"></i>Absensi
</a>

<a href="<?php echo e(route('kepala_sekolah.penilaian.index')); ?>" class="nav-link">
    <i class="bi bi-clipboard-data me-2"></i>Penilaian
</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row mb-4">
    <div class="col-12">
        <h4>Selamat Datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted">
            SMP Labschool UPI Kampus Cibiru
        </p>
    </div>
</div>


<div class="row g-3">
    <div class="col-md-4 mb-3">
        <a href="<?php echo e(route('kepala_sekolah.jadwal.index')); ?>" class="text-decoration-none">
            <div class="card bg-warning text-white h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Jadwal Menunggu</h5>
                           <h5 class="mb-0"><?php echo e(\App\Models\PenjadwalanMataPelajaran::where('status', 'menunggu_persetujuan')->count()); ?></h5>
                        </div>
                        <i class="bi bi-calendar-check fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4 mb-3">
        <a href="<?php echo e(route('kepala_sekolah.jadwal.index')); ?>" class="text-decoration-none">
            <div class="card bg-info text-white h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Jadwal Disetujui</h5>
                            <h5 class="mb-0"><?php echo e(\App\Models\PenjadwalanMataPelajaran::where('status', 'disetujui')->count()); ?></h5>
                        </div>
                        <i class="bi bi-check-circle fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4 mb-3">
        <a href="<?php echo e(route('kepala_sekolah.pembagian-kelas.index')); ?>" class="text-decoration-none">
            <div class="card bg-primary text-white h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Pembagian Kelas</h5>
                            <h5 class="mb-0"><?php echo e(\App\Models\PembagianKelas::count()); ?></h5>
                        </div>
                        <i class="bi bi-diagram-3 fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4 mb-3">
        <a href="<?php echo e(route('kepala_sekolah.pembagian-guru-piket.index')); ?>" class="text-decoration-none">
            <div class="card bg-success text-white h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Pembagian Guru Piket</h5>
                            <h5 class="mb-0"><?php echo e(\App\Models\PembagianGuruPiket::count()); ?></h5>

                        </div>
                        <i class="bi bi-person-check fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

<div class="col-md-4 mb-3">
        <a href="<?php echo e(route('kepala_sekolah.absensi.index')); ?>" class="text-decoration-none">
            <div class="card bg-danger text-white h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Absensi Siswa</h5>
                             <p class="mb-0">Lihat Detail</p>  

                        </div>
                        <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

<div class="col-md-4 mb-3">
        <a href="<?php echo e(route('kepala_sekolah.penilaian.index')); ?>" class="text-decoration-none">
            <div class="card bg-secondary text-white h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Penilaian Siswa</h5>
                             <p class="mb-0">Lihat Detail</p>

                        </div>
                        <i class="bi bi-clipboard-data fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kepala_sekolah/dashboard.blade.php ENDPATH**/ ?>