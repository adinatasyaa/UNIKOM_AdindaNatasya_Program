<?php $__env->startSection('page-title', 'Detail Bobot Penilaian'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Bobot Penilaian</h5>
        <a href="<?php echo e(route('guru.bobot.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <table class="table table-bordered mb-4">
            <tr>
                <td width="30%">Mata Pelajaran</td>
                <td><strong><?php echo e($bobot->mataPelajaran->nama_mapel ?? '-'); ?></strong></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td>
                    <?php $__empty_1 = true; $__currentLoopData = $bobot->daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo e($namaKelas); ?><?php echo e(!$loop->last ? ', ' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td><?php echo e($bobot->tahun_ajaran); ?></td>
            </tr>
            <tr>
                <td>Semester</td>
                <td>Semester <?php echo e($bobot->semester); ?></td>
            </tr>
        </table>
    </div>
        <h6 class="fw-bold mb-3">Komponen Penilaian</h6>
        <table class="table table-bordered">

            <thead style="font-weight:600;">
                <tr>
                    <th style="width:60px;">No</th>
                    <th>Nama Komponen</th>
                    <th>Jenis</th>
                    <th>Persentase</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bobot->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($k->nama_komponen); ?></td>
                    <td><span class="badge bg-secondary"><?php echo e(ucfirst($k->jenis)); ?></span></td>
                    <td><?php echo e($k->persentase); ?>%</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr class="fw-bold">
                    <td colspan="3" class="text-end">Total</td>
                    <td><?php echo e($bobot->komponen->sum('persentase')); ?>%</td>
                </tr>
            </tfoot>
        </table>

        <h6 class="fw-bold mb-3 mt-4">Tabel Nilai Siswa</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="font-weight:600;">
                    <tr>
                        <th style="width:60px;">No</th>
                        <th>Kelas</th>
                        <th>Nama Siswa</th>
                        <th>Nilai Akhir</th>
                        <th>Predikat</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $daftarNilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($nilai->kelas->nama_kelas ?? '-'); ?></td>
                        <td><?php echo e($nilai->siswa->nama ?? '-'); ?></td>
                        <td><?php echo e($nilai->nilai_akhir ?? '-'); ?></td>
                        <td>
                            <?php if($nilai->predikat): ?>
                                <span class="badge bg-info text-dark"><?php echo e($nilai->predikat); ?></span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($nilai->status == 'final'): ?>
                                <span class="badge bg-success">Final</span>
                            <?php elseif($nilai->status == 'lengkap'): ?>
                                <span class="badge bg-primary">Lengkap</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Belum Lengkap</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada nilai siswa yang diinput untuk mata pelajaran ini.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="<?php echo e(route('guru.penilaian.pilih_kelas', $bobot->id)); ?>" class="btn btn-success">
            
        <a href="<?php echo e(route('guru.penilaian.pilih_kelas', $bobot->id)); ?>" class="btn btn-success">
            <i class="bi bi-pencil-square me-1"></i> Input Nilai Siswa
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/bobot/show.blade.php ENDPATH**/ ?>