<?php $__env->startSection('page-title', 'Detail Nilai Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Nilai — <?php echo e($siswa->nama); ?></h5>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('wali_kelas.penilaian.show', $kelas->id)); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
        <a href="<?php echo e(route('wali_kelas.penilaian.unduh', [$kelas->id, $siswa->id])); ?>" class="btn btn-success btn-sm">
            <i class="bi bi-download me-1"></i> Unduh Rapor
        </a>
    </div>
</div>
    <div class="card-body">
        <table class="table table-bordered mb-4">
            <tr>
                <td width="30%">NIS</td>
                <td><?php echo e($siswa->nis); ?></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><strong><?php echo e($siswa->nama); ?></strong></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td><?php echo e($kelas->nama_kelas); ?></td>
            </tr>
        </table>

        <h6 class="fw-bold mb-3">Daftar Nilai per Mata Pelajaran</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="font-weight:600;">
                    <tr>
                        <th>No</th>
                        <th>Mata Pelajaran</th>
                        <th>Nilai Akhir</th>
                        <th>Predikat</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="<?php echo e($p->status == 'belum_lengkap' ? 'background-color:#f8d7da;' : ''); ?>">
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($p->nilai_akhir ?? '-'); ?></td>
                        <td>
                            <?php if($p->predikat): ?>
                                <div class="d-flex flex-column align-items-center gap-1">
                                    <span class="badge bg-primary"><?php echo e($p->predikat); ?></span>
                                    <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                    <?php echo e($p->keterangan); ?>

                                    </span>
                                </div>
                            <?php else: ?>
                              -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($p->status == 'final'): ?>
                                <span class="badge bg-success">Final</span>
                            <?php elseif($p->status == 'lengkap'): ?>
                                <span class="badge bg-info">Lengkap</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Belum Lengkap</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Belum ada data nilai untuk siswa ini</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/penilaian/detail.blade.php ENDPATH**/ ?>