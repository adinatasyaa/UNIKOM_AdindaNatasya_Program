<?php $__env->startSection('page-title', 'Penilaian Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="mb-0">Setting Bobot Penilaian</h5>
        <div class="d-flex gap-2 flex-wrap align-items-center">
            <form action="<?php echo e(route('guru.bobot.recalculate')); ?>" method="POST"
                onsubmit="return confirm('Hitung ulang predikat semua siswa berdasarkan setting predikat terbaru?')">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-warning btn-sm">
                    <i class="bi bi-arrow-repeat me-1"></i> Update Predikat
                </button>
            </form>
            <?php if($bobot->count() > 0): ?>
            <a href="<?php echo e(route('guru.penilaian.pilih_kelas.default')); ?>" class="btn btn-success btn-sm">
                <i class="bi bi-pencil-square me-1"></i> Input Nilai
            </a>
            <?php endif; ?>
            <a href="<?php echo e(route('guru.bobot.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Buat Bobot Baru
            </a>
        </div>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th>No</th>
                        <th>Mata Pelajaran</th>
                        <th>Kelas</th>
                        <th>Komponen</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bobot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($b->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $b->daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <?php echo e($namaKelas); ?><?php echo e(!$loop->last ? ', ' : ''); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = $b->komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-secondary"><?php echo e($k->nama_komponen); ?> (<?php echo e($k->persentase); ?>%)</span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($b->tahun_ajaran); ?></td>
                        <td>Semester <?php echo e($b->semester); ?></td>
                        <td>
                            <a href="<?php echo e(route('guru.bobot.edit', $b->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <a href="<?php echo e(route('guru.bobot.show', $b->id)); ?>" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                            <form action="<?php echo e(route('guru.bobot.destroy', $b->id)); ?>" method="POST" class="d-inline"
                                onsubmit="return confirm('Yakin ingin menghapus bobot ini? Data nilai terkait juga akan terhapus!')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada bobot penilaian dibuat</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.getElementById('formInputNilai')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const bobotId = document.getElementById('pilihBobotNilai').value;
    if (!bobotId) return;

    const url = "<?php echo e(route('guru.penilaian.pilih_kelas', ':id')); ?>".replace(':id', bobotId);
    window.location.href = url;
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/bobot/index.blade.php ENDPATH**/ ?>