<?php $__env->startSection('page-title', 'Edit Predikat'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">
        <h5 class="mb-0">Edit Predikat</h5>
    </div>

    <div class="card-body">

        <form action="<?php echo e(route('operator.predikat.update', $predikat->id)); ?>"
              method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label class="form-label">Predikat</label>
                <input type="text"
                       name="predikat"
                       class="form-control"
                       value="<?php echo e($predikat->predikat); ?>"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nilai Minimum</label>
                <input type="number"
                       name="nilai_min"
                       class="form-control"
                       value="<?php echo e($predikat->nilai_min); ?>"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nilai Maksimum</label>
                <input type="number"
                       name="nilai_max"
                       class="form-control"
                       value="<?php echo e($predikat->nilai_max); ?>"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Keterangan</label>
                <select name="keterangan" class="form-control form-select" required>
                    <option value="Sangat Baik" <?php echo e($predikat->keterangan == 'Sangat Baik' ? 'selected' : ''); ?>>Sangat Baik</option>
                    <option value="Baik" <?php echo e($predikat->keterangan == 'Baik' ? 'selected' : ''); ?>>Baik</option>
                    <option value="Cukup" <?php echo e($predikat->keterangan == 'Cukup' ? 'selected' : ''); ?>>Cukup</option>
                    <option value="Perlu Bimbingan" <?php echo e($predikat->keterangan == 'Perlu Bimbingan' ? 'selected' : ''); ?>>Perlu Bimbingan</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                Update
            </button>

            <a href="<?php echo e(route('operator.predikat.index')); ?>"
               class="btn btn-secondary">
                Kembali
            </a>

        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/predikat/edit.blade.php ENDPATH**/ ?>