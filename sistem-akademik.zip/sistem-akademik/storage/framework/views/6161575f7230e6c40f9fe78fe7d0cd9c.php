

<?php $__env->startSection('page-title', 'Dashboard Siswa'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('siswa.dashboard')); ?>" class="nav-link">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>

<a href="<?php echo e(route('siswa.pembagian-kelas.index')); ?>" class="nav-link">
    <i class="bi bi-diagram-3 me-2"></i> Pembagian Kelas
</a>

<a href="<?php echo e(route('siswa.jadwal.index')); ?>" class="nav-link">
    <i class="bi bi-calendar3 me-2"></i> Jadwal Pelajaran
</a>

<a href="<?php echo e(route('siswa.absensi.index')); ?>" class="nav-link">
    <i class="bi bi-clipboard-check me-2"></i> Absensi
</a>

<a href="<?php echo e(route('siswa.penilaian.index')); ?>" class="nav-link">
    <i class="bi bi-journal-text me-2"></i> Penilaian
</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted">SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-3">

    <div class="col-md-3">
        <a href="<?php echo e(route('siswa.pembagian-kelas.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5>Pembagian Kelas</h5>
                         <p class="mb-0">Kelas</p>
                    </div>
                    <i class="bi bi-diagram-3 fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-3">
        <a href="<?php echo e(route('siswa.jadwal.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-success shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5>Jadwal Pelajaran</h5>
                         <p class="mb-0">Jadwal</p>
                    </div>
                    <i class="bi bi-calendar-event fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-3">
        <a href="<?php echo e(route('siswa.absensi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-warning shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5>Absensi</h5>
                         <p class="mb-0">Riwayat Kehadiran</p>
                    </div>
                    <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-3">
        <a href="<?php echo e(route('siswa.penilaian.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-danger shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5>Penilaian</h5>
                         <p class="mb-0">Nilai Mata Pelajaran</p>
                    </div>
                    <i class="bi bi-journal-text fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>