<?php $__env->startSection('page-title', 'Input Absensi Piket'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Input Absensi Piket</h5>
        <a href="<?php echo e(route('guru_piket.absensi.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('guru_piket.absensi.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Siswa <span class="text-danger">*</span></label>
                    <input type="text" name="nama_siswa" class="form-control"
                        value="<?php echo e(old('nama_siswa')); ?>" placeholder="Ketik nama siswa" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Kelas <span class="text-danger">*</span></label>
                    <input type="text" name="nama_kelas" class="form-control"
                        value="<?php echo e(old('nama_kelas')); ?>" placeholder="Contoh: 7A, 8B, 9C" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tanggal <span class="text-danger">*</span></label>
                    <input type="date" name="tanggal" class="form-control"
                        value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status <span class="text-danger">*</span></label>
                    <select name="status" class="form-select" required>
                        <option value="">-- Pilih Status --</option>
                        <option value="terlambat" <?php echo e(old('status') == 'terlambat' ? 'selected' : ''); ?>>Terlambat</option>
                        <option value="izin_pulang" <?php echo e(old('status') == 'izin_pulang' ? 'selected' : ''); ?>>Izin Pulang</option>
                        <option value="tidak_hadir" <?php echo e(old('status') == 'tidak_hadir' ? 'selected' : ''); ?>>Tidak Hadir</option>
                        <option value="izin" <?php echo e(old('status') == 'izin' ? 'selected' : ''); ?>>Izin</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Semester <span class="text-danger">*</span></label>
                    <select name="semester" class="form-select" required>
                        <option value="">-- Pilih Semester --</option>
                        <option value="1" <?php echo e(old('semester') == '1' ? 'selected' : ''); ?>>Semester 1</option>
                        <option value="2" <?php echo e(old('semester') == '2' ? 'selected' : ''); ?>>Semester 2</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tahun Ajaran <span class="text-danger">*</span></label>
                    <input type="text" name="tahun_ajaran" class="form-control"
                        value="<?php echo e(old('tahun_ajaran', '2026/2027')); ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="3"
                        placeholder="Isi keterangan alasan..."><?php echo e(old('keterangan')); ?></textarea>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
                <a href="<?php echo e(route('guru_piket.absensi.index')); ?>" class="btn btn-secondary ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru_piket/absensi/create.blade.php ENDPATH**/ ?>