

<?php $__env->startSection('page-title', 'Data Hasil Seleksi'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kurikulum.dashboard')); ?>" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
<a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="nav-link"><i class="bi bi-person-plus me-2"></i> Data SPMB</a>
<a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" class="nav-link"><i class="bi bi-clipboard-check me-2"></i> Data Seleksi</a>
<a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" class="nav-link active"><i class="bi bi-award me-2"></i> Data Hasil Seleksi</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Data Hasil Seleksi</h5>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID Pendaftaran</th>
                    <th>Nama Siswa</th>
                    <th>Hasil Tes</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $spmb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($s->id_pendaftaran); ?></td>
                    <td><?php echo e($s->nama_lengkap); ?></td>
                    <td>
                        <form action="<?php echo e(route('kurikulum.spmb.hasil_seleksi.update', $s->id)); ?>" method="POST" class="d-flex gap-2">
                            <?php echo csrf_field(); ?>
                            <select name="hasil_seleksi" class="form-select form-select-sm" style="width: 160px;">
                                <option value="menunggu" <?php echo e($s->hasil_seleksi == 'menunggu' ? 'selected' : ''); ?> disabled>Menunggu</option>
                                <option value="lulus" <?php echo e($s->hasil_seleksi == 'lulus' ? 'selected' : ''); ?>>Lulus</option>
                                <option value="tidak_lulus" <?php echo e($s->hasil_seleksi == 'tidak_lulus' ? 'selected' : ''); ?>>Tidak Lulus</option>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted">Belum ada siswa yang mengikuti tes</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/spmb/hasil_seleksi.blade.php ENDPATH**/ ?>