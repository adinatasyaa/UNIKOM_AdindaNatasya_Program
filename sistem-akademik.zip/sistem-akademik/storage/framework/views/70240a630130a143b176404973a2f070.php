

<?php $__env->startSection('page-title', 'Dashboard Wakasek Kesiswaan'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kesiswaan.dashboard')); ?>" class="nav-link active">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('kesiswaan.registrasi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kesiswaan.registrasi.*') ? 'active' : ''); ?>">
    <i class="bi bi-person-lines-fill me-2"></i> Daftar Siswa Registrasi
</a>
<a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" class="nav-link">
    <i class="bi bi-grid-3x3-gap me-2"></i> Pembagian Kelas
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted">SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-3 mb-4">

<div class="col-md-4">
        <a href="<?php echo e(route('kesiswaan.registrasi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-info h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Daftar Siswa Registrasi</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;">
                              <?php echo e(\App\Models\Siswa::whereNotNull('spmb_id')->count()); ?>

                        </p>
                    </div>
                    <i class="bi bi-person-lines-fill fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
    
    <div class="col-md-4">
        <a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Total Kelas</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;">
                            <?php echo e(\App\Models\PembagianKelas::count()); ?>

                        </p>
                    </div>
                    <i class="bi bi-grid-3x3-gap fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kesiswaan/dashboard.blade.php ENDPATH**/ ?>