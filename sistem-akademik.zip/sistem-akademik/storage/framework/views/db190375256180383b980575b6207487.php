

<?php $__env->startSection('page-title', 'Daftar Siswa Registrasi'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kesiswaan.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('kesiswaan.dashboard') ? 'active' : ''); ?>">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('kesiswaan.registrasi.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kesiswaan.registrasi.*') ? 'active' : ''); ?>">
    <i class="bi bi-person-lines-fill me-2"></i> Daftar Siswa Registrasi
</a>
<a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kesiswaan.pembagian.*') ? 'active' : ''); ?>">
    <i class="bi bi-people me-2"></i> Pembagian Kelas
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Daftar Siswa Registrasi</h5>
        <small class="text-muted">Siswa hasil konfirmasi pendaftaran SPMB. Lengkapi NIS sebelum pembagian kelas.</small>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($siswa->firstItem() + $index); ?></td>
                    <td>
                        <form action="<?php echo e(route('kesiswaan.registrasi.update_nis', $s->id)); ?>" method="POST" class="d-flex gap-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="text" name="nis" class="form-control form-control-sm" style="width: 130px;" value="<?php echo e($s->nis); ?>" placeholder="Isi NIS" required>
                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                        </form>
                    </td>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->kelas->nama_kelas ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted">Belum ada siswa dari hasil registrasi SPMB</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($siswa->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kesiswaan/registrasi/index.blade.php ENDPATH**/ ?>