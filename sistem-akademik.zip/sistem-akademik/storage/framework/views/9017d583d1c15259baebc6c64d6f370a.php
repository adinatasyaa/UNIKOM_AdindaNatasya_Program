<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cek Status PPDB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body style="background-color: #f8f9fa;">
    <!-- Navbar -->
    <nav class="navbar navbar-dark" style="background-color: #1a237e;">
        <div class="container">
            <a href="<?php echo e(route('ppdb.index')); ?>" class="navbar-brand fw-bold">
                <i class="bi bi-arrow-left me-2"></i>
                Kembali ke PPDB
            </a>
        </div>
    </nav>

    <div class="container py-4">
        <div class="card shadow-sm mx-auto" style="max-width: 600px;">
            <div class="card-header" style="background-color: #1a237e; color: white;">
                <h5 class="mb-0"><i class="bi bi-search me-2"></i>Cek Status Pendaftaran</h5>
            </div>
            <div class="card-body p-4">
                <form action="<?php echo e(route('ppdb.cek_status.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" name="nama_lengkap" class="form-control"
                            value="<?php echo e(old('nama_lengkap')); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">No. Telepon Orang Tua <span class="text-danger">*</span></label>
                        <input type="text" name="no_telp_orang_tua" class="form-control"
                            value="<?php echo e(old('no_telp_orang_tua')); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search me-1"></i> Cek Status
                    </button>
                </form>

                <?php if(isset($ppdb)): ?>
                    <?php if($ppdb): ?>
                        <hr class="my-4">
                        <h6 class="fw-bold">Hasil Pencarian:</h6>
                        <table class="table table-bordered">
                            <tr>
                                <td width="40%">Nama Lengkap</td>
                                <td><strong><?php echo e($ppdb->nama_lengkap); ?></strong></td>
                            </tr>
                            <tr>
                                <td>Asal Sekolah</td>
                                <td><?php echo e($ppdb->asal_sekolah); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Daftar</td>
                                <td><?php echo e($ppdb->created_at->format('d/m/Y')); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Tes</td>
                                <td><?php echo e($ppdb->tanggal_tes ? \Carbon\Carbon::parse($ppdb->tanggal_tes)->format('d/m/Y') : '-'); ?></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td>
                                    <?php if($ppdb->status == 'pending'): ?>
                                        <span class="badge bg-warning">Menunggu</span>
                                    <?php elseif($ppdb->status == 'diterima'): ?>
                                        <span class="badge bg-success">Diterima</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php if($ppdb->keterangan): ?>
                            <tr>
                                <td>Keterangan</td>
                                <td><?php echo e($ppdb->keterangan); ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <i class="bi bi-exclamation-triangle me-1"></i>
                            Data pendaftaran tidak ditemukan. Pastikan nama dan no. telepon sesuai.
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/ppdb/cek_status.blade.php ENDPATH**/ ?>