<?php $__env->startSection('page-title', 'Edit Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Data Siswa</h5>
        <a href="<?php echo e(route('operator.siswa.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('operator.siswa.update', $siswa->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">NIS <span class="text-danger">*</span></label>
                    <input type="text" name="nis" class="form-control" value="<?php echo e(old('nis', $siswa->nis)); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $siswa->nama)); ?>" required>
                </div>
    <div class="col-md-6">
        <label class="form-label">Kelas <span class="text-danger">*</span></label>
        <select name="kelas_id" class="form-select" required>
            <option value="">-- Pilih Kelas --</option>

            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>"
                    <?php echo e(old('kelas_id', $siswa->kelas_id) == $k->id ? 'selected' : ''); ?>>
                    <?php echo e($k->nama_kelas); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Jenis Kelamin</label>
        <select name="jenis_kelamin" class="form-select">
            <option value="">-- Pilih --</option>
            <option value="L" <?php echo e(old('jenis_kelamin', $siswa->jenis_kelamin) == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
            <option value="P" <?php echo e(old('jenis_kelamin', $siswa->jenis_kelamin) == 'P' ? 'selected' : ''); ?>>Perempuan</option>
        </select>
    </div>
        <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $siswa->email)); ?>">
        </div>  
        <div class="col-md-6">
            <label class="form-label">Tempat Lahir</label>
            <input type="text" name="tempat_lahir" class="form-control" value="<?php echo e(old('tempat_lahir', $siswa->tempat_lahir)); ?>">
        </div>
        <div class="col-md-6">
            <label class="form-label">Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo e(old('tanggal_lahir', $siswa->tanggal_lahir)); ?>">
        </div>
        <div class="col-md-6">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="aktif" <?php echo e(old('status', $siswa->status) == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="tidak_aktif" <?php echo e(old('status', $siswa->status) == 'tidak_aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
                </select>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save me-1"></i> Update
            </button>
                <a href="<?php echo e(route('operator.siswa.index')); ?>" class="btn btn-secondary">Batal</a>
        </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/operator/siswa/edit.blade.php ENDPATH**/ ?>