<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Formulir PPDB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-dark" style="background-color: #1a237e;">
        <div class="container">
            <a href="<?php echo e(route('ppdb.index')); ?>" class="navbar-brand fw-bold">
                <i class="bi bi-arrow-left me-2"></i>
                Kembali ke PPDB
            </a>
        </div>
    </nav>

    <div class="container py-4">
        <div class="card shadow-sm">
            <div class="card-header" style="background-color: #1a237e; color: white;">
                <h5 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Formulir Pendaftaran Siswa Baru</h5>
                <small>SMP Labschool UPI Kampus Cibiru</small>
            </div>
            <div class="card-body p-4">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('ppdb.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <h6 class="fw-bold text-primary mb-3">Data Siswa</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" name="nama_lengkap" class="form-control"
                                value="<?php echo e(old('nama_lengkap')); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                            <select name="jenis_kelamin" class="form-select" required>
                                <option value="">-- Pilih --</option>
                                <option value="L" <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                                <option value="P" <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                            <input type="text" name="tempat_lahir" class="form-control"
                                value="<?php echo e(old('tempat_lahir')); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                            <input type="date" name="tanggal_lahir" class="form-control"
                                value="<?php echo e(old('tanggal_lahir')); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Asal Sekolah <span class="text-danger">*</span></label>
                            <input type="text" name="asal_sekolah" class="form-control"
                                value="<?php echo e(old('asal_sekolah')); ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Alamat <span class="text-danger">*</span></label>
                            <textarea name="alamat" class="form-control" rows="3" required><?php echo e(old('alamat')); ?></textarea>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="fw-bold text-primary mb-3">Data Orang Tua</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nama Orang Tua <span class="text-danger">*</span></label>
                            <input type="text" name="nama_orang_tua" class="form-control"
                                value="<?php echo e(old('nama_orang_tua')); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">No. Telepon Orang Tua <span class="text-danger">*</span></label>
                            <input type="text" name="no_telp_orang_tua" class="form-control"
                                value="<?php echo e(old('no_telp_orang_tua')); ?>" required>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="fw-bold text-primary mb-3">Upload Berkas</h6>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-1"></i>
                        Format file yang diterima: PDF, JPG, PNG. Maksimal 2MB per file.
                    </div>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Rapor SD</label>
                            <input type="file" name="berkas_rapor" class="form-control"
                                accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Kartu Keluarga</label>
                            <input type="file" name="berkas_kk" class="form-control"
                                accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Akta Kelahiran</label>
                            <input type="file" name="berkas_akta" class="form-control"
                                accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                    </div>

                    <div class="mt-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-send me-1"></i> Kirim Pendaftaran
                        </button>
                        <a href="<?php echo e(route('ppdb.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/ppdb/create.blade.php ENDPATH**/ ?>