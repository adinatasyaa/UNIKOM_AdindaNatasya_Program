<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pengumuman PPDB - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body style="background-color: #f8f9fa;">
    <!-- Navbar -->
    <nav class="navbar navbar-dark" style="background-color: #1a237e;">
        <div class="container">
            <a href="<?php echo e(route('ppdb.index')); ?>" class="navbar-brand fw-bold">
                <i class="bi bi-arrow-left me-2"></i>
                Kembali ke PPDB
            </a>
        </div>
    </nav>

    <div class="container py-4">
        <div class="card shadow-sm">
            <div class="card-header" style="background-color: #1a237e; color: white;">
                <h5 class="mb-0"><i class="bi bi-megaphone me-2"></i>Pengumuman Hasil Seleksi PPDB</h5>
                <small>SMP Labschool UPI Kampus Cibiru</small>
            </div>
            <div class="card-body">
                <?php if($pengumuman->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Siswa</th>
                                    <th>Asal Sekolah</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pengumuman->firstItem() + $index); ?></td>
                                    <td><?php echo e($p->nama_siswa); ?></td>
                                    <td><?php echo e($p->asal_sekolah); ?></td>
                                    <td>
                                        <?php if($p->status == 'diterima'): ?>
                                            <span class="badge bg-success">Diterima</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Ditolak</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($pengumuman->links('pagination::bootstrap-5')); ?>

                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-megaphone" style="font-size: 3rem;"></i>
                        <p class="mt-3">Belum ada pengumuman hasil seleksi.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/ppdb/pengumuman.blade.php ENDPATH**/ ?>