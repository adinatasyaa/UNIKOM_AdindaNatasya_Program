<?php $__env->startSection('page-title', 'Edit Pembagian Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="card shadow-sm mx-auto" style="max-width: 500px;">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0">Edit Wali Kelas: <?php echo e($pembagianKelas->kelas->nama_kelas); ?></h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('kesiswaan.pembagian.update', $pembagianKelas->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Pilih Wali Kelas Baru</label>
                    <select class="form-select" name="guru_id" required>
                        <?php $__currentLoopData = $daftarGuru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($g->id); ?>" <?php echo e($pembagianKelas->guru_id == $g->id ? 'selected' : ''); ?>><?php echo e($g->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('kesiswaan.pembagian.index')); ?>" class="btn btn-secondary w-50">Batal</a>
                    <button type="submit" class="btn btn-warning w-50">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kesiswaan/pembagian/edit.blade.php ENDPATH**/ ?>