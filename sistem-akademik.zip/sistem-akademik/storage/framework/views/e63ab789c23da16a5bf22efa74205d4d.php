<?php $__env->startSection('page-title', 'Jadwal Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h4>Jadwal Mata Pelajaran</h4>
            <p class="text-muted">
                Jadwal mata pelajaran sesuai kelas yang telah ditetapkan sekolah.
            </p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>


            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Jadwal Pelajaran</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Hari</th>
                        <th>Jam</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                        <th>Kelas</th>
                        <th>Tahun Ajaran</th>
                        <th>Semester</th>
                    </tr>
                </thead>
                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->hari); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($item->jam_mulai)->format('H.i')); ?> - <?php echo e(\Carbon\Carbon::parse($item->jam_selesai)->format('H.i')); ?></td>
                        <td><?php echo e($item->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($item->guru->nama ?? '-'); ?></td>
                        <td><?php echo e($item->kelas->nama_kelas ?? '-'); ?></td>
                        <td><?php echo e($item->tahun_ajaran); ?></td>
                        <td><?php echo e($item->semester); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="8"
                            class="text-center py-4 text-muted">
                            Jadwal pelajaran belum tersedia.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/siswa/jadwal/index.blade.php ENDPATH**/ ?>