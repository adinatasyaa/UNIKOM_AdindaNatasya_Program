

<?php $__env->startSection('page-title', 'Jadwal Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Approval Jadwal Mata Pelajaran</h5>
    </div>

<div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="text-nowrap">No</th>
                    <th class="text-nowrap">Kelas</th>
                    <th class="text-nowrap">Mata Pelajaran</th>
                    <th class="text-nowrap">Guru</th>
                    <th class="text-nowrap">Hari</th>
                    <th class="text-nowrap">Jam</th>
                    <th class="text-nowrap">Tahun Ajaran</th>
                    <th class="text-nowrap">Semester</th>
                    <th class="text-nowrap">Status</th>
                    <th class="text-nowrap">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->kelas->nama_kelas); ?></td>
                    <td><?php echo e($item->mataPelajaran->nama_mapel); ?></td>
                    <td><?php echo e($item->guru->nama); ?></td>
                    <td><?php echo e($item->hari); ?></td>
                    <td>
                        <?php
                            $mulai = \Carbon\Carbon::parse($item->jam_mulai);
                            $selesai = \Carbon\Carbon::parse($item->jam_selesai);
                            $menit = $mulai->diffInMinutes($selesai);
                            $jam = intdiv($menit, 60);
                            $sisaMenit = $menit % 60;

                            $durasi = '';
                            if ($jam > 0) {
                                $durasi .= $jam . ' jam ';
                            }
                            if ($sisaMenit > 0) {
                                $durasi .= $sisaMenit . ' menit';
                            }
                        ?>
                        <?php echo e(trim($durasi)); ?>

                    </td>
                    <td><?php echo e($item->tahun_ajaran); ?></td>
                    <td>
                        <?php if($item->semester == 1): ?>
                            Ganjil
                        <?php else: ?>
                            Genap
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item->status == 'draft'): ?>
                            <span class="badge bg-secondary">
                                Draft
                            </span>
                        <?php elseif($item->status == 'menunggu_persetujuan'): ?>
                            <span class="badge bg-warning text-dark">
                                Menunggu Persetujuan
                            </span>
                        <?php elseif($item->status == 'disetujui'): ?>
                            <span class="badge bg-success">
                                Disetujui
                            </span>
                        <?php else: ?>
                            <span class="badge bg-danger">
                                Ditolak
                            </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item->status == 'menunggu_persetujuan'): ?>

                            <form action="<?php echo e(route('kepala_sekolah.jadwal.setujui', $item->id)); ?>"method="POST"
                                class="mb-2">
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn btn-success btn-sm w-100">
                                Setujui
                              </button>
                            </form>

                            <form action="<?php echo e(route('kepala_sekolah.jadwal.tolak', $item->id)); ?>"method="POST">
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn btn-danger btn-sm w-100">
                                Tolak
                              </button>
                            </form>

                               <?php else: ?>
        
                               <?php endif; ?>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">
                        Belum ada data jadwal mata pelajaran.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="mt-3">
            <?php echo e($jadwal->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kepala_sekolah/jadwal/index.blade.php ENDPATH**/ ?>