<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Hapus Akun')); ?>

        </h2>
        <p class="text-muted mb-3">
            Setelah akun Anda dihapus, semua data terkait akan dihapus secara permanen. Silakan unduh data yang ingin Anda simpan sebelum menghapus akun.
        </p>
    </header>

    <?php if($errors->userDeletion->isNotEmpty()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->userDeletion->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('profile.destroy')); ?>" onsubmit="return confirmDeleteAccount()">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>

        <div class="mb-3" style="max-width: 300px;">
            <label for="password" class="form-label">Password</label>
            <input id="password" name="password" type="password" class="form-control" placeholder="Masukkan password Anda">
        </div>

        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash me-1"></i> Hapus Akun
        </button>
    </form>
</section>

<script>
function confirmDeleteAccount() {
    return confirm('Yakin ingin menghapus akun ini? Tindakan ini tidak dapat dibatalkan dan seluruh data akan hilang permanen.');
}
</script><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>