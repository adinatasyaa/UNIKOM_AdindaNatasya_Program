<?php $__env->startSection('page-title', 'Edit Absensi'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Absensi</h5>
        <a href="<?php echo e(route('guru.absensi.show', $absensi->id)); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Informasi Absensi -->
        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <td width="40%">Mata Pelajaran</td>
                        <td><strong><?php echo e($absensi->mataPelajaran->nama_mapel ?? '-'); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Kelas</td>
                        <td><?php echo e($absensi->kelas->nama_kelas ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td><?php echo e(\Carbon\Carbon::parse($absensi->tanggal)->format('d/m/Y')); ?></td>
                    </tr>
                    <tr>
                        <td>Jam Pelajaran</td>
                        <td><?php echo e($absensi->jam_pelajaran); ?></td>
                    </tr>
                    <tr>
                        <td>Semester</td>
                        <td>Semester <?php echo e($absensi->semester); ?></td>
                    </tr>
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td><?php echo e($absensi->tahun_ajaran); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Form Edit Kehadiran -->
        <form action="<?php echo e(route('guru.absensi.update', $absensi->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <h6 class="fw-bold mb-3">Edit Kehadiran Siswa</h6>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead style="font-weight:600;">
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Status Kehadiran</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $absensi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($d->siswa->nis ?? '-'); ?></td>
                            <td><?php echo e($d->siswa->nama ?? '-'); ?></td>
                            <td>
                                <select name="kehadiran[<?php echo e($d->id); ?>][status]" class="form-select form-select-sm" required>
                                    <option value="Hadir" <?php echo e($d->status_kehadiran == 'Hadir' ? 'selected' : ''); ?>>Hadir</option>
                                    <option value="Izin" <?php echo e($d->status_kehadiran == 'Izin' ? 'selected' : ''); ?>>Izin</option>
                                    <option value="Sakit" <?php echo e($d->status_kehadiran == 'Sakit' ? 'selected' : ''); ?>>Sakit</option>
                                    <option value="Alpa" <?php echo e($d->status_kehadiran == 'Alpa' ? 'selected' : ''); ?>>Alpa</option>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="kehadiran[<?php echo e($d->id); ?>][keterangan]"
                                    class="form-control form-control-sm"
                                    value="<?php echo e($d->keterangan); ?>"
                                    placeholder="Keterangan (opsional)">
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Belum ada data kehadiran</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn btn-primary mt-3">
                <i class="bi bi-save me-1"></i> Simpan Perubahan
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/absensi/edit.blade.php ENDPATH**/ ?>