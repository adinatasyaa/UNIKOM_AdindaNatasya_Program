<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pendaftaran Berhasil - SMP Labschool UPI Kampus Cibiru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body style="background-color: #f8f9fa;">
    <div class="container py-5">
        <div class="card shadow-sm text-center p-5 mx-auto" style="max-width: 600px;">
            <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
            <h3 class="mt-3 fw-bold">Pendaftaran Berhasil!</h3>
            <p class="text-muted">Terima kasih, pendaftaran atas nama:</p>
            <h4 class="fw-bold text-primary"><?php echo e($ppdb->nama_lengkap); ?></h4>
            <p class="text-muted">telah berhasil dikirim.</p>

            <div class="alert alert-info mt-3">
                <i class="bi bi-info-circle me-1"></i>
                Untuk mengecek status pendaftaran, gunakan:
                <br>
                <strong>Nama Lengkap</strong> dan <strong>No. Telepon Orang Tua</strong>
            </div>

            <div class="d-flex gap-2 justify-content-center mt-3">
                <a href="<?php echo e(route('ppdb.cek_status')); ?>" class="btn btn-primary">
                    <i class="bi bi-search me-1"></i> Cek Status
                </a>
                <a href="<?php echo e(route('ppdb.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-house me-1"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/ppdb/success.blade.php ENDPATH**/ ?>