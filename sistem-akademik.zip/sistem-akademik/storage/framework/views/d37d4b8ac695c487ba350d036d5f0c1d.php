<?php $__env->startSection('page-title', 'Dashboard Wali Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted"> SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-4">
        <a href="<?php echo e(route('wali_kelas.absensi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Absensi</h5>
                        <p class="mb-0" style="font-size:13px; opacity:0.9;">Rekap absensi kelas & pantau info piket</p>
                    </div>
                    <i class="bi bi-calendar-check fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="<?php echo e(route('wali_kelas.penilaian.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-success h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Penilaian</h5>
                        <p class="mb-0" style="font-size:13px; opacity:0.9;">Lihat & kelola input nilai rapor siswa</p>
                    </div>
                    <i class="bi bi-journal-text fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

     <div class="col-md-4">
        <a href="<?php echo e(route('wali_kelas.pembagian_kelas.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-warning h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Pembagian Kelas</h5>
                        <p class="mb-0" style="font-size:13px; opacity:0.9;">
                            Lihat pembagian kelas dan daftar siswa
                        </p>
                    </div>

                    <i class="bi bi-diagram-3 fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/dashboard.blade.php ENDPATH**/ ?>