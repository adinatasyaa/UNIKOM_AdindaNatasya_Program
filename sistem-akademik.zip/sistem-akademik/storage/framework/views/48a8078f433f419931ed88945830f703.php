<?php $__env->startSection('page-title', 'Penjadwalan Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Penjadwalan Mata Pelajaran</h5>
        <a href="<?php echo e(route('kurikulum.penjadwalan.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Tambah Jadwal
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

		<form method="GET" action="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="row g-2 mb-3">
            <div class="col-auto">
                <select name="kelas_id" class="form-select">
                    <option value="">-- Semua Kelas --</option>
                    <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>>
                            <?php echo e($k->nama_kelas); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-auto">
                <select name="hari" class="form-select">
                    <option value="">-- Semua Hari --</option>
                    <?php $__currentLoopData = ['Senin','Selasa','Rabu','Kamis','Jumat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($h); ?>" <?php echo e(request('hari') == $h ? 'selected' : ''); ?>><?php echo e($h); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>
        <div class="table-responsive">
           <table class="table table-hover table-bordered">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th class="text-nowrap">No</th>
                        <th class="text-nowrap">Kelas</th>
                        <th class="text-nowrap">Mata Pelajaran</th>
                        <th class="text-nowrap">Guru</th>
                        <th class="text-nowrap">Hari</th>
                        <th class="text-nowrap">Jam</th>
                        <th class="text-nowrap">Jumlah Jam</th>
                        <th class="text-nowrap">Tahun Ajaran</th>
                        <th class="text-nowrap">Semester</th>
                        <th class="text-nowrap">Status</th>
                        <th class="text-nowrap">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($jadwal->firstItem() + $index); ?></td>
                        <td><?php echo e($j->kelas->nama_kelas ?? '-'); ?></td>
                        <td><?php echo e($j->mataPelajaran->kode_mapel ?? '-'); ?></td>
                        <td><?php echo e($j->guru->nama ?? '-'); ?></td>
                        <td><?php echo e($j->hari); ?></td>
                        <td><?php echo e(date('H.i', strtotime($j->jam_mulai))); ?> - <?php echo e(date('H.i', strtotime($j->jam_selesai))); ?></td>
                        <td class="text-center"><?php echo e($j->jumlah_jam); ?> jam</td>
                        <td><?php echo e($j->tahun_ajaran); ?></td>
                        <td>Semester <?php echo e($j->semester); ?></td>
                        <td>
                            <?php if($j->status == 'draft'): ?>
                                <span class="badge bg-secondary">Draft</span>
                            <?php elseif($j->status == 'menunggu_persetujuan'): ?>
                                <span class="badge bg-warning text-dark">Menunggu Persetujuan
                                </span>
                            <?php elseif($j->status == 'disetujui'): ?>
                                <span class="badge bg-success">Disetujui
                                </span>
                            <?php elseif($j->status == 'ditolak'): ?>
                                <span class="badge bg-danger">Ditolak
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center text-nowrap" style="min-width: 140px;">
                            <a href="<?php echo e(route('kurikulum.penjadwalan.show', $j->id)); ?>" class="btn btn-sm btn-info">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="<?php echo e(route('kurikulum.penjadwalan.edit', $j->id)); ?>" class="btn btn-sm btn-warning">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?php echo e(route('kurikulum.penjadwalan.destroy', $j->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Hapus data ini?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="11" class="text-center text-muted">Belum ada jadwal</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($jadwal->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/penjadwalan/index.blade.php ENDPATH**/ ?>