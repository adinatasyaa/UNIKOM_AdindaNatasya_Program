<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="mb-4">
        <h4 class="mb-0">Persetujuan Tugas Wali Kelas</h4>
        <p class="text-muted">Silakan periksa dan setujui daftar siswa yang dibagikan oleh Wakasek Kesiswaan.</p>
    </div>

    <div class="card mb-4 shadow-sm border-0">
        <div class="card-body bg-light rounded py-3">
            <form action="<?php echo e(route('wali_kelas.persetujuan.index')); ?>" method="GET" id="formPilihGuru" class="row align-items-center mb-0">
                <div class="col-md-3">
                    <label for="pilih_guru_id" class="form-label font-weight-bold text-secondary mb-md-0">Simulasi Pilih Wali Kelas:</label>
                </div>
                <div class="col-md-5">
                    <select name="pilih_guru_id" id="pilih_guru_id" class="form-select form-control" onchange="document.getElementById('formPilihGuru').submit();">
                        <?php $__currentLoopData = $semuaWaliKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($guru->id); ?>" <?php echo e($guruId == $guru->id ? 'selected' : ''); ?>>
                                <?php echo e($guru->nama_guru); ?> (ID: <?php echo e($guru->id); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <?php if(session('success')): ?> 
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tahun / Semester</th>
                        <th>Kelas Yang Ditugaskan</th>
                        <th>Status Persetujuan Anda</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kelasSaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($ks->tahun_ajaran); ?> / <?php echo e($ks->semester); ?></td>
                        <td><strong><?php echo e($ks->kelas->nama_kelas ?? 'Kelas Tidak Ditemukan'); ?></strong></td>
                        <td>
                            <?php if($ks->status_persetujuan == 'menunggu'): ?> 
                                <span class="badge bg-warning text-dark">Menunggu Persetujuan</span>
                            <?php elseif($ks->status_persetujuan == 'disetujui'): ?> 
                                <span class="badge bg-success">Sudah Disetujui</span>
                            <?php else: ?> 
                                <span class="badge bg-danger">Anda Tolak</span> 
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('wali_kelas.persetujuan.show', $ks->id)); ?>" class="btn btn-sm btn-primary">
                                Periksa Daftar Siswa
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">Belum ada tugas pembagian kelas untuk Wali Kelas ini saat ini.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/persetujuan/index.blade.php ENDPATH**/ ?>