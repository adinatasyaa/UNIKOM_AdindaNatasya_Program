<?php $__env->startSection('page-title', 'Detail Persetujuan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="<?php echo e(route('wali_kelas.pembagian_kelas.index')); ?>"class="btn btn-secondary btn-sm mb-2">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
            <h4 class="mb-0">Detail Siswa Kelas: <?php echo e($pembagianKelas->kelas->nama_kelas); ?></h4>
            <small class="text-muted">Tahun Ajaran: <?php echo e($pembagianKelas->tahun_ajaran); ?> | Semester: <?php echo e($pembagianKelas->semester); ?></small>
        </div>
            <div>
                Status Kelas: 
                <span class="badge <?php echo e($pembagianKelas->status_persetujuan == 'disetujui' ? 'bg-success' : 'bg-danger'); ?> uppercase">
                    <?php echo e(strtoupper($pembagianKelas->status_persetujuan)); ?>

                </span>
            </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white font-weight-bold">
            Daftar Siswa Terdistribusi (Total: <?php echo e($daftarSiswa->count()); ?> Siswa)
        </div>
        <div class="card-body p-0">
            <table class="table table-striped table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="50" class="text-center">No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($index + 1); ?></td>
                        <td><?php echo e($ds->siswa->nis ?? '-'); ?></td>
                        <td><?php echo e($ds->siswa->nama ?? 'Nama Tidak Terdata'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="text-center py-4 text-muted">Belum ada data siswa yang dimasukkan ke kelas ini oleh Kesiswaan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/pembagian_kelas/show.blade.php ENDPATH**/ ?>