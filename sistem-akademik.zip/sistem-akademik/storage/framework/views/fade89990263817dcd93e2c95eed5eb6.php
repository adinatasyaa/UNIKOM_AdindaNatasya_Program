<?php $__env->startSection('page-title', 'Dashboard Guru Piket'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted">SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-3">
        <a href="<?php echo e(route('guru_piket.absensi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Total Absensi Piket</h5>
                        <p class="mb-0 fw-bold" style="font-size:25px;">
                            <?php echo e(\App\Models\AbsensiPiket::where('guru_piket_id', \App\Models\Guru::where('email', auth()->user()->email)->first()?->id)->count()); ?>

                        </p>
                    </div>
                    <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('guru_piket.absensi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-warning h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Terlambat Hari Ini</h5>
                        <p class="mb-0 fw-bold" style="font-size:25px;">
                            <?php echo e(\App\Models\AbsensiPiket::where('tanggal', date('Y-m-d'))->where('status', 'terlambat')->count()); ?>

                        </p>
                    </div>
                    <i class="bi bi-clock fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('guru_piket.absensi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-danger h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Tidak Hadir Hari Ini</h5>
                        <p class="mb-0 fw-bold" style="font-size:25px;">
                            <?php echo e(\App\Models\AbsensiPiket::where('tanggal', date('Y-m-d'))->where('status', 'tidak_hadir')->count()); ?>

                        </p>
                    </div>
                    <i class="bi bi-person-x fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('guru_piket.pembagian-guru-piket.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-info h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Jadwal Piket</h5>
                        <p class="mb-0 fw-bold" style="font-size:25px;">
                            <?php echo e(\App\Models\PembagianGuruPiket::where('guru_id', \App\Models\Guru::where('email', auth()->user()->email)->first()?->id)->count()); ?>

                        </p>
                    </div>
                    <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru_piket/dashboard.blade.php ENDPATH**/ ?>