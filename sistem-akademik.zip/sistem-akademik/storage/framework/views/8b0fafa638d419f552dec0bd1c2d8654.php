<?php $__env->startSection('page-title', 'Pembagian Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Pembagian Kelas Siswa</h4>
        <a href="<?php echo e(route('kesiswaan.pembagian.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Tambah Pembagian Siswa
            </a>
    </div>

    <?php if(session('success')): ?> 
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tahun / Semester</th>
                        <th>Kelas</th>
                        <th>Wali Kelas</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $riwayatPembagian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($rp->tahun_ajaran); ?> / <?php echo e($rp->semester); ?></td>
                        <td><strong><?php echo e($rp->kelas->nama_kelas ?? 'Kelas Tidak Ditemukan'); ?></strong></td>
                        <td><?php echo e($rp->guru->nama ?? 'Belum Ditunjuk'); ?></td>
                        <td>
                            <?php if($rp->status_persetujuan == 'menunggu'): ?> 
                                <span class="badge bg-warning text-dark">Menunggu</span>
                            <?php elseif($rp->status_persetujuan == 'disetujui'): ?> 
                                <span class="badge bg-success">Disetujui</span>
                            <?php else: ?> 
                                <span class="badge bg-danger">Ditolak</span> 
                            <?php endif; ?>
                        </td>
                        <td class="text-center text-nowrap">

                            <a href="<?php echo e(route('kesiswaan.pembagian.show', $rp->id)); ?>"
                               class="btn btn-info btn-sm"
                               title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>

                            <a href="<?php echo e(route('kesiswaan.pembagian.edit', $rp->id)); ?>"
                               class="btn btn-warning btn-sm"
                               title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>

                            <form action="<?php echo e(route('kesiswaan.pembagian.destroy', $rp->id)); ?>"
                                  method="POST"
                                  class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit"
                                        class="btn btn-danger btn-sm"
                                        onclick="return confirm('Yakin ingin menghapus?')"
                                        title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">Belum ada data pembagian kelas.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kesiswaan/pembagian/index.blade.php ENDPATH**/ ?>