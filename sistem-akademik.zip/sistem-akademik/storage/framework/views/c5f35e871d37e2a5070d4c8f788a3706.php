<?php $__env->startSection('page-title', 'Detail Jadwal'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detail Jadwal Mata Pelajaran</h5>
        <a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <h6 class="fw-bold text-primary">Detail Jadwal</h6>
        <table class="table table-bordered">
            <tr>
                <td width="30%">Kelas</td>
                <td><strong><?php echo e($jadwal->kelas->nama_kelas ?? '-'); ?></strong></td>
            </tr>
            <tr>
                <td>Mata Pelajaran</td>
                <td><?php echo e($jadwal->mataPelajaran->kode_mapel ?? '-'); ?></td>
            </tr>
            <tr>
                <td>Guru</td>
                <td><?php echo e($jadwal->guru->nama ?? '-'); ?></td>
            </tr>
            <tr>
                <td>Hari</td>
                <td><?php echo e($jadwal->hari); ?></td>
            </tr>
            <tr>
                <td>Jam</td>
                <td><?php echo e(\Carbon\Carbon::parse($jadwal->jam_mulai)->format('H.i')); ?> - <?php echo e(\Carbon\Carbon::parse($jadwal->jam_selesai)->format('H.i')); ?></td>
            </tr>
            <tr>
                <td>Tahun Ajaran</td>
                <td><?php echo e($jadwal->tahun_ajaran); ?></td>
            </tr>
            <tr>
                <td>Semester</td>
                <td>Semester <?php echo e($jadwal->semester); ?></td>
            </tr>
            <tr>
                <td>Status</td>
                <td><span class="badge bg-success">Aktif</span></td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wakasek_kurikulum/penjadwalan/show.blade.php ENDPATH**/ ?>