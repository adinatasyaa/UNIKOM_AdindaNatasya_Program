

<?php $__env->startSection('page-title', 'Penilaian'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="mb-3">
        <h4>Data Penilaian</h4>
        <p class="text-muted">
            Daftar nilai yang telah diberikan oleh guru mata pelajaran.
        </p>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Daftar Nilai</strong>
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered table-hover mb-0">
                <thead style="border-bottom: 2px solid #dee2e6; font-weight: 600;">
                    <tr>
                        <th class="text-nowrap">No</th>
                        <th class="text-nowrap">Mata Pelajaran</th>
                        <th class="text-nowrap">Guru</th>
                        <th class="text-nowrap">Tahun Ajaran</th>
                        <th class="text-nowrap">Semester</th>
                        <th class="text-nowrap" style="max-width: 200px;">Nilai Akhir</th>
                        <th class="text-nowrap">Predikat</th>
                        <th class="text-nowrap">Status</th>
                    </tr>
                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->mataPelajaran->nama_mapel ?? '-'); ?></td>
                        <td><?php echo e($item->guru->nama ?? '-'); ?></td>
                        <td class="text-center"><?php echo e($item->tahun_ajaran); ?></td>
                        <td class="text-center"><?php echo e($item->semester); ?></td>
                        <td class="text-center fw-bold"><?php echo e($item->nilai_akhir); ?></td>
                       <td class="text-center">
                            <div class="d-flex flex-column align-items-center gap-1">
                                <span class="badge bg-primary"><?php echo e($item->predikat); ?></span>
                                <span class="badge bg-light text-dark border" style="white-space: nowrap; font-weight: 500;">
                                     <?php echo e($item->keterangan); ?>

                                </span>
                            </div>
                        </td>
                        <td class="text-center">
                            <?php if($item->status=='final'): ?>
                                <span class="badge bg-success">Final</span>
                            <?php elseif($item->status=='lengkap'): ?>
                                <span class="badge bg-info">Lengkap</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Belum Lengkap</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="8" class="text-center py-4">
                            Belum ada data penilaian.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/siswa/penilaian/index.blade.php ENDPATH**/ ?>