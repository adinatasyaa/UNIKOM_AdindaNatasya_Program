<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="mb-4">
        <h4 class="mb-0">Pembagian Kelas</h4>
            <p class="text-muted">Daftar kelas dan siswa yang telah ditetapkan oleh sekolah.</p>
    </div>
    <?php if(session('success')): ?> 
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tahun / Semester</th>
                        <th>Kelas Yang Ditugaskan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kelasSaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($ks->tahun_ajaran); ?> / <?php echo e($ks->semester); ?></td>
                        <td><strong><?php echo e($ks->kelas->nama_kelas ?? 'Kelas Tidak Ditemukan'); ?></strong></td>
                        <td>
                            <?php if($ks->status_persetujuan == 'menunggu'): ?>
                                <span class="badge bg-warning text-dark">
                                    Menunggu Persetujuan Kepala Sekolah
                                </span>
                            <?php elseif($ks->status_persetujuan == 'disetujui'): ?>
                                <span class="badge bg-success">
                                    Disetujui Kepala Sekolah
                                </span>
                            <?php else: ?>
                                <span class="badge bg-danger">
                                    Ditolak Kepala Sekolah
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('wali_kelas.pembagian_kelas.show', $ks->id)); ?>"class="btn btn-info btn-sm"title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">Belum ada pembagian kelas yang dapat ditampilkan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/pembagian_kelas/index.blade.php ENDPATH**/ ?>