<?php $__env->startSection('page-title', 'Dashboard Guru Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted">SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-4">
        <a href="<?php echo e(route('guru.absensi.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Absensi</h5>
                        <p class="mb-0" style="font-size:13px; opacity:0.9;">Input kehadiran siswa</p>
                    </div>
                    <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?php echo e(route('guru.bobot.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-success h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Penilaian</h5>
                        <p class="mb-0" style="font-size:13px; opacity:0.9;">Bobot & input nilai siswa</p>
                    </div>
                    <i class="bi bi-clipboard-data fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?php echo e(route('guru.jadwal_mengajar.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-warning h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Jadwal Mengajar</h5>
                        <p class="mb-0" style="font-size:13px; opacity:0.9;">Lihat jadwal mengajar Anda</p>
                    </div>
                    <i class="bi bi-calendar3 fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/guru/dashboard.blade.php ENDPATH**/ ?>