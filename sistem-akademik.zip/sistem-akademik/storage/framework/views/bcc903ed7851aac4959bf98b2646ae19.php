<?php $__env->startSection('page-title', 'Dashboard Wakasek Kurikulum'); ?>

<?php $__env->startSection('sidebar'); ?>
<a href="<?php echo e(route('kurikulum.dashboard')); ?>" class="nav-link active">
    <i class="bi bi-speedometer2 me-2"></i> Dashboard
</a>
<a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="nav-link">
    <i class="bi bi-person-plus me-2"></i> Data SPMB
</a>
<a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="nav-link">
    <i class="bi bi-calendar-event me-2"></i> Penjadwalan
</a>
<a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" class="nav-link">
    <i class="bi bi-clipboard-check me-2"></i> Data Seleksi
</a>
<a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" class="nav-link">
    <i class="bi bi-award me-2"></i> Data Hasil Seleksi
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-3">
        <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted">SMP Labschool UPI Kampus Cibiru</p>
    </div>
</div>

<div class="row g-3 mb-4">
    
    <div class="col-md-4">
        <a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-warning h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Menunggu</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Spmb::where('status', 'pending')->count()); ?></p>
                    </div>
                    <i class="bi bi-hourglass-split fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-success h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Diterima</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Spmb::where('status', 'diterima')->count()); ?></p>
                    </div>
                    <i class="bi bi-check-circle fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="<?php echo e(route('kurikulum.spmb.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-danger h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Ditolak</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Spmb::where('status', 'ditolak')->count()); ?></p>
                    </div>
                    <i class="bi bi-x-circle fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
    <a href="<?php echo e(route('kurikulum.spmb.data_seleksi')); ?>" class="text-decoration-none">
        <div class="card text-white bg-purple h-100 shadow-sm">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Data Seleksi</h5>
                    <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Spmb::whereIn('status', ['diterima', 'konfirmasi'])->count()); ?></p>
                </div>
                <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
            </div>
        </div>
    </a>
</div>

<div class="col-md-4">
    <a href="<?php echo e(route('kurikulum.spmb.hasil_seleksi')); ?>" class="text-decoration-none">
        <div class="card text-white bg-secondary h-100 shadow-sm">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Data Hasil Seleksi</h5>
                    <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e(\App\Models\Spmb::whereIn('status', ['diterima', 'konfirmasi'])->where('hasil_seleksi', 'lulus')->count()); ?></p>
                </div>
                <i class="bi bi-award fs-1 opacity-50"></i>
            </div>
        </div>
    </a>
</div>

<div class="col-md-4">
        <a href="<?php echo e(route('kurikulum.mapel.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-primary h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Kelola Mata Pelajaran</h5>
                        
                    </div>
                    <i class="bi bi-book fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

<div class="col-md-4">
        <a href="<?php echo e(route('kurikulum.penjadwalan.index')); ?>" class="text-decoration-none">
            <div class="card text-white bg-info h-100 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Total Penjadwalan</h5>
                        <p class="mb-0 fw-bold" style="font-size: 25px;"><?php echo e($total_jadwal ?? 0); ?></p>
                    </div>
                    <i class="bi bi-calendar-event fs-1 opacity-50"></i>
                </div>
            </div>
        </a>
    </div>

</div>
<style>
    .bg-purple { background-color: #6f42c1 !important; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/kurikulum/dashboard.blade.php ENDPATH**/ ?>