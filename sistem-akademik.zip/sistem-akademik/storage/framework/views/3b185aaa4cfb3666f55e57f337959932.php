<?php $__env->startSection('page-title', 'Penilaian Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Pilih Kelas</h5>
    </div>
    <div class="card-body">
        <p class="text-muted">Pilih kelas yang Anda ampu untuk melihat kelengkapan nilai siswa.</p>
        <div class="row g-3">
            <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3">
                <a href="<?php echo e(route('wali_kelas.penilaian.show', $k->id)); ?>" class="text-decoration-none">
                    <div class="card text-center p-3 h-100" style="border:1px solid #dee2e6; transition:.2s;"
                        onmouseover="this.style.boxShadow='0 4px 10px rgba(0,0,0,0.1)'"
                        onmouseout="this.style.boxShadow='none'">
                        <i class="bi bi-door-open fs-2 text-primary mb-2"></i>
                        <h6 class="mb-0"><?php echo e($k->nama_kelas); ?></h6>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center text-muted py-4">
                Anda belum ditetapkan sebagai wali kelas manapun.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-akademik\resources\views/wali_kelas/penilaian/index.blade.php ENDPATH**/ ?>